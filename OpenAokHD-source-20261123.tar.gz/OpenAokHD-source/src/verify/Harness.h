#pragma once

// The headless self-check behind `--verify`, one translation unit per scenario.
// Each scenario builds its own world from the same fixed seed, so the scenarios
// are independent of their order.
//
// Every scenario prints one machine-readable line. tools/check_determinism.sh
// greps for them, so their wording must not change.
#include <cstdint>

#include <entt/entt.hpp>

namespace ECS {
class Simulation;
}

namespace Verify {

// A digest of the world's state -- every entity's place, hit points, owner and
// identity, in entity order. Two worlds that should be the same, and are not,
// have different fingerprints.
uint64_t Fingerprint(const entt::registry& registry);

// Whether the map generated and the simulation stayed bit-identical over
// `ticks`, and whether every unit given a move order reached it.
// Prints "verify:", "arrived=" and "entities=".
bool CheckDeterminism(int ticks);

// A villager sent at a resource: reach it, take from it, carry the load to a
// drop site, hand it over. Prints "gathering=".
bool CheckGathering();

// A villager sent to drop off at one of the player's buildings: all of its
// load handed over, a part of a unit too, and then it stands; only at a
// finished building of its own that takes the load; going into the Town
// Center banks the load, rounded, and into a tower nothing. Prints
// "dropoff=".
bool CheckDropoff();

// Graphics run their dat sequences: a standing scout rests between plays of
// its idle, and a packed trebuchet standing keeps its wheels still.
bool CheckSequence();

// A destroyed building falls in its dat dying graphic over its rubble.
bool CheckCollapse();
// Villagers sent at a sheep by the Town Center kill it, stand at it to take
// its food, and walk no further than the way there and back calls for.
bool CheckHerding();
bool CheckCrowd();
bool CheckSpread();

// A lumberjack sent at a standing tree: the felling stroke with no wood cut,
// then the tree lying as its felled graphic, then wood cut from it.
// Prints "felling=".
bool CheckFelling();

// What the interface notifies the player of and the simulation has to tell
// it: a sheep claimed, a farm run out, a Wonder begun and seen by every
// player, production halted for want of houses, research finished at a
// building, Spies known for what it does, a building site found taken, a
// relic picked up. Prints "notices=".
bool CheckNotices();

// Foundations as the original lays them: no ground held, seen only by their
// side and nobody's target until begun; what placing runs into; the first
// begun of overlapping foundations standing and the other refunded; the
// footprint-only sight of a building going up; deleting's refunds; the dat's
// hill rules for the ground a building is placed on; and a dock's water and
// beach. Prints "foundations=".
bool CheckFoundations();

// What a player keeps of what it no longer sees: no building drawn that it
// never saw; a picture of one gone out of its sight, its alone, staying when
// the building is destroyed until its ground is seen; a picture of a mine used
// up unseen; the ground as it was where a farm was laid unseen. Prints "fog=".
bool CheckFog();

// A scenario's flag of a player's: seeing round itself, and drawn with a frame
// its graphic has. Prints "flag=".
bool CheckFlag();

// Spies' price for each enemy villager and the enemy sight it gives; none in a
// Death Match or Regicide game, where Treason marks the enemy Kings instead;
// and a computer player's spy, Treason when it has 400 gold over its escrow.
// Prints "spies=".
bool CheckSpies();

// Gaia's village taken by the first player to see it; its wild animals and
// relic carts not. Prints "capture=".
bool CheckCapture();

// The approach planner on its own, away from any worker using it.
// Prints "planner=".
bool CheckApproachPlanner();

// A crew raises a building and it is then demolished, watched throughout.
// Prints "building=".
bool CheckConstruction();

// A Town Center trains villagers: price, refusals, the step out of the door,
// the population limit, and cancelling. Prints "production=".
bool CheckProduction();

// Technologies from the dat: civ bonuses and tech trees at the start, an age
// waiting on its buildings, research paid and timed, upgrades in place, and
// effects reaching units already in the field. Prints "techs=".
bool CheckTechs();

// Fighting by the dat's rules: the damage formula, reach measured between the
// dat's boxes, a duel to the death, an
// archer's arrows in flight, a tower shooting by itself, stand ground, a
// hunter killing a deer and gathering it, and a boar answering. Prints
// "combat=".
bool CheckCombat();

// Fog of war per player: each sees its own base and not the other's, ground a
// scout passes stays explored, an enemy building found is shown in the fog by
// the picture kept of it and an enemy unit not at all, and "all visible" is.
// Prints "vision=".
bool CheckVision();

// Sheltering in buildings: going in, refusals by kind and room, garrison
// arrows, healing, turning out, the town bell, a garrison outliving its
// building, and the info panel telling the count inside for our own only.
// Prints "garrison=".
bool CheckGarrison();

// Animals by their task lists: herdables changing hands, prey fleeing, the
// wild grazing. Prints "animals=".
bool CheckAnimals();

// Standing orders: patrol, follow and guard. Prints "duties=".
bool CheckDuties();

// Locked formations: a group kept in its formation wherever one of it is
// sent, its button lit and Disband Formation offered, another formation for
// some of it, Disband, and a member lost. Prints "formations=".
bool CheckFormations();

// Monks: conversion and its timing, faith, buildings, healing, and facing
// whom they convert. Prints "monks=".
bool CheckMonks();

// The land pass of the random map scripts: islands, continents, beaches,
// starts on land, fish in water, cliffs that join. Prints "maps=".
bool CheckMaps();

// Whether a world's cliffs join: each piece sits at its own place in its 3x3
// cell, and every link is met by the next cell's piece linking back the same
// way, in the dat's frame turned onto the grid. Null when they do, else what is
// wrong. Used by maps= and scenario=.
const char* CliffsJoin(ECS::Simulation& sim);

// The computer playing both seats at its hardest: town, the Feudal Age by
// its threshold, army and a fight, and a twin game identical. Prints "ai=".
bool CheckAI();

// The computer players' rule language on its own: the reader (conditional
// loading, load, load-random, constants, errors), passes (rule order,
// disable-self, timers, logic, defaults, wildcards), every shipped AI file
// loading under every civilisation, difficulty and map, the words bound to the
// dat, and facts and actions bound to a world. Prints "script=".
bool CheckScript();

// Each difficulty's pace, one computer against an idle human seat: hard and
// moderate in the Feudal Age by their thresholds; easy and easiest never
// before the human, and soon after. Prints "pace=".
bool CheckPace();

// Seven computer players and a human at one table: every brain loaded, every
// town grown in three minutes. Prints "seven=".
bool CheckSeven();

// A computer player's attack across the water: on Islands, attack-now with
// nothing of the enemy's to walk to -- the group boards a transport, is
// landed on the enemy's island and strikes there. Prints "crossing=".
bool CheckCrossing();

// Two machines in lockstep over a loopback socket: orders carried out on
// both, worlds identical, tampering caught. Prints "net=".
bool CheckNet();

// A network game's lobby over a loopback socket: the game found, a client
// seated, rows, ready checks and chat on both machines, a refused start, a
// row given back, and the game started from the table in step. Prints
// "lobby=".
bool CheckLobby();

// The standard victory: conquest, a Wonder, the relics. Prints "victory=".
bool CheckVictory();

// Water as its own ground: the sea's own passability layer and regions, a
// ship routed round an island, ships trained at a dock and launched on the
// water side, a dock placed only where the dat lets one stand. Prints
// "water=".
bool CheckWater();

// A fishing ship trained at a Dock on the shore: to the fish, a load at the
// dat's rate, home to the Dock as food; a fish trap built on the water,
// holding the civ's fish trap food and worked at its own rate. Prints
// "fishing=".
bool CheckFishing();

// The warships and the Dock's technologies: what a Castle Age dock trains, a
// galley sinking a fishing ship, a fire ship burning a galley, a demolition
// ship's detonation and blast, Careening. Prints "navy=".
bool CheckNavy();
bool CheckShipAngles();
bool CheckTurning();
// A computer player never plays in a person's colour: it takes the lowest
// colour nobody chose. Prints "colours=".
bool CheckColours();
// The command buttons with the original's hotkeys: a Monk's Convert and
// Heal, a loaded transport's Unload, a building's Set Gather Point, a
// trebuchet's Pack and Unpack. Prints "buttons=".
bool CheckButtons();
// What a unit picks a fight with on sight: a wolf a villager, never a
// building, a ram, a Monk or a Trade Cart; a soldier a wolf only when the
// computer plays it. Prints "search=".
bool CheckSearch();
// How near a wolf lets people come before it goes for them, by difficulty.
// Prints "hunt=".
bool CheckHunt();
// What a villager at work does when struck: fights off a wolf, runs from a
// soldier, goes back to work after; help from the idle beside it. Prints
// "answer=".
bool CheckAnswer();
bool CheckPocket();
// A soldier sent into a clearing walled in by trees goes to the trees' edge.
// Prints "clearing=".
bool CheckClearing();
// A soldier sent past an enemy archer that shoots at it walks on to where it
// was sent. Prints "passing=".
bool CheckPassing();
// Soldiers set on an enemy that falls before they reach it carry on to where
// it fell. Prints "carryon=".
bool CheckCarryOn();
// A route across the tile a unit stands on, someone standing in the straight
// way, is found. Prints "step=".
bool CheckStep();
// A lumberjack whose tree runs out goes on to the nearest it can come up to,
// not a nearer one walled in. Prints "walledtree=".
bool CheckWalledTree();
// A hundred soldiers set on one enemy all have their routes the tick after
// the order, and all come up to it. Prints "setoff=".
bool CheckSetOff();
// A route to a spot inside a crowd standing there goes straight in without
// searching far for a way round. Prints "crowdgoal=".
bool CheckCrowdGoal();
// A hundred soldiers sent to one place in one tick share their routes.
// Prints "sharedwalk=".
bool CheckSharedWalk();
// An army's chases plan again over several ticks, not all in one. Prints
// "replanspread=".
bool CheckReplanSpread();
// Many graphics' art shares a page or two, and a villager drawn from its page
// is its SLP frame in its player's colours, before and after the page grows.
// Prints "pages=".
bool CheckPages();
// A soldier struck down leaves the minimap as it falls. Prints
// "minimapdead=".
bool CheckMinimapDead();
// A command button's rollover help ends with its hotkey. Prints "help=".
bool CheckHelp();
// Two neighbouring chunks of ground halved for the view zoomed far out still
// meet with no gap between them, a pixel out of place, and keep every pixel a
// plain shrink keeps. Prints "halve=".
bool CheckHalve();
// The rollover help's box is as tall as its lines, on the same bottom.
// Prints "helpbox=".
bool CheckHelpBox();
// A selected thing's outline and hit point bar still show with the view
// zoomed far out. Prints "marks=".
bool CheckMarks();
// Art and interface graphics too tall for a small renderer's textures still
// draw as their SLPs hold them. Prints "smalltextures=".
bool CheckSmallTextures();
// A trebuchet shows its silhouette behind a Castle, not in the open.
// Prints "outline=".
bool CheckOutline();
// The pointer over a mine's foot shows a villager's hand zoomed out.
// Prints "cursor=".
bool CheckCursor();
// Black covers the map's unexplored edge and past it, zoomed out. Prints
// "fogedge=".
bool CheckFogEdge();
// Militia ordered at three selected Barracks, one a foundation, go one to
// each finished one in turn until both are full. Prints "queuesplit=".
bool CheckQueueSplit();
// The production overview lists what is being made, then what waits, by
// kind; a click goes round the buildings making an entry; it shows only with
// its option on. Prints "queueoverview=".
bool CheckQueueOverview();
// A tile draws its terrain's own pattern cell for its place, its terrain
// changed or not. Prints "terraincell=".
bool CheckTerrainCell();
// Scroll Speed, Allow Audio Taunts and the mouse interface act as the
// Options say. Prints "options=".
bool CheckOptions();
// Random maps' connections join every start to every other by land.
// Prints "connections=".
bool CheckConnections();
// A builder that breaks off for a fight, or a repairer for the town bell,
// goes back to that building. Prints "backtowork=".
bool CheckBackToWork();
// A building destroyed with nowhere round it to step out: its garrison
// stands on the ground it held. Prints "garrisonfall=".
bool CheckGarrisonFall();
// A converted unit's body lies in its new owner's colour. Prints
// "corpsecolour=".
bool CheckCorpseColour();
// Each player's Wonder counts its own years; the relics' count goes on
// between allies. Prints "wondercount=".
bool CheckWonderCount();
// The cheats left on (aegis, natural wonders) come back with a saved game.
// Prints "savecheats=".
bool CheckSaveCheats();
// Repairs and "black death" follow the players' stances, not the lobby's
// teams. Prints "stanceside=".
bool CheckStanceSide();
// A gate is placed only on explored ground, never over a foundation of its
// own side. Prints "gateplace=".
bool CheckGatePlace();
// A Farm is worked only once built and only by its owner; a right-click on
// another's strikes it. Prints "farmorder=".
bool CheckFarmOrder();
// The idle military button never finds a unit on a standing order. Prints
// "idlemilitary=".
bool CheckIdleMilitary();
// A scenario of an older version written again is labelled the version
// written, 1.18. Prints "scenarioversion=".
bool CheckScenarioVersion();
// A load is taken to a finished drop site, never to a foundation. Prints
// "unfinisheddrop=".
bool CheckUnfinishedDrop();
// A farmer works standing on its Farm's field, at one spot of it after
// another, gathering as it steps between them. Prints "farmfield=".
bool CheckFarmField();
// A fish trap run out leaves its dead unit, which a Fishing Ship builds over.
// Prints "deadtrap=".
bool CheckDeadTrap();
// A stray arrow hurts an enemy and never an ally. Prints "strayarrow=".
bool CheckStrayArrow();
// A scenario's Score, Time Limit and Custom victories are played as they
// say. Prints "scenariovictory=".
bool CheckScenarioVictory();
// A scenario's Use Advanced Buttons turns the advanced commands on, and its
// Play Sound with no file plays its dat sound. Prints "advancedbuttons=".
bool CheckAdvancedButtons();
// The lobby's Time and Score victories: kept through the setup's encoding and
// played to. Prints "lobbyvictory=".
bool CheckLobbyVictory();
// A computer player takes a blow as in its town within its town's size and
// four tiles. Prints "townstruck=".
bool CheckTownStruck();
// Every map in the lobby's Map Type list finds its script. Prints
// "mapscripts=".
bool CheckMapScripts();
// Every choice of a long drop-down list can be clicked. Prints
// "dropdownrows=".
bool CheckDropDownRows();
// A blow in a computer player's town is answered by its soldiers that are
// idle or fighting of their own accord, not by those it sent elsewhere.
// Prints "answerdraft=".
bool CheckAnswerDraft();
// A villager with no way to any drop site stands with its load. Prints
// "dropoffbeyond=".
bool CheckDropoffBeyond();
// Every object the editor offers or a CD scenario places draws something, for
// every owner, civilisation and age. Prints "objectart=".
bool CheckObjectArt();
// A used-up tree's stump lies for the dat's decay time, its tile open.
// Prints "stumps=".
bool CheckStumps();
// On every random map, every tile of ground that carries trees has its tree,
// and no tree stands where land units could not walk once it is gone.
// Prints "forests=".
bool CheckForests();
// A building can be laid over a stump, which it clears, but not over a
// felled tree still holding wood. Prints "buildstump=".
bool CheckBuildOverStump();
// A tree placed as a scenario places it, felled, draws as the felled trunk.
// Prints "felledplaced=".
bool CheckFelledPlaced();
// Stumps and bodies are drawn on the ground, under who walks there; villagers
// and trees stand. Prints "groundlayer=".
bool CheckGroundLayer();
// A Town Center keeps units off its back alone; a villager sent onto the
// rest gets there, and nothing is built on any of it. Prints "tcground=".
bool CheckTownCenterGround();
// A new map's hawks fly about it, drawn up at their height, flapping and
// gliding by turns. Prints "hawks=".
bool CheckHawks();
// A boar's carcass is shown in the info panel as the boar it was, with its
// food. Prints "carcass=".
bool CheckCarcassPanel();
// A boar's carcass lies as the boar fell while it holds food, then leaves its
// remains, rotting, for the dat's decay time; a sheep's leaves none.
// Prints "carcassart=".
bool CheckCarcassArt();
// A computer player's scout set on two wolves in its town: every swing it
// begins at one wounds it. Prints "wolves=".
bool CheckWolves();

// A computer player's boats on Islands: a fishing ship keeps to fish within
// sn-maximum-fish-boat-drop-distance of a Dock, the warship the boat attack
// groups leave over explores the water, and boat attack groups attack an
// enemy known or explore. Prints "boats=".
bool CheckBoats();

// A computer player's attack groups as the game runs them: made, filled,
// gathered and sent without attack-now once the enemy is known, none while
// it is not, none with sn-number-attack-groups 0, and none before the initial
// attack delay; attack-soldier-count counting a group still at home. Prints
// "attackgroups=".
bool CheckAttackGroups();

// The game's target evaluation, which a computer player's attack group goes
// for first among the enemy's buildings it knows: a barracks before a house
// scored alike, a house before a wall, the best scored of three barracks, and
// a Monastery before them with sn-special-attack-type1. Prints "targets=".
bool CheckTargets();

// The view's zoom (ours, not the original's): a step keeps the point under
// the pointer where it is, the zoom stays within its limits, and a pinch
// zooms the view at once. Prints "zoom=".
bool CheckZoom();

// The selection limit (the original's forty, off by default): a box round
// sixty of the player's units selects them all, or forty with the limit on.
// Prints "selection=".
bool CheckSelection();

// Soldiers keep their room: a group sent over open ground keeps its width,
// none over another; through a town it squeezes but does not stack; twenty at
// one enemy stand round it. Prints "march=".
bool CheckMarch();

// The fight as it feels: archers set at one enemy together loose over a
// spread of ticks, and an aggressive unit helps one of its side struck within
// its sight, where a defensive one helps only within three tiles. Prints
// "aggression=".
bool CheckAggression();

// Villagers do not stand short of their places: four computer players for ten
// minutes on Arabia and on Islands, their villagers standing still on their
// way for ten seconds or more for only a few seconds in all. Prints
// "walkers=".
bool CheckWalkers();

// The population limits the game setup offers, from 25 to 1000: the
// original's among them, and a game at the largest supporting more than 200.
// Prints "population=".
bool CheckPopulation();

// A late game measured: eight computer players on a giant map in the
// Imperial Age, their armies and fleets sent at one another, a minute's
// ticks timed system by system (core/Costs). Prints "stress=" with the
// costs: each system's average microseconds a tick and its worst.
bool CheckStress();

// A landing on Islands: a transport takes on a war party under the dat's
// garrison rules, sails it to the other island and puts it ashore, and the
// party's assault ends the game in conquest; a transport sunk with a soldier
// aboard takes him with it. Prints "landing=".
bool CheckLanding();

// The Market: the opening prices, a lot sold and bought at the price on its
// button, the prices moving for every player, refusals that change nothing,
// several lots in one order, the floor, and Guilds. Prints "market=".
bool CheckMarket();

// Trade: who may trade where, a trade cart's round trips between Markets
// paid by the trade formula, the full cart, a partner and a home lost, a
// cart rallied onto a foreign Market, a trade cog between Docks. Prints
// "trade=".
bool CheckTrade();

// Tribute: the Market it needs, the fee on top, Coinage and Banking, the
// refusals, and teams locked to allies only. Prints "tribute=".
bool CheckTribute();

// Diplomacy: the lobby's stances, team bonuses and Lock Teams; stances
// changed in play, and told only when they change; targeting that follows
// them; Cartography's shared sight; allied victory. Prints "diplomacy=".
bool CheckDiplomacy();

// Chat and flares as orders: who hears a message, taunts, refusals, Lock
// Teams, and who sees a flare and for how long. Prints "chat=".
bool CheckChat();
// Walls and gates: a dragged line laid as foundations at the dat's price, each
// segment the piece its neighbours choose, a tower joining a wall, one
// villager raising a whole line, a Gate turning to its wall and replacing it,
// going up as its site unit -- that unit's scaffold, shadow and time -- open
// to its owner and ally and shut to the enemy, and locked, to all.
// Prints "walls=".
bool CheckWalls();

// Repairs: a Barracks mended at the repairer's rate and charged half its cost
// over its hit points, a crew faster, a trebuchet at a quarter pace, a repair
// stopping when the wood runs out, no repair of an enemy's or of a ram.
// Prints "repair=".
bool CheckRepair();

// Trebuchets packing and unpacking: setting up still and taking the packing
// time, armed set up and unable to move, packed and moving, a stop leaving
// it as it was, and sent at a building out of range, closing, setting up in
// range and shooting; their icons from the units' sheet; and placed as units
// from a scenario or the editor. Prints "packing=".
bool CheckPacking();

// A converted unit keeps its maker's technology: its maker's Forging, not its
// new owner's Scale Mail but its maker's later one, its maker's line upgrade.
// Prints "converted=".
bool CheckConversion();

// The lobby's games and options: Regicide's start and its defeat, Death
// Match's stockpiles, the population limit, the map revealed, the starting
// age, All Techs. Prints "modes=".
bool CheckModes();

// The cheat codes: recognised from chat, refused without the lobby's leave,
// and each doing what it does. Prints "cheats=".
bool CheckCheats();

// The score: each scoring element's figure at the
// moment its event happens, the Achievements' statistics, the map explored
// once a second, the team figure, and a save carrying it all. Prints
// "score=".
bool CheckScore();

// Runs every scenario. Returns a process exit status: 0 when all passed.
int Run(int ticks);

// A game saved part way through and loaded into a fresh world runs on as the
// one that never stopped, and a damaged save is refused. Prints "save=".
bool CheckSave();

// A recorded game played back from its file is the game recorded at every
// digest it noted. Prints "recording=".
bool CheckRecording();

// The shipped scenarios and campaigns: all 32 read whole, DEMO.SCN's and
// Joan of Arc's first scenario's facts as the files state them, their worlds
// built as the files lay them out, triggers firing on their conditions with
// their effects done, a scenario game saved and loaded, and the campaign
// progress record. Prints "scenario=".
bool CheckScenario();

// Waypoints: three laid at once walked in order and the route gone at its
// end; a move part way along forgetting the rest; a group keeping its
// formation at each point. Prints "waypoints=".
bool CheckWaypoints();

// The scenario writer: every one of the disc's 32 scenarios read, written and
// read again is the same file, field by field and, inflated, byte by byte;
// an editor's changes survive a write; a new file reads; its view zooms about
// a point. Prints "editor=".
bool CheckEditor();

} // namespace Verify
