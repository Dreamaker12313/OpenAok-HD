#include "ecs/Resources.h"

#include "core/ConfigManager.h"
#include "core/Rules.h"
#include "ecs/Buildings.h"
#include "ecs/Events.h"
#include "ecs/Fog.h"
#include "ecs/Mortality.h"
#include "ecs/Players.h"
#include "ecs/components/Building.h"
#include "ecs/components/Identity.h"
#include "ecs/components/Mortal.h"
#include "ecs/components/Owner.h"
#include "ecs/components/Sprite.h"
#include "ecs/components/Transform.h"

namespace ECS::Resources {

namespace {

namespace R = Core::Rules;

// The dat's type of a Mill; a farm reseeds itself only beside one of its
// owner's, as The Conquerors' farms do.
constexpr int kMillType = 80;

int WoodCost(const R::UnitRules& rules) {
    for (int i = 0; i < rules.cost_count; ++i) {
        if (rules.costs[i].resource == R::Res::Wood && rules.costs[i].paid) {
            return rules.costs[i].amount;
        }
    }
    return 0;
}

bool HasMill(const entt::registry& registry, Core::PlayerId owner) {
    auto mills = registry.view<const Components::Building, const Components::Identity,
                               const Components::Owner>();
    for (auto mill : mills) {
        if (mills.get<const Components::Owner>(mill).player_id != owner) continue;
        if (mills.get<const Components::Building>(mill).state !=
            Components::BuildingState::Complete) {
            continue;
        }
        const R::UnitRules* rules =
            Players::UnitOf(registry, owner, mills.get<const Components::Identity>(mill).unit_id);
        if (rules != nullptr && rules->type == kMillType) return true;
    }
    return false;
}

// The Conquerors: an exhausted farm beside a Mill reseeds itself for its wood,
// without a villager going back to it. The farm is put back complete, over its
// harvested-out field.
bool Reseed(entt::registry& registry, Physics::Grid& grid, entt::entity farm,
            Core::PlayerId owner, int unit_id, Components::Vector2D at) {
    const R::UnitRules* rules = Players::UnitOf(registry, owner, unit_id);
    if (rules == nullptr || !Buildings::LaysCrop(*rules)) return false;
    Players::Player* player = Players::Find(registry, owner);
    if (player == nullptr || !HasMill(registry, owner)) return false;
    const int wood = WoodCost(*rules);
    if (wood > 0 && Players::Resource(*player, R::Res::Wood) < Core::Fixed32(wood)) return false;
    const int tile_x = Physics::TileOf(at.x);
    const int tile_y = Physics::TileOf(at.y);
    Buildings::Destroy(registry, grid, farm);
    const entt::entity again = Buildings::Place(registry, grid, unit_id, owner, tile_x, tile_y, true);
    if (again == entt::null) return false;
    if (wood > 0) Players::AddResource(*player, R::Res::Wood, Core::Fixed32(0) - Core::Fixed32(wood));
    return true;
}

} // namespace

void Exhaust(entt::registry& registry, Physics::Grid& grid, entt::entity resource) {
    if (!registry.valid(resource)) return;

    // A farm is a building: its own teardown handles its art, its owner's
    // books and its ground.
    if (registry.all_of<Components::Building>(resource)) {
        const auto* owner = registry.try_get<Components::Owner>(resource);
        const auto* identity = registry.try_get<Components::Identity>(resource);
        const auto* at = registry.try_get<Components::Transform>(resource);
        const Core::PlayerId player = owner != nullptr ? owner->player_id : Core::PLAYER_GAIA;
        const int unit_id = identity != nullptr ? identity->unit_id : -1;
        const Components::Vector2D position = at != nullptr ? at->position : Components::Vector2D{};
        Events::Emit(registry, {.kind = Events::Kind::Exhausted, .subject = resource,
                                .player = player, .id = unit_id, .at = position});
        // A farm that is not Gaia's, and still one of its owner's buildings,
        // reseeds itself from the Mill the way The Conquerors' does.
        const bool standing = registry.all_of<Components::Building>(resource) &&
            registry.get<Components::Building>(resource).state ==
                Components::BuildingState::Complete;
        if (standing && player != Core::PLAYER_GAIA && unit_id >= 0 &&
            Reseed(registry, grid, resource, player, unit_id, position)) {
            return;
        }
        Buildings::Destroy(registry, grid, resource);
        return;
    }

    // Who does not see it go keeps it as it was.
    Fog::Going(registry, resource);
    // A carcass gathered out leaves its body.
    if (const auto* corpse = registry.try_get<Components::Corpse>(resource); corpse != nullptr && corpse->was >= 0) {
        Mortality::Spent(registry, resource);
        registry.destroy(resource);
        return;
    }
    if (const auto* at = registry.try_get<Components::Transform>(resource)) {
        const auto position = at->position;
        const int x = Physics::TileOf(position.x);
        const int y = Physics::TileOf(position.y);
        // A map object blocks the tile it stands on; its remains do not.
        grid.SetWalkable(x, y, true);

        // What it leaves behind, if the dat names anything.
        if (const auto* identity = registry.try_get<Components::Identity>(resource)) {
            const Core::Rules::UnitRules* rules = Core::Rules::Unit(identity->unit_id);
            auto& cfg = Core::ConfigManager::Get();
            const auto remains = rules != nullptr ? cfg.GetObjectArt(rules->dead_unit)
                                                  : Core::ConfigManager::ObjectArt{};
            if (remains.Valid()) {
                const entt::entity stump = registry.create();
                registry.emplace<Components::Transform>(stump, position, position);
                Components::Sprite sprite{};
                sprite.slp_id = remains.slp_id;
                sprite.slp_frame = 0;
                sprite.width = 0;
                sprite.height = 0;
                registry.emplace<Components::Sprite>(stump, std::move(sprite));
                // It lies for the dat's decay time (a stump three minutes),
                // then is gone.
                const Core::Rules::UnitRules* stump_rules = Core::Rules::Unit(rules->dead_unit);
                const int32_t lies = stump_rules != nullptr ? Mortality::DecayMs(*stump_rules) : 0;
                if (lies > 0) {
                    registry.emplace<Components::Corpse>(
                        stump, Components::Corpse{.remaining_ms = lies, .remains = rules->dead_unit});
                }
            }
        }
    }
    registry.destroy(resource);
}

} // namespace ECS::Resources
