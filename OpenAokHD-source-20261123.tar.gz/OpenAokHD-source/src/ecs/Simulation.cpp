#include "Simulation.h"
#include <fstream>

#include <algorithm>
#include <iostream>

#include "ai/Brain.h"
#include "core/CommandQueue.h"
#include "core/Costs.h"
#include "pathfinding/Pathfinder.h"
#include "core/ConfigManager.h"
#include "core/MapGenerator.h"
#include "core/RMSParser.h"
#include "core/Random.h"
#include "core/Rules.h"
#include "core/Types.h"
#include "ecs/Allegiance.h"
#include "ecs/Fog.h"
#include "ecs/Animals.h"
#include "ecs/Buildings.h"
#include "ecs/Duties.h"
#include "ecs/Monks.h"
#include "ecs/Relics.h"
#include "ecs/Spies.h"
#include "ecs/Events.h"
#include "ecs/Chat.h"
#include "ecs/Diplomacy.h"
#include "ecs/Flares.h"
#include "ecs/Garrisons.h"
#include "ecs/Market.h"
#include "ecs/Orders.h"
#include "ecs/Packing.h"
#include "ecs/Players.h"
#include "ecs/Production.h"
#include "ecs/Score.h"
#include "ecs/Techs.h"
#include "ecs/Trade.h"
#include "ecs/Triggers.h"
#include "ecs/Units.h"
#include "ecs/Victory.h"
#include "ecs/Vision.h"
#include "ecs/Walls.h"
#include "ecs/BuildingGeometry.h"
#include "ecs/components/Identity.h"
#include "ecs/components/Sight.h"
#include "ecs/components/Transform.h"
#include "pathfinding/ApproachPlanner.h"
#include "hal/GraphicCache.h"
#include "ecs/Combat.h"
#include "ecs/Missiles.h"
#include "ecs/Mortality.h"
#include "systems/AnimationSystem.h"
#include "ecs/Navigation.h"
#include "systems/MovementSystem.h"
#include "systems/WorkerSystem.h"

namespace ECS {

namespace {

// Which way each starting villager stands from the Town Center: spread round
// it rather than bunched at one door, the first three on the faces a player
// sees. Further villagers -- a civ bonus can give more -- cycle round again.
constexpr int kStartBearings = 4;
constexpr int kStartBearingX[kStartBearings] = {-1, 1, 1, -1};
constexpr int kStartBearingY[kStartBearings] = { 1, 1, -1, -1};

// Where a Regicide game's Castle goes: the nearest spot it may stand on, from
// this many tiles out from the Town Center's middle -- clear of the town's
// own doorstep -- to this many.
constexpr int kCastleRing = 7;
constexpr int kCastleReach = 16;
// Defend the Wonder: the Wonder stands further out than a Castle, so its
// bigger footprint finds open ground.
constexpr int kWonderRing = 8;
constexpr int kWonderReach = 32;

// How far out from the Town Center's wall a starting unit stands.
const Core::Fixed32 kStartStandoff = Core::Fixed32(3) / Core::Fixed32(2);
const Core::Fixed32 kStartClearance = Core::Fixed32(55) / Core::Fixed32(100);

// A player's starting units: the Town Center, its villagers and the scout.
void SpawnStartingUnits(entt::registry& registry, Physics::Grid& grid,
                        const Core::GameSetup& setup, Core::PlayerId player,
                        int cx, int cy) {
    auto& cfg = Core::ConfigManager::Get();
    const entt::entity tc = Buildings::Place(
        registry, grid, cfg.GetUnitIdByName(setup.starting_town_center), player,
        cx, cy, true);

    const Players::Player* seat = Players::Find(registry, player);
    const int villagers = seat != nullptr
        ? Players::Resource(*seat, Core::Rules::Res::StartingVillagers).ToInt() : 3;
    // Where each stands is asked of the approach planner, from a bearing round
    // the Town Center: a point beside its wall, at whatever sub-tile offset the
    // ground allows, clear of the villagers already placed.
    const auto ground = Buildings::FootprintBounds(
        registry.get<Components::Transform>(tc).position,
        registry.get<Components::Identity>(tc).unit_id);
    std::vector<Components::Vector2D> placed;
    for (int i = 0; i < villagers; ++i) {
        // Starting villagers alternate men and women; each is a separate base
        // unit with its own graphics.
        const int unit_id = cfg.GetUnitIdByName((i % 2 == 0) ? "VMBAS" : "VFBAS");
        const int b = i % kStartBearings;
        Pathfinding::ApproachRequest ask;
        ask.target = ground;
        ask.from = {Core::Fixed32(cx + kStartBearingX[b] * 8) + Core::Fixed32(i),
                    Core::Fixed32(cy + kStartBearingY[b] * 8)};
        ask.standoff = kStartStandoff;
        ask.clearance = kStartClearance;
        ask.taken = placed.empty() ? nullptr : placed.data();
        ask.taken_count = placed.size();
        const auto spot = Pathfinding::FindStandingSpot(grid, ask);
        if (!spot.found) continue;
        placed.push_back(spot.spot);
        Units::Spawn(registry, unit_id, player, spot.spot);
    }

    if (setup.starting_scout != nullptr) {
        Components::Vector2D at{};
        if (Buildings::Doorstep(registry, grid, tc, at)) {
            Units::Spawn(registry, cfg.GetUnitIdByName(setup.starting_scout), player, at);
        }
    }

    // Regicide: every player also starts with a King and a Castle; the
    // villagers are the civ's own starting number.
    if (setup.regicide) {
        const int castle = cfg.GetUnitIdByName(setup.regicide_castle);
        // The nearest spot to the Town Center a Castle may stand on, ring by
        // ring from a little way out, in a fixed order.
        bool built = false;
        for (int r = kCastleRing; r <= kCastleReach && !built; ++r) {
            for (int dy = -r; dy <= r && !built; ++dy) {
                for (int dx = -r; dx <= r && !built; ++dx) {
                    if (std::abs(dx) != r && std::abs(dy) != r) continue;
                    if (!Buildings::CanPlace(grid, castle, cx + dx, cy + dy)) continue;
                    Buildings::Place(registry, grid, castle, player, cx + dx, cy + dy, true);
                    built = true;
                }
            }
        }
        Components::Vector2D at{};
        if (Buildings::Doorstep(registry, grid, tc, at)) {
            Units::Spawn(registry, cfg.GetUnitIdByName(setup.regicide_king), player, at);
        }
    }

    // Defend the Wonder: every player starts with a finished Wonder.
    if (setup.defend_wonder) {
        const int wonder = cfg.GetUnitIdByName("WNDR");
        bool built = false;
        for (int r = kWonderRing; r <= kWonderReach && !built; ++r) {
            for (int dy = -r; dy <= r && !built; ++dy) {
                for (int dx = -r; dx <= r && !built; ++dx) {
                    if (std::abs(dx) != r && std::abs(dy) != r) continue;
                    if (!Buildings::CanPlace(grid, wonder, cx + dx, cy + dy)) continue;
                    Buildings::Place(registry, grid, wonder, player, cx + dx, cy + dy, true);
                    built = true;
                }
            }
        }
    }
}

// King of the Hill: the monument on the map's middle, neutral, for the sides
// to fight over. Placed before anything else, so a starting town never covers
// it.
void SpawnHill(entt::registry& registry, Physics::Grid& grid) {
    const int unit_id = Core::ConfigManager::Get().GetUnitIdByName("KOH-FLAG");
    if (unit_id < 0) return;
    const int cx = grid.GetWidth() / 2;
    const int cy = grid.GetHeight() / 2;
    for (int r = 0; r <= 24; ++r) {
        for (int dy = -r; dy <= r; ++dy) {
            for (int dx = -r; dx <= r; ++dx) {
                if (r > 0 && std::abs(dx) != r && std::abs(dy) != r) continue;
                if (!Buildings::CanPlace(grid, unit_id, cx + dx, cy + dy)) continue;
                if (Buildings::Place(registry, grid, unit_id, Core::PLAYER_GAIA,
                                     cx + dx, cy + dy, true) != entt::null) {
                    return;
                }
            }
        }
    }
    std::cerr << "[Simulation] King of the Hill found no ground for the monument." << std::endl;
}

} // namespace

void Simulation::Init(const Core::GameSetup& game) {
    setup = game;
    // A random map game's computer players take the colours nobody chose; a
    // scenario's seats keep the file's.
    if (setup.scenario.empty()) Core::SettleColours(setup);
    // The lobby, for whoever needs its choices later -- the interface prints
    // the players' names from it. Never part of the world's digest.
    registry.ctx().insert_or_assign(setup);

    // The simulation's own random numbers, kept in the registry as world state
    // so any system can roll without a hidden global -- and so every machine
    // in a lockstep game rolls the same, from the same seed. Offset from the
    // map seed so drawing from one never shifts the other.
    registry.ctx().emplace<Core::Random>(
        static_cast<uint64_t>(setup.seed) ^ 0x9E3779B97F4A7C15ull);
    registry.ctx().insert_or_assign(
        Combat::HuntRandom{Core::Random(static_cast<uint64_t>(setup.seed) ^ 0xC2B2AE3D27D4EB4Full)});

    // Every seat's table, then the technologies each starts with -- its civ's
    // tech tree and bonuses, and the starting age -- before anything is placed,
    // so the starting units are made from the rules the player actually has.
    Players::Setup(registry, setup);
    Events::Setup(registry);
    Market::Setup(registry);
    Diplomacy::Setup(registry, setup);
    Chat::Setup(registry);
    Flares::Setup(registry);
    Fog::Setup(registry);
    AI::Setup(registry, setup);
    Victory::Setup(registry, setup);
    // Before the starting age is researched and anything placed: the score
    // counts both (ecs/Score).
    Score::Setup(registry);
    for (int seat = 1; seat < Core::kMaxPlayers; ++seat) {
        if (setup.players[seat].active) {
            // A scenario's seat has an age of its own.
            const int own = setup.players[seat].starting_age;
            Techs::Start(registry, static_cast<Core::PlayerId>(seat),
                         own >= 0 ? std::min(own, 3) : setup.starting_age,
                         setup.all_techs);
        }
    }
    // Spies is not to be had in Regicide or Death Match.
    Spies::Setup(registry, setup);
    Diplomacy::ApplyTeamBonuses(registry, setup);

    // A scenario's world is its file's, not a script's.
    if (!setup.scenario.empty()) {
        InitScenario();
        AI::UseScenario(registry, setup);
        // The history's first reading, of the scenario's own units.
        Score::Start(registry);
        return;
    }

    std::vector<Core::PlayerId> seats;
    for (int seat = 1; seat < Core::kMaxPlayers; ++seat) {
        if (setup.players[seat].active) seats.push_back(static_cast<Core::PlayerId>(seat));
    }

    Core::MapGenConfig map_cfg;
    // The lobby's map size, and the label the script sees for it.
    grid.Resize(setup.map_size, setup.map_size);
    map_cfg.width = setup.map_size;
    map_cfg.height = setup.map_size;
    std::vector<std::string> labels;
    for (const Core::MapSize& size : Core::kMapSizes) {
        if (size.tiles == setup.map_size) labels.emplace_back(size.script_label);
    }
    map_cfg.num_players = static_cast<int>(seats.size());
    for (Core::PlayerId seat : seats) {
        map_cfg.players.push_back(seat);
        map_cfg.teams.push_back(setup.players[seat].team);
    }

    // Maps come from the random map scripts held in gamedata.drs; the
    // built-in generator stands in when the archive is missing.
    auto& cfg = Core::ConfigManager::Get();
    auto& archives = HAL::GraphicCache::Get();
    std::string script_text;
    const uint32_t script_id = cfg.RmsScriptId(setup.map_script);
    bool from_script = false;
    if (script_id != 0 && archives.ReadGameDataText(script_id, script_text)) {
        from_script = true;
    } else {
        // The HD data ships its extra scripts loose beside the game data.
        std::ifstream loose("../assets/original/random-map-scripts/" + setup.map_script + ".rms");
        if (loose) {
            script_text.assign(std::istreambuf_iterator<char>(loose), std::istreambuf_iterator<char>());
            from_script = !script_text.empty();
        }
    }
    if (from_script) {
        const Core::RMSScript script = Core::RMSParser::Parse(
            script_text, setup.seed,
            [](uint32_t file_id, std::string& out) {
                return HAL::GraphicCache::Get().ReadGameDataText(file_id, out);
            },
            setup.map_script, labels);
        player_starts = Core::MapGenerator::GenerateFromScript(
            grid, registry, setup.seed, script, map_cfg);
    } else {
        std::cerr << "[Simulation] Map script \"" << setup.map_script
                  << "\" unavailable; using the built-in generator." << std::endl;
        player_starts = Core::MapGenerator::GenerateProcedural(
            grid, registry, setup.seed, map_cfg);
    }
    if (setup.king_of_the_hill) SpawnHill(registry, grid);

    Vision::Setup(registry, grid.GetWidth(), grid.GetHeight(), setup.reveal);
    // Whose gates open for whom: to begin with, each player's team-mates.
    Walls::SetAllies(registry, grid);
    for (size_t i = 0; i < player_starts.size() && i < seats.size(); ++i) {
        SpawnStartingUnits(registry, grid, setup, seats[i],
                           player_starts[i].first, player_starts[i].second);
    }

    // Allied Town Centers are visible from the start: each team-mate's start
    // is explored as far as its Town Center sees.
    for (size_t i = 0; i < player_starts.size() && i < seats.size(); ++i) {
        const Core::TeamId team = setup.players[seats[i]].team;
        if (team == 0) continue;
        const auto* tc = Players::UnitOf(registry, seats[i],
                                         cfg.GetUnitIdByName(setup.starting_town_center));
        const int sight = tc != nullptr ? tc->los.ToInt() : 0;
        for (size_t j = 0; j < seats.size(); ++j) {
            if (j == i || setup.players[seats[j]].team != team) continue;
            Vision::Explore(registry, seats[j], player_starts[i].first,
                            player_starts[i].second, sight);
        }
    }
    CalculateVision();
    // The history's first reading, of the starting units (ecs/Timeline).
    Score::Start(registry);
    // The route search's landmarks, before the first tick.
    Pathfinding::Prepare(grid);
    std::cout << "[Simulation] World initialized." << std::endl;
}

void Simulation::Update(int32_t dt_ms) {
    Core::Costs::BeginTick();
    current_tick++;
    { Core::Costs::Scope cost(Core::Costs::Part::Other); Events::BeginTick(registry); }
    { Core::Costs::Scope cost(Core::Costs::Part::Other); Score::Advance(registry, dt_ms); }
    // Where everyone stands, before anything plans a route or takes a step.
    {
        Core::Costs::Scope cost(Core::Costs::Part::Navigation);
        Pathfinding::Prepare(grid);
        Navigation::Survey(registry, grid);
    }

    {
        Core::Costs::Scope cost(Core::Costs::Part::Orders);
        for (const auto& command : Core::CommandQueue::Get().PopAllCommands()) {
            Orders::Execute(registry, grid, command);
        }
    }
    // The computer players decide, through the same orders.
    { Core::Costs::Scope cost(Core::Costs::Part::AI); AI::Update(registry, grid, dt_ms); }
    // Whose gates open for whom, as the stances now stand.
    { Core::Costs::Scope cost(Core::Costs::Part::Walls); Walls::SetAllies(registry, grid); }

    // Cache previous positions for render interpolation, straight down the
    // storage's packed array.
    for (auto& transform : registry.storage<Components::Transform>()) {
        transform.previous_position = transform.position;
    }

    // Units at the end of a walk with waypoints left set off for the next.
    { Core::Costs::Scope cost(Core::Costs::Part::Movement); Orders::WalkOnToWaypoints(registry, grid); }
    // Siege engines setting up or packing, and packed ones closing on a
    // target, before anything moves.
    { Core::Costs::Scope cost(Core::Costs::Part::Movement); Packing::Update(registry, grid, dt_ms); }
    { Core::Costs::Scope cost(Core::Costs::Part::Movement); Systems::MovementSystem::Update(registry, grid, dt_ms); }
    { Core::Costs::Scope cost(Core::Costs::Part::Workers); Systems::WorkerSystem::Update(registry, grid, dt_ms); }
    { Core::Costs::Scope cost(Core::Costs::Part::Trade); Trade::Update(registry, grid, dt_ms); }
    { Core::Costs::Scope cost(Core::Costs::Part::Garrisons); Garrisons::Update(registry, grid, dt_ms); }
    { Core::Costs::Scope cost(Core::Costs::Part::Duties); Duties::Update(registry, grid, dt_ms); }
    { Core::Costs::Scope cost(Core::Costs::Part::Monks); Monks::Update(registry, grid, dt_ms); }
    { Core::Costs::Scope cost(Core::Costs::Part::Relics); Relics::Update(registry, grid, dt_ms); }
    { Core::Costs::Scope cost(Core::Costs::Part::Animals); Animals::Update(registry, grid, dt_ms); }
    { Core::Costs::Scope cost(Core::Costs::Part::Combat); Combat::Update(registry, grid, dt_ms); }
    { Core::Costs::Scope cost(Core::Costs::Part::Missiles); Missiles::Update(registry, grid, dt_ms); }
    { Core::Costs::Scope cost(Core::Costs::Part::Mortality); Mortality::Update(registry, grid, dt_ms); }
    { Core::Costs::Scope cost(Core::Costs::Part::Buildings); Buildings::Update(registry, grid); }
    { Core::Costs::Scope cost(Core::Costs::Part::Walls); Walls::Update(registry, grid); }
    // Spies' price follows the villagers it counts, before anything queues.
    { Core::Costs::Scope cost(Core::Costs::Part::Other); Spies::Update(registry); }
    { Core::Costs::Scope cost(Core::Costs::Part::Production); Production::Update(registry, grid, dt_ms); }
    { Core::Costs::Scope cost(Core::Costs::Part::Animation); Systems::AnimationSystem::Update(registry, dt_ms); }
    // A scenario's triggers, before the victory they can declare is looked at;
    // nothing in a random map game.
    { Core::Costs::Scope cost(Core::Costs::Part::Triggers); Triggers::Update(registry, grid, dt_ms); }
    { Core::Costs::Scope cost(Core::Costs::Part::Victory); Victory::Update(registry, grid, dt_ms); }

    { Core::Costs::Scope cost(Core::Costs::Part::Vision); CalculateVision(); }
    // What each player stops seeing, it remembers as it was.
    { Core::Costs::Scope cost(Core::Costs::Part::Fog); Fog::Update(registry); }
    // What of Gaia's the players now see, the first of them takes.
    { Core::Costs::Scope cost(Core::Costs::Part::Other); Allegiance::Capture(registry, grid); }
    // Last, after everything else that tick.
    { Core::Costs::Scope cost(Core::Costs::Part::Other); Score::Update(registry); }
    Core::Costs::EndTick();
}

void Simulation::CalculateVision() {
    Vision::Update(registry);
}

} // namespace ECS
