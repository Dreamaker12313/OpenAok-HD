#include "GraphicCache.h"
#include <filesystem>
#include <fstream>
#include "stb/stb_image.h"
#include "nlohmann/json.hpp"
#include <array>
#include <cmath>

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <iostream>

namespace HAL {

namespace {

// Padding between packed frames so bilinear sampling cannot bleed one frame
// into its neighbour.
constexpr int kPadding = 1;
// A texture page starts kFirstPageSide square and grows, a side at a time,
// as it fills: to kLargestPageSide for art, so the art on screen together
// mostly shares one page, and to kPageSide for shadows and outlines, which
// are few or seldom drawn. Unless the renderer allows less.
constexpr int kFirstPageSide = 1024;
constexpr int kPageSide = 2048;
constexpr int kLargestPageSide = 4096;
// How wide a graphic's frames are shelved: a block of them, its border all
// round, is no wider than kPageSide.
constexpr int kAtlasWidth = kPageSide - 2 * kPadding;
// The side taken as the renderer's limit when it names none.
constexpr int kNoLimit = 16384;

// Player-coloured pixels are stored as a shade, not an absolute palette entry.
// Each player's ramp begins at palette index 16 * player and runs eight
// entries, dark to light: 16-23 is player 1's blue, 32-39 player 2's red,
// 48-55 player 3's green. The eight indexes after each ramp are unrelated
// browns, so a shade is clamped to the ramp: units use shades 8 and 9 for
// their brightest highlights.
constexpr int kPlayerRampSize = 8;
// Used only until the dat's ramp table has been supplied.
constexpr int kPlayerRampStride = 16;

// What drawing into a page changes: the target, and its viewport, clip and
// scale, which SDL sets to a new target's whole at 1:1 whenever the target
// changes. Kept and put back, a page grows in the middle of a frame without
// the rest of the frame drawn at another zoom.
struct DrawState {
    SDL_Texture* target = nullptr;
    SDL_Rect viewport{0, 0, 0, 0};
    SDL_Rect clip{0, 0, 0, 0};
    bool clipped = false;
    float scale_x = 1.0f, scale_y = 1.0f;
    Uint8 r = 0, g = 0, b = 0, a = 0;
};

DrawState Keep(SDL_Renderer* renderer) {
    DrawState s;
    s.target = SDL_GetRenderTarget(renderer);
    SDL_RenderGetScale(renderer, &s.scale_x, &s.scale_y);
    SDL_RenderGetViewport(renderer, &s.viewport);
    s.clipped = SDL_RenderIsClipEnabled(renderer) == SDL_TRUE;
    SDL_RenderGetClipRect(renderer, &s.clip);
    SDL_GetRenderDrawColor(renderer, &s.r, &s.g, &s.b, &s.a);
    return s;
}

void PutBack(SDL_Renderer* renderer, const DrawState& s) {
    SDL_SetRenderTarget(renderer, s.target);
    // The viewport is given in the scale's units, so the scale goes first.
    SDL_RenderSetScale(renderer, s.scale_x, s.scale_y);
    SDL_RenderSetViewport(renderer, &s.viewport);
    SDL_RenderSetClipRect(renderer, s.clipped ? &s.clip : nullptr);
    SDL_SetRenderDrawColor(renderer, s.r, s.g, s.b, s.a);
}

} // namespace

bool GraphicCache::Init(SDL_Renderer* renderer,
                        const std::string& drs_path,
                        const std::string& palette_path) {
    sdl_renderer = renderer;
    SDL_RendererInfo info{};
    int most = kNoLimit;
    if (SDL_GetRendererInfo(renderer, &info) == 0 && info.max_texture_width > 0 && info.max_texture_height > 0) {
        most = std::min(info.max_texture_width, info.max_texture_height);
    }
    Sides(most);
    // Growing copies a page on the GPU, through a render target; without
    // them a page is made as big as it may grow from the first.
    grows = SDL_RenderTargetSupported(renderer) == SDL_TRUE;
    if (!DrsOpen(drs_path, drs)) return false;
    if (!LoadJascPalette(palette_path, palette)) return false;

    ready = true;
    std::cout << "[HAL] GraphicCache ready: " << drs.entries.size()
              << " SLPs, " << palette.size() << " palette entries." << std::endl;
    return true;
}

void GraphicCache::Shutdown() {
    for (auto& pool : pages) {
        for (Page& page : pool) SDL_DestroyTexture(page.texture);
        pool.clear();
    }
    for (SDL_Texture* texture : lone) SDL_DestroyTexture(texture);
    lone.clear();
    EndFrame();
    for (auto& pair : interface_atlases) {
        if (pair.second.base) SDL_DestroyTexture(pair.second.base);
    }
    for (auto& pair : interface_player_layers) {
        if (pair.second) SDL_DestroyTexture(pair.second);
    }
    for (auto& pair : terrain_atlases) {
        if (pair.second.base) SDL_DestroyTexture(pair.second.base);
    }
    atlases.clear();
    arts.clear();
    banded.clear();
    shadows.clear();
    outlines.clear();
    interface_atlases.clear();
    interface_player_layers.clear();
    terrain_atlases.clear();
    interface_ready = false;
    terrain_ready = false;
    gamedata_ready = false;
    ready = false;
}

void GraphicCache::Sides(int most) {
    most_side = most;
    first_side = std::min(kFirstPageSide, most);
    page_side = std::min(kPageSide, most);
    largest_side = std::min(kLargestPageSide, most);
}

void GraphicCache::LimitTextureSide(int side) {
    Sides(std::min(most_side > 0 ? most_side : kNoLimit, side));
}

const GraphicAtlas* GraphicCache::GetAtlas(uint32_t slp_id) {
    return AtlasFrom(drs, atlases, slp_id, slp_id, palette, false);
}

template <typename Key>
const GraphicAtlas* GraphicCache::AtlasFrom(
        const DrsArchive& src,
        std::unordered_map<Key, GraphicAtlas>& cache,
        Key key, uint32_t slp_id,
        const std::vector<PaletteColor>& colours, bool texture) {
    auto it = cache.find(key);
    if (it != cache.end()) {
        return it->second.valid ? &it->second : nullptr;
    }

    GraphicAtlas atlas;
    // Insert even on failure, so a missing graphic is not retried every frame.
    const std::vector<SlpFrameHeader> headers = SlpReadHeaders(src, slp_id);
    if (headers.empty()) {
        cache.emplace(key, atlas);
        return nullptr;
    }

    // Shelf-pack the frames in order, so a frame index maps straight to a
    // rect, `across` wide: the height they take.
    atlas.frames.resize(headers.size());
    auto shelve = [&](int across) {
        int shelf_x = 0;
        int shelf_y = 0;
        int shelf_h = 0;
        for (size_t i = 0; i < headers.size(); ++i) {
            const int fw = static_cast<int>(headers[i].width);
            const int fh = static_cast<int>(headers[i].height);
            if (fw <= 0 || fh <= 0) {
                atlas.frames[i].rect = {0, 0, 0, 0};
                continue;
            }
            if (shelf_x + fw > across) {
                shelf_x = 0;
                shelf_y += shelf_h + kPadding;
                shelf_h = 0;
            }
            atlas.frames[i].rect = {shelf_x, shelf_y, fw, fh};
            atlas.frames[i].hotspot_x = headers[i].hotspot_x;
            atlas.frames[i].hotspot_y = headers[i].hotspot_y;
            shelf_x += fw + kPadding;
            shelf_h = std::max(shelf_h, fh);
        }
        return shelf_y + shelf_h;
    };
    // As wide as a block of them, its border all round, fits on a page; a
    // graphic drawn from a texture of its own wider, when that is what keeps
    // it within the textures the renderer allows.
    const int most = most_side > 0 ? most_side : kNoLimit;
    int across = page_side > 0 ? std::min(kAtlasWidth, page_side - 2 * kPadding) : kAtlasWidth;
    int high = shelve(across);
    while (texture && high > most && across * 2 <= most) {
        across *= 2;
        high = shelve(across);
    }
    atlas.width = across;
    atlas.height = high;
    if (atlas.height <= 0) {
        cache.emplace(key, atlas);
        return nullptr;
    }

    // The coverage bits, whether there are player-coloured pixels, and for a
    // graphic drawn from a texture of its own, the texture.
    atlas.base = TextureOf(DrawLayer(src, slp_id, atlas, texture ? Layer::Base : Layer::None, 0, colours, 0,
                                     &atlas.opaque, &atlas.coloured));
    // Geometry, not pixels, decides validity: a shadow graphic decodes to no
    // colour pixels at all, but its frame rects and hotspots are still needed.
    atlas.valid = !atlas.frames.empty();

    auto inserted = cache.emplace(key, std::move(atlas));
    return inserted.first->second.valid ? &inserted.first->second : nullptr;
}

void GraphicCache::Count(int& textures, int64_t& bytes) const {
    textures = 0;
    bytes = 0;
    int widest = 0, tallest = 0;
    auto add = [&](SDL_Texture* texture) {
        int w = 0, h = 0;
        if (texture == nullptr || SDL_QueryTexture(texture, nullptr, nullptr, &w, &h) != 0) return;
        ++textures;
        bytes += static_cast<int64_t>(w) * h * 4;
        if (static_cast<int64_t>(w) * h > static_cast<int64_t>(widest) * tallest) {
            widest = w;
            tallest = h;
        }
    };
    for (const auto& pool : pages) {
        for (const Page& page : pool) add(page.texture);
    }
    for (SDL_Texture* texture : lone) add(texture);
    for (const auto& [id, atlas] : interface_atlases) add(atlas.base);
    for (const auto& [id, texture] : interface_player_layers) add(texture);
    for (const auto& [id, atlas] : terrain_atlases) add(atlas.base);
    std::cout << "[HAL] Largest texture " << widest << "x" << tallest << std::endl;
}

ArtPlace GraphicCache::Art(uint32_t slp_id, int player) {
    const GraphicAtlas* geometry = GetAtlas(slp_id);
    if (geometry == nullptr) return {};
    // Keyed by the colour the player wears, which the lobby may change from
    // game to game.
    const uint64_t key = (static_cast<uint64_t>(slp_id) << 8) |
                         (geometry->coloured ? static_cast<uint8_t>(ColourSlot(player) + 1) : 0);
    auto it = arts.find(key);
    if (it != arts.end()) return it->second;
    const ArtPlace place = LayerPlace(Pool::Art, slp_id, Layer::Art, player);
    arts.emplace(key, place);
    return place;
}

ArtPlace GraphicCache::Shadow(uint32_t slp_id) {
    auto it = shadows.find(slp_id);
    if (it != shadows.end()) return it->second;
    const ArtPlace place = LayerPlace(Pool::Shadow, slp_id, Layer::Shadow, 0);
    shadows.emplace(slp_id, place);
    return place;
}

ArtPlace GraphicCache::Outline(uint32_t slp_id) {
    auto it = outlines.find(slp_id);
    if (it != outlines.end()) return it->second;
    const ArtPlace place = LayerPlace(Pool::Outline, slp_id, Layer::Outline, 0);
    outlines.emplace(slp_id, place);
    return place;
}

ArtPlace GraphicCache::LayerPlace(Pool pool, uint32_t slp_id, Layer layer, int player) {
    const GraphicAtlas* geometry = GetAtlas(slp_id);
    if (geometry == nullptr) return {};
    SDL_Surface* block = DrawLayer(drs, slp_id, *geometry, layer, player, palette, kPadding);
    if (block == nullptr) return {};
    const int most = pool == Pool::Art ? largest_side : page_side;
    return block->h <= most ? Place(pool, block, kPadding) : PlaceBands(pool, block, *geometry, most);
}

ArtPlace GraphicCache::PlaceBands(Pool pool, SDL_Surface* block, const GraphicAtlas& geometry, int most) {
    // The shelves' tops and bottoms in atlas rows; frames are shelved in
    // order, so a shelf's are one run.
    std::vector<std::pair<int, int>> shelves;
    for (const GraphicFrame& f : geometry.frames) {
        if (f.rect.w <= 0) continue;
        if (shelves.empty() || shelves.back().first != f.rect.y) {
            shelves.push_back({f.rect.y, f.rect.y + f.rect.h});
        } else {
            shelves.back().second = std::max(shelves.back().second, f.rect.y + f.rect.h);
        }
    }
    std::vector<ArtBand>& bands = banded.emplace_back();
    SDL_SetSurfaceBlendMode(block, SDL_BLENDMODE_NONE);
    for (size_t i = 0; i < shelves.size();) {
        // As many shelves as fit `most` with the border above and below. Atlas
        // row r is the block's r + kPadding, so the band's rows of the block
        // start at its first shelf's top.
        const int top = shelves[i].first;
        int bottom = shelves[i].second;
        size_t next = i + 1;
        while (next < shelves.size() && shelves[next].second - top + 2 * kPadding <= most) {
            bottom = shelves[next++].second;
        }
        const int rows = bottom - top + 2 * kPadding;
        SDL_Surface* band = SDL_CreateRGBSurfaceWithFormat(0, block->w, rows, 32, block->format->format);
        ArtPlace place;
        if (band != nullptr) {
            SDL_Rect from{0, top, block->w, rows};
            SDL_BlitSurface(block, &from, band, nullptr);
            place = Place(pool, band, kPadding);
        }
        bands.push_back({top, place.page, place.x, place.y - top});
        i = next;
    }
    SDL_FreeSurface(block);
    if (bands.empty()) return {};
    return {bands.front().page, bands.front().x, bands.front().y, &bands};
}

bool GraphicCache::Fit(Page& page, int w, int h, SDL_Rect& at) {
    // Along the skyline, the lowest place the block's width fits.
    auto& sky = page.skyline;
    int best = -1, best_y = 0;
    for (size_t i = 0; i < sky.size(); ++i) {
        const int x = sky[i].x;
        if (x + w > page.w) break;
        int y = 0;
        for (size_t j = i; j < sky.size() && sky[j].x < x + w; ++j) y = std::max(y, sky[j].y);
        if (y + h > page.h) continue;
        if (best < 0 || y < best_y) {
            best = static_cast<int>(i);
            best_y = y;
        }
    }
    if (best < 0) return false;
    at = {sky[static_cast<size_t>(best)].x, best_y, w, h};
    // The block's top edge replaces the skyline under it.
    const int end = at.x + w;
    size_t i = static_cast<size_t>(best);
    while (i < sky.size() && sky[i].x + sky[i].w <= end) sky.erase(sky.begin() + static_cast<long>(i));
    if (i < sky.size() && sky[i].x < end) {
        sky[i].w -= end - sky[i].x;
        sky[i].x = end;
    }
    sky.insert(sky.begin() + static_cast<long>(i), Span{at.x, at.y + h, w});
    // Neighbours at one height are one stretch.
    for (size_t k = 0; k + 1 < sky.size();) {
        if (sky[k].y == sky[k + 1].y) {
            sky[k].w += sky[k + 1].w;
            sky.erase(sky.begin() + static_cast<long>(k) + 1);
        } else {
            ++k;
        }
    }
    return true;
}

bool GraphicCache::Grow(Page& page, int most) {
    const bool wider = page.w <= page.h;
    const int w = wider ? page.w * 2 : page.w;
    const int h = wider ? page.h : page.h * 2;
    if (!grows || w > most || h > most) return false;
    SDL_Texture* grown = SDL_CreateTexture(sdl_renderer, SDL_PIXELFORMAT_RGBA32, SDL_TEXTUREACCESS_TARGET, w, h);
    if (grown == nullptr) return false;
    SDL_SetTextureBlendMode(grown, SDL_BLENDMODE_BLEND);
    const DrawState drawing = Keep(sdl_renderer);
    SDL_SetRenderTarget(sdl_renderer, grown);
    SDL_SetRenderDrawColor(sdl_renderer, 0, 0, 0, 0);
    SDL_RenderClear(sdl_renderer);
    SDL_SetTextureBlendMode(page.texture, SDL_BLENDMODE_NONE);
    const SDL_Rect held{0, 0, page.w, page.h};
    SDL_RenderCopy(sdl_renderer, page.texture, nullptr, &held);
    SDL_SetTextureBlendMode(page.texture, SDL_BLENDMODE_BLEND);
    PutBack(sdl_renderer, drawing);
    // SDL's Metal renderer writes a texture's first update straight into its
    // memory, ahead of the drawing queued for it, which the clear and copy
    // above would then wipe. A clear pixel of the new part given now is that
    // first update, so every block written onto the page later waits its
    // turn behind the copy.
    const uint32_t clear = 0;
    const SDL_Rect corner{w - 1, h - 1, 1, 1};
    SDL_UpdateTexture(grown, &corner, &clear, static_cast<int>(sizeof(clear)));
    for (auto& [key, place] : arts) {
        if (place.page == page.texture) place.page = grown;
    }
    for (auto* places : {&shadows, &outlines}) {
        for (auto& [key, place] : *places) {
            if (place.page == page.texture) place.page = grown;
        }
    }
    for (auto& bands : banded) {
        for (ArtBand& band : bands) {
            if (band.page == page.texture) band.page = grown;
        }
    }
    retired.push_back(page.texture);
    page.texture = grown;
    // A new right half is empty from the top; into a new bottom half the
    // skyline goes on down.
    if (wider) page.skyline.push_back({page.w, 0, page.w});
    page.w = w;
    page.h = h;
    return true;
}

void GraphicCache::EndFrame() {
    for (SDL_Texture* texture : retired) SDL_DestroyTexture(texture);
    retired.clear();
}

ArtPlace GraphicCache::Place(Pool pool, SDL_Surface* block, int border) {
    const int w = block->w;
    const int h = block->h;
    SDL_Texture* texture = nullptr;
    SDL_Rect at{0, 0, w, h};
    const int most = pool == Pool::Art ? largest_side : page_side;
    auto& list = pages[static_cast<size_t>(pool)];
    for (Page& page : list) {
        if (Fit(page, w, h, at)) {
            texture = page.texture;
            break;
        }
    }
    // A pool fills its last page, growing it, before it starts another: the
    // more on one page, the more sprites draw in one batch.
    while (texture == nullptr && !list.empty() && Grow(list.back(), most)) {
        if (Fit(list.back(), w, h, at)) texture = list.back().texture;
    }
    if (texture == nullptr && w <= most && h <= most) {
        // Big enough for the block, as small as it may be.
        int side = grows ? first_side : most;
        while (side < w || side < h) side *= 2;
        Page page;
        page.texture = SDL_CreateTexture(sdl_renderer, SDL_PIXELFORMAT_RGBA32, SDL_TEXTUREACCESS_STATIC, side, side);
        if (page.texture != nullptr) {
            SDL_SetTextureBlendMode(page.texture, SDL_BLENDMODE_BLEND);
            page.w = side;
            page.h = side;
            page.skyline.push_back({0, 0, side});
            list.push_back(std::move(page));
            if (Fit(list.back(), w, h, at)) texture = list.back().texture;
        }
    }
    if (texture == nullptr && w <= most_side && h <= most_side) {
        texture = SDL_CreateTexture(sdl_renderer, SDL_PIXELFORMAT_RGBA32, SDL_TEXTUREACCESS_STATIC, w, h);
        at = {0, 0, w, h};
        if (texture != nullptr) {
            SDL_SetTextureBlendMode(texture, SDL_BLENDMODE_BLEND);
            lone.push_back(texture);
        }
    }
    if (texture == nullptr) {
        std::cerr << "[HAL] No texture takes a " << w << "x" << h << " block: " << SDL_GetError() << std::endl;
        SDL_FreeSurface(block);
        return {};
    }
    SDL_UpdateTexture(texture, &at, block->pixels, block->pitch);
    SDL_FreeSurface(block);
    return {texture, at.x + border, at.y + border};
}

void GraphicCache::SetPlayerRamps(const std::vector<int>& bases) {
    player_ramps = bases;
}

void GraphicCache::SetPlayerColours(const std::array<int, 16>& slots) {
    colour_slots = slots;
}

int GraphicCache::ColourSlot(int player) const {
    // Gaia has no colour of its own in the dat; it is drawn in the grey ramp.
    constexpr int kGaiaRamp = 6;
    if (player == 0) return kGaiaRamp;
    if (player < 0 || player >= 16) return 0;
    return colour_slots[static_cast<size_t>(player)] >= 0 ? colour_slots[static_cast<size_t>(player)]
                                                          : player - 1;
}

size_t GraphicCache::PaletteIndexForPlayer(int player, uint8_t shade) const {
    const size_t step = std::min<size_t>(shade, kPlayerRampSize - 1);
    // The colour the player wears: its seat's own, or the lobby's choice.
    const int index = ColourSlot(player);
    if (index >= 0 && index < static_cast<int>(player_ramps.size())) {
        return static_cast<size_t>(player_ramps[index]) + step;
    }
    return static_cast<size_t>(player) * kPlayerRampStride + step;
}

PaletteColor GraphicCache::GetPlayerColor(int player) const {
    if (palette.empty()) return PaletteColor{255, 255, 255};
    // Four steps along the ramp: the pure colour, before it washes out into
    // the pale highlights the last few entries hold.
    const size_t idx = PaletteIndexForPlayer(player, 4) % palette.size();
    return palette[idx];
}

PaletteColor GraphicCache::GetPaletteColor(size_t index) const {
    if (palette.empty()) return PaletteColor{255, 255, 255};
    return palette[index % palette.size()];
}

bool GraphicCache::OpenInterface(const std::string& drs_path) {
    interface_ready = DrsOpen(drs_path, interface_drs);
    if (interface_ready) {
        std::cout << "[HAL] Interface archive: " << interface_drs.entries.size()
                  << " files." << std::endl;
    }
    return interface_ready;
}

namespace {
bool ModEnabled(const std::filesystem::path& mod) {
    std::ifstream cfg(mod / "mod.json");
    if (!cfg) return true;
    std::string text((std::istreambuf_iterator<char>(cfg)), std::istreambuf_iterator<char>());
    const size_t p = text.find("\"enabled\"");
    if (p == std::string::npos) return true;
    const size_t colon = text.find(':', p);
    const size_t value = text.find_first_not_of(" \t\r\n", colon == std::string::npos ? p : colon + 1);
    return value == std::string::npos || text.compare(value, 5, "false") != 0;
}

void ApplyLooseDir(DrsArchive& archive, const std::filesystem::path& dir) {
    if (!std::filesystem::is_directory(dir)) return;
    for (const auto& item : std::filesystem::directory_iterator(dir)) {
        if (!item.is_regular_file()) continue;
        const std::string filename = item.path().filename().string();
        const size_t dot = filename.find('.');
        if (dot == std::string::npos) continue;
        const std::string stem = filename.substr(0, dot);
        if (stem.empty() || !std::all_of(stem.begin(), stem.end(), ::isdigit)) continue;
        std::ifstream in(item.path(), std::ios::binary);
        std::vector<uint8_t> bytes((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
        if (bytes.empty()) continue;
        const uint32_t id = static_cast<uint32_t>(std::stoul(stem));
        const uint32_t offset = static_cast<uint32_t>(archive.data.size());
        archive.data.insert(archive.data.end(), bytes.begin(), bytes.end());
        archive.entries[id] = DrsEntry{offset, static_cast<uint32_t>(bytes.size())};
    }
}
} // namespace

namespace {
void Put16(std::vector<uint8_t>& out, uint16_t v) {
    out.push_back(static_cast<uint8_t>(v));
    out.push_back(static_cast<uint8_t>(v >> 8));
}
void Put32(std::vector<uint8_t>& out, uint32_t v) {
    for (int i = 0; i < 4; ++i) out.push_back(static_cast<uint8_t>(v >> (8 * i)));
}
void PutI32(std::vector<uint8_t>& out, int32_t v) { Put32(out, static_cast<uint32_t>(v)); }

std::vector<uint8_t> EncodeTerrainSlp(const std::vector<std::vector<std::vector<uint8_t>>>& frames) {
    constexpr int kTileW = 97, kTileH = 49;
    std::vector<std::pair<int, int>> rows;
    rows.reserve(kTileH);
    for (int y = 0; y < kTileH; ++y) {
        const int width = y < kTileH / 2 ? 1 + 4 * y : 2 * kTileH - 1 - 4 * (y - kTileH / 2);
        rows.emplace_back((kTileW - width) / 2, width);
    }
    std::vector<uint8_t> out;
    out.insert(out.end(), {'2', '.', '0', 'N'});
    Put16(out, static_cast<uint16_t>(frames.size()));
    Put16(out, 0);
    const char comment[] = "ArtDesk 1.00 SLP Writer";
    out.insert(out.end(), comment, comment + sizeof(comment)); // includes the NUL
    while (out.size() < 32) out.push_back(0);
    const uint32_t body_at = 32 + 32 * static_cast<uint32_t>(frames.size());
    std::vector<uint8_t> headers;
    std::vector<uint8_t> bodies;
    for (const auto& frame : frames) {
        const uint32_t base = body_at + static_cast<uint32_t>(bodies.size());
        std::vector<uint8_t> outline;
        for (const auto& [left, width] : rows) {
            Put16(outline, static_cast<uint16_t>(left));
            Put16(outline, static_cast<uint16_t>(kTileW - left - width));
        }
        const uint32_t cmd_at = base + static_cast<uint32_t>(outline.size());
        std::vector<uint8_t> cmds;
        std::vector<uint32_t> offsets;
        for (const auto& indices : frame) {
            offsets.push_back(cmd_at + 4 * kTileH + static_cast<uint32_t>(cmds.size()));
            for (size_t i = 0; i < indices.size(); i += 63) {
                const size_t n = std::min<size_t>(63, indices.size() - i);
                cmds.push_back(static_cast<uint8_t>(n << 2));
                cmds.insert(cmds.end(), indices.begin() + i, indices.begin() + i + n);
            }
            cmds.push_back(0x0F);
        }
        Put32(headers, cmd_at);
        Put32(headers, base);
        Put32(headers, 0);
        Put32(headers, 0x10);
        PutI32(headers, kTileW);
        PutI32(headers, kTileH);
        PutI32(headers, kTileW / 2);
        PutI32(headers, 0);
        bodies.insert(bodies.end(), outline.begin(), outline.end());
        for (uint32_t o : offsets) Put32(bodies, o);
        bodies.insert(bodies.end(), cmds.begin(), cmds.end());
    }
    out.insert(out.end(), headers.begin(), headers.end());
    out.insert(out.end(), bodies.begin(), bodies.end());
    return out;
}

std::vector<std::vector<std::vector<uint8_t>>> CutTerrain(const uint8_t* rgb, int w, int h,
                                                          const std::vector<std::array<int, 3>>& pal) {
    constexpr int kSide = 388, kPeriod = 8, kTileW = 97, kTileH = 49;
    std::vector<uint8_t> tex(kSide * kSide * 3);
    for (int y = 0; y < kSide; ++y) {
        const int sy = std::min(h - 1, y * h / kSide);
        for (int x = 0; x < kSide; ++x) {
            const int sx = std::min(w - 1, x * w / kSide);
            const uint8_t* p = rgb + (sy * w + sx) * 3;
            std::copy(p, p + 3, &tex[(y * kSide + x) * 3]);
        }
    }
    std::vector<std::pair<int, int>> rows;
    for (int y = 0; y < kTileH; ++y) {
        const int width = y < kTileH / 2 ? 1 + 4 * y : 2 * kTileH - 1 - 4 * (y - kTileH / 2);
        rows.emplace_back((kTileW - width) / 2, width);
    }
    std::vector<std::vector<std::vector<uint8_t>>> frames;
    frames.reserve(kPeriod * kPeriod);
    for (int column = 0; column < kPeriod; ++column) {
        for (int row = 0; row < kPeriod; ++row) {
            const int tile_y = (kPeriod - row) % kPeriod;
            std::vector<std::vector<uint8_t>> frame;
            frame.reserve(kTileH);
            for (int y = 0; y < kTileH; ++y) {
                const auto [left, width] = rows[y];
                std::vector<uint8_t> line;
                line.reserve(width);
                for (int i = 0; i < width; ++i) {
                    const double px = left + i + 0.5 - kTileW / 2.0;
                    const double py = y + 0.5;
                    const double u = column + (px / 48.5 + py / 24.5) / 2.0;
                    const double v = tile_y + (py / 24.5 - px / 48.5) / 2.0;
                    int tx = static_cast<int>(std::floor(u / kPeriod * kSide)) % kSide;
                    int ty = static_cast<int>(std::floor(v / kPeriod * kSide)) % kSide;
                    if (tx < 0) tx += kSide;
                    if (ty < 0) ty += kSide;
                    const uint8_t* p = &tex[(ty * kSide + tx) * 3];
                    int best = 0;
                    long best_d = 1L << 30;
                    for (int c = 0; c < 256; ++c) {
                        const long dr = p[0] - pal[c][0], dg = p[1] - pal[c][1], db = p[2] - pal[c][2];
                        const long d = dr * dr + dg * dg + db * db;
                        if (d < best_d) { best_d = d; best = c; }
                    }
                    line.push_back(static_cast<uint8_t>(best));
                }
                frame.push_back(std::move(line));
            }
            frames.push_back(std::move(frame));
        }
    }
    return frames;
}
} // namespace

void GraphicCache::ApplyTerrainTextures(const std::string& map_file) {
    if (!terrain_ready) return;
    std::ifstream map_in(map_file);
    if (!map_in) return;
    nlohmann::json map;
    try { map_in >> map; } catch (...) { return; }
    std::ifstream pal_in("../assets/original/interfac_extracted/50500.bina", std::ios::binary);
    std::vector<uint8_t> bytes((std::istreambuf_iterator<char>(pal_in)), std::istreambuf_iterator<char>());
    if (bytes.size() < 768) return;
    std::vector<std::array<int, 3>> pal(256);
    for (int i = 0; i < 256; ++i)
        pal[i] = {bytes[i * 3], bytes[i * 3 + 1], bytes[i * 3 + 2]};
    for (const auto& item : map.value("terrains", nlohmann::json::array())) {
        const int id = item.value("slp", -1);
        const std::string file = item.value("texture", "");
        if (id < 0 || file.empty()) continue;
        int w = 0, h = 0, channels = 0;
        const std::string path = (!file.empty() && file[0] == '/') ? file : "../" + file;
        stbi_uc* pixels = stbi_load(path.c_str(), &w, &h, &channels, 3);
        if (pixels == nullptr || w <= 0 || h <= 0) { if (pixels) stbi_image_free(pixels); continue; }
        auto frames = CutTerrain(pixels, w, h, pal);
        stbi_image_free(pixels);
        const auto slp = EncodeTerrainSlp(frames);
        const uint32_t offset = static_cast<uint32_t>(terrain_drs.data.size());
        terrain_drs.data.insert(terrain_drs.data.end(), slp.begin(), slp.end());
        terrain_drs.entries[static_cast<uint32_t>(id)] = DrsEntry{offset, static_cast<uint32_t>(slp.size())};
    }
}

void GraphicCache::ApplyLooseMods(const std::string& mods_dir) {
    if (!std::filesystem::is_directory(mods_dir)) return;
    for (const auto& mod : std::filesystem::directory_iterator(mods_dir)) {
        if (!mod.is_directory() || !ModEnabled(mod.path())) continue;
        const auto common = mod.path() / "resources" / "_common" / "drs";
        ApplyLooseDir(drs, common / "graphics");
        ApplyLooseDir(interface_drs, common / "interface");
        ApplyLooseDir(terrain_drs, common / "terrain");
    }
}

const std::vector<PaletteColor>& GraphicCache::InterfacePalette(uint32_t palette_id) {
    if (palette_id == kGamePalette) return palette;
    auto it = interface_palettes.find(palette_id);
    if (it != interface_palettes.end()) return it->second;
    if (const uint32_t percent = palette_id >> 24; percent > 0) {
        const std::vector<PaletteColor> base = InterfacePalette(palette_id & 0xFFFFFFu);
        std::vector<PaletteColor> shaded(base.size());
        const int keep = 100 - static_cast<int>(percent);
        for (size_t i = 0; i < base.size(); ++i) {
            const int r = base[i].r * keep / 100;
            const int g = base[i].g * keep / 100;
            const int b = base[i].b * keep / 100;
            int best = 0;
            int best_d = 1 << 30;
            for (size_t j = 0; j < base.size(); ++j) {
                const int dr = base[j].r - r, dg = base[j].g - g, db = base[j].b - b;
                const int d = dr * dr + dg * dg + db * db;
                if (d < best_d) { best_d = d; best = static_cast<int>(j); }
            }
            shaded[i] = base[static_cast<size_t>(best)];
        }
        return interface_palettes.emplace(palette_id, std::move(shaded)).first->second;
    }
    std::vector<PaletteColor> colours;
    std::string text;
    if (interface_ready && DrsReadText(interface_drs, palette_id, text)) {
        // JASC-PAL: a header, a version, a count, then one "r g b" per line.
        size_t pos = 0;
        int line = 0;
        int count = 0;
        while (pos < text.size()) {
            size_t end = text.find('\n', pos);
            if (end == std::string::npos) end = text.size();
            const std::string row = text.substr(pos, end - pos);
            pos = end + 1;
            if (line == 2) count = std::atoi(row.c_str());
            if (line >= 3 && static_cast<int>(colours.size()) < count) {
                int r = 0, g = 0, b = 0;
                if (std::sscanf(row.c_str(), "%d %d %d", &r, &g, &b) == 3) {
                    colours.push_back({static_cast<uint8_t>(r), static_cast<uint8_t>(g),
                                       static_cast<uint8_t>(b)});
                }
            }
            ++line;
        }
    }
    if (colours.empty()) colours = palette;
    return interface_palettes.emplace(palette_id, std::move(colours)).first->second;
}

const GraphicAtlas* GraphicCache::GetInterfaceAtlas(uint32_t slp_id, uint32_t palette_id) {
    if (!interface_ready) return nullptr;
    const uint64_t key = (static_cast<uint64_t>(palette_id) << 32) | slp_id;
    return AtlasFrom(interface_drs, interface_atlases, key, slp_id,
                     InterfacePalette(palette_id), true);
}

SDL_Texture* GraphicCache::GetInterfacePlayerLayer(uint32_t slp_id, int player) {
    if (!interface_ready) return nullptr;
    const uint64_t key = (static_cast<uint64_t>(slp_id) << 8) | static_cast<uint8_t>(ColourSlot(player) + 1);
    auto it = interface_player_layers.find(key);
    if (it != interface_player_layers.end()) return it->second;

    const GraphicAtlas* geometry = GetInterfaceAtlas(slp_id);
    SDL_Texture* tex = geometry != nullptr
                           ? BuildLayer(interface_drs, slp_id, *geometry, Layer::Player, player, palette)
                           : nullptr;
    interface_player_layers.emplace(key, tex);
    return tex;
}

SDL_Texture* GraphicCache::GetInterfaceTexture(uint32_t slp_id, uint32_t palette_id) {
    const GraphicAtlas* atlas = GetInterfaceAtlas(slp_id, palette_id);
    return atlas ? atlas->base : nullptr;
}

bool GraphicCache::OpenTerrain(const std::string& drs_path) {
    terrain_ready = DrsOpen(drs_path, terrain_drs);
    if (terrain_ready) {
        std::cout << "[HAL] Terrain archive: " << terrain_drs.entries.size()
                  << " files." << std::endl;
    }
    return terrain_ready;
}

const GraphicAtlas* GraphicCache::GetTerrainAtlas(uint32_t slp_id) {
    if (!terrain_ready) return nullptr;
    return AtlasFrom(terrain_drs, terrain_atlases, slp_id, slp_id, palette, true);
}

bool GraphicCache::OpenGameData(const std::string& drs_path) {
    gamedata_ready = DrsOpen(drs_path, gamedata_drs);
    if (gamedata_ready) {
        std::cout << "[HAL] Game data archive: " << gamedata_drs.entries.size()
                  << " scripts." << std::endl;
    }
    return gamedata_ready;
}

bool GraphicCache::ReadGameDataText(uint32_t file_id, std::string& out) const {
    if (!gamedata_ready) return false;
    return DrsReadText(gamedata_drs, file_id, out);
}

SDL_Surface* GraphicCache::DrawLayer(const DrsArchive& src, uint32_t slp_id,
                                     const GraphicAtlas& geometry, Layer layer, int player,
                                     const std::vector<PaletteColor>& colours, int border,
                                     std::vector<uint8_t>* opaque, bool* coloured) {
    if (geometry.height <= 0 || geometry.frames.empty()) return nullptr;
    // A texture of its own spans the atlas's width; a block for a page only
    // what its frames cover.
    int used_w = 0;
    for (const GraphicFrame& f : geometry.frames) used_w = std::max(used_w, f.rect.x + f.rect.w);
    const int surface_w = border == 0 ? geometry.width : used_w + 2 * border;
    const int surface_h = geometry.height + 2 * border;
    SDL_Surface* surface = nullptr;
    if (layer != Layer::None) {
        surface = SDL_CreateRGBSurfaceWithFormat(0, surface_w, surface_h, 32, SDL_PIXELFORMAT_RGBA32);
        if (!surface) return nullptr;
        SDL_memset(surface->pixels, 0, static_cast<size_t>(surface->h) * surface->pitch);
    }
    if (opaque != nullptr) {
        opaque->assign((static_cast<size_t>(geometry.width) * static_cast<size_t>(geometry.height) + 7) / 8, 0);
    }
    if (coloured != nullptr) *coloured = false;

    bool wrote_any = false;
    SlpFrame frame;
    for (size_t i = 0; i < geometry.frames.size(); ++i) {
        const SDL_Rect& r = geometry.frames[i].rect;
        if (r.w == 0) continue;
        if (!SlpDecodeFrame(src, slp_id, static_cast<uint32_t>(i), frame)) continue;
        for (uint32_t y = 0; y < frame.height; ++y) {
            uint8_t* dst = surface == nullptr
                               ? nullptr
                               : static_cast<uint8_t*>(surface->pixels) +
                                     static_cast<size_t>(r.y + border + static_cast<int>(y)) * surface->pitch +
                                     static_cast<size_t>(r.x + border) * 4;
            for (uint32_t x = 0; x < frame.width; ++x) {
                const size_t p = static_cast<size_t>(y) * frame.width + x;
                if (opaque != nullptr && frame.alpha[p]) {
                    const size_t bit = static_cast<size_t>(r.y + static_cast<int>(y)) * geometry.width +
                                       static_cast<size_t>(r.x + static_cast<int>(x));
                    (*opaque)[bit >> 3] |= static_cast<uint8_t>(1u << (bit & 7));
                }
                if (coloured != nullptr && frame.alpha[p] && frame.player[p]) *coloured = true;
                if (dst == nullptr) continue;
                uint8_t* out = dst + static_cast<size_t>(x) * 4;
                const PaletteColor* c = nullptr;
                switch (layer) {
                case Layer::Base:
                    // Player-coloured pixels are left out; an interface icon
                    // gets them from its player layer.
                    if (frame.alpha[p] && !frame.player[p]) c = &colours[frame.indexes[p] % colours.size()];
                    break;
                case Layer::Player:
                    if (frame.player[p]) c = &palette[PaletteIndexForPlayer(player, frame.player[p]) % palette.size()];
                    break;
                case Layer::Art:
                    if (frame.player[p]) {
                        c = &palette[PaletteIndexForPlayer(player, frame.player[p]) % palette.size()];
                    } else if (frame.alpha[p]) {
                        c = &colours[frame.indexes[p] % colours.size()];
                    }
                    break;
                case Layer::Shadow:
                    if (frame.shadow[p]) {
                        out[0] = 0; out[1] = 0; out[2] = 0; out[3] = 255;
                        wrote_any = true;
                    }
                    break;
                case Layer::Outline:
                    // White, so a colour mod can tint it per player.
                    if (frame.outline[p]) {
                        out[0] = 255; out[1] = 255; out[2] = 255; out[3] = 255;
                        wrote_any = true;
                    }
                    break;
                case Layer::None:
                    break;
                }
                if (c != nullptr) {
                    out[0] = c->r; out[1] = c->g; out[2] = c->b; out[3] = 255;
                    wrote_any = true;
                }
            }
        }
    }
    if (!wrote_any) {
        if (surface != nullptr) SDL_FreeSurface(surface);
        return nullptr;
    }
    return surface;
}

SDL_Texture* GraphicCache::BuildLayer(const DrsArchive& src, uint32_t slp_id, const GraphicAtlas& geometry,
                                      Layer layer, int player, const std::vector<PaletteColor>& colours) {
    return TextureOf(DrawLayer(src, slp_id, geometry, layer, player, colours, 0));
}

SDL_Texture* GraphicCache::TextureOf(SDL_Surface* surface) {
    if (surface == nullptr) return nullptr;
    // None past the renderer's limit is asked for.
    if (most_side > 0 && (surface->w > most_side || surface->h > most_side)) {
        std::cerr << "[HAL] No texture takes a " << surface->w << "x" << surface->h << " graphic" << std::endl;
        SDL_FreeSurface(surface);
        return nullptr;
    }
    SDL_Texture* texture = SDL_CreateTextureFromSurface(sdl_renderer, surface);
    SDL_FreeSurface(surface);
    if (texture) SDL_SetTextureBlendMode(texture, SDL_BLENDMODE_BLEND);
    return texture;
}

} // namespace HAL
