#pragma once
#include <SDL2/SDL.h>
#include "ecs/Simulation.h"
#include <string>
#include <cstdint>
#include <unordered_map>

namespace Rendering {

class Renderer;

struct TerrainChunk {
    SDL_Texture* texture = nullptr;
    int grid_x = 0;
    int grid_y = 0;
    SDL_FRect screen_bounds{0, 0, 0, 0};
    uint64_t last_used = 0;   // frame counter, for eviction
};

class TerrainRenderer {
public:
    static void DrawTerrain(ECS::Simulation& sim, Renderer& renderer, SDL_Renderer* sdl_r);

    // One tile of ground: where it sits inside its terrain's atlas. The whole
    // terrain set is a single texture, so a chunk bakes without ever swapping
    // texture, and picking a cell is rect arithmetic.
    struct TerrainTile {
        SDL_Texture* atlas = nullptr;
        SDL_Rect src{0, 0, 0, 0};
    };
    // The cell of `type`'s set that the tile at (x, y) draws, whatever the
    // tile's terrain was before.
    static TerrainTile GetTerrainTile(Core::TerrainType type, int x, int y);

    // Which frame of a terrain set of `frame_count` frames the tile at (x, y)
    // draws. Each set in terrain.drs is a square tiling pattern (100, 64, 36
    // or 9 frames) whose pieces line up in one arrangement only: the tile at
    // (x, y) draws the pattern's cell for that position. The row runs the
    // opposite way to the column because the isometric grid's y axis points
    // up-left on screen while the pattern is stored top-down.
    static int PatternCell(int x, int y, int frame_count);

    // Draws the w x h top left of `full`, which has a clear column and row
    // beyond it, into the whole of the render target at half its size. Each
    // pixel is ground where any of the four it stands for is, so neighbouring
    // chunks still overlap where they meet and no gap opens between them when
    // drawn at any zoom.
    static void Halve(SDL_Renderer* sdl_r, SDL_Texture* full, int w, int h);

    // Tiles per chunk side; small, so little texture goes to the empty
    // corners of each chunk's isometric bounding box.
    static const int CHUNK_SIZE = 8;
    // Live chunks, keyed by chunk coordinate. Only what the viewport needs is
    // ever baked or kept.
    static std::unordered_map<uint64_t, TerrainChunk> chunks;
    
    static void InvalidateChunks();
};

} // namespace Rendering
