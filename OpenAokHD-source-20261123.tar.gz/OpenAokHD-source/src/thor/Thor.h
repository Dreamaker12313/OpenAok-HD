#pragma once
#include <SDL2/SDL.h>

namespace ECS { class Simulation; }
namespace Rendering { class Renderer; }

// The AYN Thor's second screen (Thor AoK): with it, the interface leaves the
// top screen to the map and a command deck on the bottom screen shows the
// stockpiles, the mini-map, the selection and its commands
// (android/app/src/main/java/org/openaok/game/ThorDeck.java). The deck reads a
// snapshot the engine writes once a frame and sends commands back, which the
// engine runs on its own thread through the code a click on the panel runs.
// Without a second screen nothing here does anything.
namespace Thor {

// Whether the deck is showing: the top screen then draws no interface.
bool Dual();
void SetDual(bool on);

// Commands from the deck (ThorBridge.java has the same numbers).
enum Command : int {
    kCommand = 1,       // a = command grid slot 1..15
    kMinimap = 2,       // a, b = point of the mini-map picture, 0..65535 each
    kIdleVillager = 3,
    kIdleMilitary = 4,
    kTownCenter = 5,
    kAgeUp = 6,         // selects the Town Center and researches the next age
    kMenu = 7,
    kCancelQueue = 8,   // a = queue slot (QueueSlot::slot)
    kDelete = 9,
    kObjectives = 10,
    kTechTree = 11,
    kGoTo = 12,         // a = entry of the go-to list (the snapshot's), the next of those buildings
    kGroupSelect = 13,  // a = control group 1..4
    kGroupAssign = 14,  // a = control group 1..4, from the selection
    kSpeed = 15,        // a = 1 faster, -1 slower
    kGame = 16,         // a = GameItem
};

// kGame's items.
enum GameItem : int {
    kLastNotification = 0, kGoToSelected = 1, kFlare = 2, kMinimapNormal = 3, kMinimapCombat = 4,
    kMinimapEconomic = 5, kStatistics = 6, kClock = 7,
};

// The game's speed, percent: given what it is, returns what the deck has asked
// it to be since (the main loop's, once a frame).
int Speed(int percent);

// A command for the next frame, from the deck or from the controller (hal/Pad).
void Push(int type, int a = 0, int b = 0);

// Once a frame, after the world is drawn: runs the deck's commands and
// writes the snapshot (and now and then the mini-map's picture).
void Frame(ECS::Simulation& sim, Rendering::Renderer& renderer, SDL_Renderer* sdl_r, int win_w,
           int win_h);
} // namespace Thor
