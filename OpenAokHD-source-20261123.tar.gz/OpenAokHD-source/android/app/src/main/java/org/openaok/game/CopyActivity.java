package org.openaok.game;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.CRC32;

/**
 * The launcher. The engine reads the game's data from files beside its build
 * directory, and the APK holds none of it: the player makes a folder of it on
 * a computer from their own CD (android/package.py) and copies it to the
 * phone. On first start this asks for that folder and copies it into the app's
 * own storage, checking every file against the folder's manifest.txt (its
 * CRC-32, size and path), then starts the game. Data of another version than
 * this build plays from (BuildConfig.DATA_VERSION, the folder's version.txt)
 * is asked for again.
 */
public class CopyActivity extends Activity {
    private static final int kChooseFolder = 1;
    // The name android/package.py gives the folder, looked for inside the one
    // chosen if that is not it.
    private static final String kFolderName = "OpenAoK-data";

    private LinearLayout layout;
    private TextView status;
    private ProgressBar bar;
    private Button choose;
    private Button play;
    private Button mods;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        final int installed = installedVersion();
        build();
        if (installed == BuildConfig.DATA_VERSION) {
            // Thor AoK's start screen: play, or choose a new data folder.
            play.setText(getString(R.string.play));
            show(getString(R.string.launch_ready), true);
        } else if (installed > 0) {
            show(getString(R.string.launch_newer), true);
        } else {
            show(getString(R.string.launch_need), false);
        }
    }

    private File game() {
        return new File(getFilesDir(), "game");
    }

    private File marker() {
        return new File(game(), ".installed");
    }

    // The version of the data copied in, or 0 when there is none.
    private int installedVersion() {
        try {
            return Integer.parseInt(new String(Files.readAllBytes(marker().toPath()), StandardCharsets.UTF_8).trim());
        } catch (IOException | NumberFormatException e) {
            return 0;
        }
    }

    private void build() {
        layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        layout.setBackgroundColor(Color.TRANSPARENT);
        layout.setPadding(120, 0, 120, 0);
        TextView title = new TextView(this);
        title.setText("OpenAokHD");
        title.setTextColor(Color.rgb(232, 176, 74));
        title.setTextSize(54);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.START);
        title.setPadding(0, 0, 0, 28);
        status = new TextView(this);
        status.setTextColor(Color.rgb(230, 200, 120));
        status.setTextSize(18);
        status.setGravity(Gravity.START);
        status.setMaxWidth(900);
        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(1000);
        bar.setVisibility(View.GONE);
        play = menuButton(getString(R.string.play));
        play.setOnClickListener(v -> play());
        mods = menuButton("MOD管理器");
        mods.setOnClickListener(v -> pickMods());
        choose = menuButton(getString(R.string.choose_folder));
        choose.setOnClickListener(v -> {
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            startActivityForResult(pick, kChooseFolder);
        });
        layout.addView(title);
        layout.addView(status);
        layout.addView(bar, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        layout.addView(play, menuParams());
        layout.addView(mods, menuParams());
        layout.addView(choose, menuParams());
        setContentView(layout);
        layout.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    private Button menuButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(22);
        button.setTextColor(Color.rgb(235, 220, 190));
        button.setBackgroundColor(Color.argb(180, 25, 20, 15));
        button.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        button.setPadding(48, 0, 48, 0);
        return button;
    }

    private LinearLayout.LayoutParams menuParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(560, 110);
        p.setMargins(0, 10, 0, 0);
        return p;
    }

    private void pickMods() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        startActivityForResult(pick, 2);
    }

    private void importMods(Uri tree) {
        new Thread(() -> {
            try {
                File modsRoot = new File(game(), "mods");
                modsRoot.mkdirs();
                String root = DocumentsContract.getTreeDocumentId(tree);
                Map<String, Entry> top = children(tree, root);
                List<String> names = new ArrayList<>();
                if (top.containsKey("mod.json")) {
                    String name = "imported_" + System.currentTimeMillis();
                    File target = new File(modsRoot, name);
                    target.mkdirs();
                    Map<String, String> files = new HashMap<>();
                    walk(tree, root, "", files);
                    copyFiles(tree, files, target);
                    names.add(name);
                } else {
                    for (Map.Entry<String, Entry> item : top.entrySet()) {
                        if (!item.getValue().folder) continue;
                        File target = new File(modsRoot, item.getKey());
                        target.mkdirs();
                        Map<String, String> files = new HashMap<>();
                        walk(tree, item.getValue().id, "", files);
                        copyFiles(tree, files, target);
                        names.add(item.getKey());
                    }
                }
                runOnUiThread(() -> Toast.makeText(this,
                    "已导入 MOD：" + android.text.TextUtils.join(", ", names), Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "导入 MOD 失败：" + e.getMessage(),
                    Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void copyFiles(Uri tree, Map<String, String> files, File target) throws IOException {
        byte[] buffer = new byte[1 << 20];
        for (Map.Entry<String, String> file : files.entrySet()) {
            File out = new File(target, file.getKey());
            File parent = out.getParentFile();
            if (parent != null) parent.mkdirs();
            try (InputStream in = open(tree, file.getValue());
                 OutputStream os = new FileOutputStream(out)) {
                int n;
                while ((n = in.read(buffer)) > 0) os.write(buffer, 0, n);
            }
        }
    }

    // The words, and the buttons beneath them; `playable` offers to play with
    // the data already copied in.
    private void show(String text, boolean playable) {
        status.setText(text);
        bar.setVisibility(View.GONE);
        choose.setVisibility(View.VISIBLE);
        play.setVisibility(playable ? View.VISIBLE : View.GONE);
        mods.setEnabled(installedVersion() > 0);
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == 2) {
            if (result == RESULT_OK && data != null && data.getData() != null) importMods(data.getData());
            return;
        }
        if (request != kChooseFolder || result != RESULT_OK || data == null || data.getData() == null) return;
        final Uri tree = data.getData();
        choose.setVisibility(View.GONE);
        play.setVisibility(View.GONE);
        bar.setVisibility(View.VISIBLE);
        bar.setProgress(0);
        status.setText(getString(R.string.reading));
        new Thread(() -> {
            try {
                install(tree);
                runOnUiThread(this::play);
            } catch (IOException e) {
                final boolean playable = installedVersion() > 0;
                runOnUiThread(() -> show(e.getMessage(), playable));
            }
        }).start();
    }

    // A document in the chosen tree: its id, and whether it is a folder.
    private static final class Entry {
        final String id;
        final boolean folder;

        Entry(String id, boolean folder) {
            this.id = id;
            this.folder = folder;
        }
    }

    private Map<String, Entry> children(Uri tree, String folder) throws IOException {
        Map<String, Entry> out = new HashMap<>();
        Uri uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, folder);
        String[] columns = {DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                            DocumentsContract.Document.COLUMN_MIME_TYPE};
        try (Cursor c = getContentResolver().query(uri, columns, null, null, null)) {
            if (c == null) throw new IOException("Could not read the folder.");
            while (c.moveToNext()) {
                out.put(c.getString(1), new Entry(c.getString(0),
                    DocumentsContract.Document.MIME_TYPE_DIR.equals(c.getString(2))));
            }
        }
        return out;
    }

    // Every file under `folder`, by its path from it.
    private void walk(Uri tree, String folder, String prefix, Map<String, String> files) throws IOException {
        for (Map.Entry<String, Entry> child : children(tree, folder).entrySet()) {
            String path = prefix + child.getKey();
            if (child.getValue().folder) {
                walk(tree, child.getValue().id, path + "/", files);
            } else {
                files.put(path, child.getValue().id);
            }
        }
    }

    private InputStream open(Uri tree, String id) throws IOException {
        InputStream in = getContentResolver().openInputStream(DocumentsContract.buildDocumentUriUsingTree(tree, id));
        if (in == null) throw new IOException("Could not open a file in the folder.");
        return in;
    }

    private List<String> lines(Uri tree, String id) throws IOException {
        List<String> out = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(open(tree, id), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) out.add(line);
        }
        return out;
    }

    private void install(Uri tree) throws IOException {
        // The folder chosen, or the one package.py made inside it.
        String root = DocumentsContract.getTreeDocumentId(tree);
        Map<String, Entry> top = children(tree, root);
        if (!top.containsKey("manifest.txt") && top.containsKey(kFolderName) && top.get(kFolderName).folder) {
            root = top.get(kFolderName).id;
        }
        Map<String, String> files = new HashMap<>();
        walk(tree, root, "", files);
        if (!files.containsKey("manifest.txt") || !files.containsKey("version.txt")) {
            throw new IOException("That folder is not the game's data: choose the " + kFolderName
                + " folder made by android/package.py.");
        }
        int version;
        try {
            version = Integer.parseInt(lines(tree, files.get("version.txt")).get(0).trim());
        } catch (RuntimeException e) {
            version = 0;
        }
        if (version != BuildConfig.DATA_VERSION) {
            throw new IOException("That folder holds game data of version " + version + "; this OpenAoK "
                + "plays from version " + BuildConfig.DATA_VERSION + ". Make it again with this "
                + "release's source code.");
        }

        // CRC-32, size, path.
        List<String[]> wanted = new ArrayList<>();
        long total = 0;
        for (String line : lines(tree, files.get("manifest.txt"))) {
            String[] parts = line.split(" ", 3);
            if (parts.length != 3) continue;
            wanted.add(parts);
            total += Long.parseLong(parts[1]);
        }

        File game = game();
        marker().delete();
        new File(game, "build").mkdirs();
        byte[] buffer = new byte[1 << 20];
        long done = 0;
        int shown = -1;
        for (String[] item : wanted) {
            String id = files.get(item[2]);
            if (id == null) throw new IOException("The folder is missing " + item[2] + ": copy it to the phone again.");
            File out = new File(game, item[2]);
            File parent = out.getParentFile();
            if (parent != null) parent.mkdirs();
            CRC32 crc = new CRC32();
            long size = 0;
            try (InputStream in = open(tree, id); OutputStream os = new FileOutputStream(out)) {
                int n;
                while ((n = in.read(buffer)) > 0) {
                    os.write(buffer, 0, n);
                    crc.update(buffer, 0, n);
                    size += n;
                    done += n;
                    final int permille = total > 0 ? (int) (done * 1000 / total) : 1000;
                    if (permille != shown) {
                        shown = permille;
                        final long mb = done >> 20, all = total >> 20;
                        runOnUiThread(() -> {
                            bar.setProgress(permille);
                            status.setText(getString(R.string.copying, mb, all));
                        });
                    }
                }
            }
            if (size != Long.parseLong(item[1]) || crc.getValue() != Long.parseLong(item[0], 16)) {
                throw new IOException(item[2] + " in the folder is damaged: copy the folder to the phone again.");
            }
        }
        try (FileWriter w = new FileWriter(marker())) {
            w.write(Integer.toString(BuildConfig.DATA_VERSION));
        }
    }

    private void play() {
        startActivity(new Intent(this, GameActivity.class));
        finish();
    }
}
