"""Encode a PNG/JPEG into an 8-bit AoE SLP frame (opaque, 256-colour).

Used by the HD art conversion: the 32-bit `_32.slp` files are decoded to
RGBA elsewhere, then flattened on the dark panel colour and encoded here.
Pure Python + Pillow, no game data is written by this file.
"""
import struct
from PIL import Image


def encode_slp_rect(width, height, indexes):
    """One frame, one rectangle per row, no transparency."""
    data = bytearray(b"2.0N" + struct.pack("<HH", 1, 0) + b"ArtDesk 1.00 SLP Writer\0")
    body_at = 32 + 32
    outline = bytearray()
    offsets = []
    commands = bytearray()
    cmd_at = body_at + 4 * height

    for y in range(height):
        outline += struct.pack("<HH", 0, 0)
        offsets.append(cmd_at + 4 * height + len(commands))
        row = indexes[y * width:(y + 1) * width]
        for i in range(0, width, 63):
            run = row[i:i + 63]
            commands.append(len(run) << 2)
            commands += bytes(run)
        commands.append(0x0F)

    header = struct.pack("<IIIIiiii", cmd_at, body_at, 0, 0x10, width, height, 0, 0)
    return bytes(data + header + outline +
                 b"".join(struct.pack("<I", o) for o in offsets) + commands)


def image_to_slp(path, background=(36, 28, 20, 255)):
    image = Image.open(path).convert("RGBA")
    width, height = image.size
    canvas = Image.new("RGBA", (width, height), background)
    canvas.alpha_composite(image)
    quantized = canvas.convert("RGB").quantize(colors=256, method=Image.MEDIANCUT)
    return (encode_slp_rect(width, height, list(quantized.getdata())),
            quantized.getpalette()[:768], (width, height))


def jasc(palette):
    lines = ["JASC-PAL", "0100", "256"]
    for i in range(256):
        r, g, b = palette[i * 3:i * 3 + 3] if i * 3 + 2 < len(palette) else (0, 0, 0)
        lines.append(f"{r} {g} {b}")
    return ("\n".join(lines) + "\n").encode("ascii")
