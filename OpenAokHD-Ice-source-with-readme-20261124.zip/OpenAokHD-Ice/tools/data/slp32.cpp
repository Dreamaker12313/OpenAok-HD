// Decode a 32-bit HD SLP frame (properties & 7 == 7) to a PPM.
// Build against the vendored genieutils library, e.g.:
//   g++ -std=c++17 -Ithird_party/genieutils/include tools/data/slp32.cpp \
//       build/.../libgenieutils.a -o slp32
// Then: ./slp32 main_32.slp main.ppm
#include <genie/resource/SlpFile.h>
#include <fstream>
#include <iostream>

int main(int argc, char** argv) {
    if (argc < 3) return 2;
    std::ifstream size_in(argv[1], std::ios::binary | std::ios::ate);
    if (!size_in) return 2;
    const size_t size = static_cast<size_t>(size_in.tellg());
    genie::SlpFile slp(size);
    slp.setFileName(argv[1]);
    slp.load();

    const auto frame = slp.getFrame(0);
    const int width = static_cast<int>(frame->getWidth());
    const int height = static_cast<int>(frame->getHeight());
    if (!frame->is32bit()) {
        std::cerr << "not a 32-bit SLP\n";
        return 1;
    }

    std::ofstream out(argv[2], std::ios::binary);
    out << "P6\n" << width << " " << height << "\n255\n";
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            const uint32_t p = frame->img_data.bgra_channels[y * width + x];
            const unsigned char b = p & 255, g = (p >> 8) & 255, r = (p >> 16) & 255;
            out.put(r); out.put(g); out.put(b);
        }
    }
    return 0;
}
