#!/usr/bin/env python3
"""Convert an HD mod's terrain textures into the pack's terrain.drs.

Usage:
    python3 tools/data/convert_mod_terrain.py \
      --textures mods/foo/resources/_common/terrain/textures \
      --dat mods/foo/resources/_common/dat/empires2_x1_p1.dat \
      --pack /sdcard/Download/OpenAoK-data

Needs NumPy, Pillow, a readable dat and build/data-tools/dump_dat.
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import convert_hd  # noqa: E402
import datfile  # noqa: E402
import slp  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--textures", required=True)
    ap.add_argument("--dat", required=True)
    ap.add_argument("--pack", required=True)
    args = ap.parse_args()
    textures = Path(args.textures)
    dat = Path(args.dat)
    pack = Path(args.pack)
    if not textures.is_dir() or not dat.is_file():
        print("textures or dat missing", file=sys.stderr)
        return 2
    os.environ["AOE_DAT_PATH"] = str(dat)
    os.environ["AOE_DAT_GV"] = "Cysion" if "_x2_" in dat.name else "TC"
    terrains = {t["slp"]: Path(str(t["file"])).stem
                for t in datfile.load()["terrains"].values()
                if t.get("file") and t["file"] not in ("", "None")}
    palette_path = pack / "assets" / "original" / "interfac_extracted" / "50500.bina"
    with open(palette_path, "rb") as fh:
        pal = [tuple(fh.read(3)) for _ in range(256)]
    found = {n.lower().split('_00_')[0]: n for n in os.listdir(textures)}
    mapping = []
    for slp_id, name in sorted(terrains.items()):
        actual = found.get(name.lower())
        if actual:
            mapping.append({"slp": slp_id, "texture": str((textures / actual).relative_to(pack))})
    files = convert_hd.terrain(str(textures), terrains, pal)
    target = pack / "assets" / "original" / "Data" / "terrain.drs"
    if target.exists():
        blob, entries = slp.read_drs(str(target))
        out = {i: ("bin", blob[o:o + s]) for i, (o, s) in entries.items()}
        out.update(files)
    else:
        out = files
    convert_hd.write_drs(str(target), out)
    # The runtime cutter uses this to map PNG files to terrain SLP ids.
    import json
    map_path = pack / "assets" / "extracted_data" / "terrain_map.json"
    map_path.parent.mkdir(parents=True, exist_ok=True)
    map_path.write_text(json.dumps({"terrains": mapping}, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"terrain.drs updated: {len(files)} textures")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
