#!/usr/bin/env python3
"""Overlay Age of Empires II HD mod folders onto an OpenAoK-data pack.

Usage:
    python3 tools/data/apply_mods.py --pack /path/to/OpenAoK-data

Mod folder layout (all parts optional):
    mods/<name>/files/                         # copied verbatim into the pack
    mods/<name>/campaign/*.cpx|*.cpx2          # -> assets/original/Campaign/
    mods/<name>/mainmenu/                       # -> assets/extracted_data/mainmenu/
    mods/<name>/drs/interfac.drs                # merged into Data/interfac.drs by ID
    mods/<name>/drs/graphics.drs                # merged into Data/graphics.drs by ID
    mods/<name>/drs/sounds.drs                  # merged into Data/sounds.drs by ID
    mods/<name>/mod.json                        # optional {"priority": 10}

Mods are applied in ascending priority (higher number wins), then by name.
The pack manifest is rebuilt at the end; re-import the pack into the app.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import struct
import subprocess
import sys
import zipfile
import zlib
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import slp  # noqa: E402
from convert_hd import write_drs  # noqa: E402




def merge_loose_dir(base_path: Path, folder: Path, exts=("slp", "bina", "wav")) -> int:
    """Merge numbered HD loose files (graphics/interface/sounds) by resource ID."""
    if not folder.is_dir():
        return 0
    if base_path.exists():
        base_blob, base_entries = slp.read_drs(str(base_path))
        out = {i: ("bin", base_blob[o:o + s]) for i, (o, s) in base_entries.items()}
    else:
        out = {}
    count = 0
    for src in folder.iterdir():
        if not src.is_file():
            continue
        stem, _, ext = src.name.partition(".")
        if ext.lower() not in exts or not stem.isdigit():
            continue
        fid = int(stem)
        data = src.read_bytes()
        out[fid] = (ext.lower(), data)
        count += 1
    if count:
        base_path.parent.mkdir(parents=True, exist_ok=True)
        write_drs(str(base_path), out)
    return count


def entry_type(data: bytes) -> str:
    if data.startswith(b"2.0N"):
        return "slp"
    if data.startswith(b"JASC-PAL"):
        return "pal"
    return "bin"


def merge_drs(base_path: Path, mod_path: Path) -> int:
    if not base_path.exists():
        shutil.copy2(mod_path, base_path)
        return len(slp.read_drs(str(mod_path))[1])
    base_blob, base_entries = slp.read_drs(str(base_path))
    mod_blob, mod_entries = slp.read_drs(str(mod_path))
    out = {i: ("bin", base_blob[o:o + s]) for i, (o, s) in base_entries.items()}
    for i, (o, s) in mod_entries.items():
        data = mod_blob[o:o + s]
        out[i] = (entry_type(data), data)
    write_drs(str(base_path), out)
    return len(mod_entries)


def rebuild_manifest(pack: Path) -> int:
    entries = []
    for base in ("assets", "fonts", "original_game_1999", "build", "mods"):
        root = pack / base
        if not root.is_dir():
            continue
        for path in root.rglob("*"):
            if path.is_file() and ".unpacked" not in path.parts and not path.name.startswith(".trashed-"):
                entries.append(path.relative_to(pack).as_posix())
    entries.append("version.txt")
    lines = []
    for rel in sorted(set(entries)):
        path = pack / rel
        if not path.exists():
            continue
        data = path.read_bytes()
        lines.append(f"{zlib.crc32(data) & 0xffffffff:08x} {len(data)} {rel}")
    (pack / "manifest.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return len(lines)


def mod_meta(mod: Path) -> dict:
    cfg = mod / "mod.json"
    if cfg.is_file():
        try:
            return json.loads(cfg.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def mod_priority(mod: Path) -> int:
    cfg = mod / "mod.json"
    if cfg.is_file():
        try:
            return int(json.loads(cfg.read_text(encoding="utf-8")).get("priority", 0))
        except Exception:
            pass
    return 0


def apply_mod(pack: Path, mod: Path) -> dict:
    result = {"name": mod.name, "files": 0, "campaign": 0, "mainmenu": 0, "drs": 0, "dat": 0, "terrain": 0}
    converted = mod / "converted"
    if converted.is_dir():
        dst = pack / "assets" / "extracted_data"
        for src in converted.rglob("*"):
            if src.is_file():
                rel = src.relative_to(converted)
                target = dst / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, target)
                result["files"] += 1
    files = mod / "files"
    if files.is_dir():
        for src in files.rglob("*"):
            if src.is_file():
                rel = src.relative_to(files)
                dst = pack / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
                result["files"] += 1
    camp = mod / "campaign"
    if camp.is_dir():
        dst = pack / "assets" / "original" / "Campaign"
        dst.mkdir(parents=True, exist_ok=True)
        for src in camp.iterdir():
            if src.is_file() and src.suffix.lower() in (".cpx", ".cpx2"):
                shutil.copy2(src, dst / src.name)
                result["campaign"] += 1
    mainmenu = mod / "mainmenu"
    if mainmenu.is_dir():
        dst = pack / "assets" / "extracted_data" / "mainmenu"
        for src in mainmenu.rglob("*"):
            if src.is_file():
                rel = src.relative_to(mainmenu)
                target = dst / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, target)
                result["mainmenu"] += 1
    common = mod / "resources" / "_common" / "drs"
    if common.is_dir():
        data_dir = pack / "assets" / "original" / "Data"
        result["drs"] += merge_loose_dir(data_dir / "graphics.drs", common / "graphics", ("slp",))
        result["drs"] += merge_loose_dir(data_dir / "interfac.drs", common / "interface", ("slp", "bina", "wav"))
        result["drs"] += merge_loose_dir(data_dir / "sounds.drs", common / "sounds", ("wav",))
    terrain_textures = mod / "resources" / "_common" / "terrain" / "textures"
    if terrain_textures.is_dir():
        dat_candidates = list((mod / "dat").glob("empires2*.dat")) + list((mod / "resources" / "_common" / "dat").glob("empires2*.dat"))
        if dat_candidates:
            try:
                subprocess.run([sys.executable, str(Path(__file__).resolve().parent / "convert_mod_terrain.py"),
                                "--textures", str(terrain_textures), "--dat", str(dat_candidates[0]),
                                "--pack", str(pack)], check=True)
                result["terrain"] = 1
            except subprocess.CalledProcessError as exc:
                print(f"warning: terrain conversion failed: {exc}", file=sys.stderr)
        else:
            print(f"warning: {mod.name} has terrain textures but no dat to map them", file=sys.stderr)
    dat_dir = mod / "dat"
    if dat_dir.is_dir():
        for src in dat_dir.glob("empires2*.dat"):
            try:
                subprocess.run([sys.executable, str(Path(__file__).resolve().parent / "convert_mod_dat.py"),
                                "--dat", str(src), "--pack", str(pack)], check=True)
                result["dat"] = result.get("dat", 0) + 1
            except subprocess.CalledProcessError as exc:
                print(f"warning: could not convert {src.name}: {exc}", file=sys.stderr)
    drs = mod / "drs"
    if drs.is_dir():
        for src in drs.glob("*.drs"):
            target = pack / "assets" / "original" / "Data" / src.name
            result["drs"] += merge_drs(target, src)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pack", required=True, help="OpenAoK-data folder")
    parser.add_argument("--mods", help="mods folder (default: <pack>/mods)")
    args = parser.parse_args()
    pack = Path(args.pack).resolve()
    mods_dir = Path(args.mods).resolve() if args.mods else pack / "mods"
    if not pack.is_dir():
        print(f"pack not found: {pack}", file=sys.stderr)
        return 2
    mods = []
    unpacked = mods_dir / ".unpacked"
    if mods_dir.is_dir():
        for m in mods_dir.iterdir():
            if m.is_dir() and m.name != ".unpacked":
                if not m.name.endswith(".disabled") and mod_meta(m).get("enabled", True):
                    mods.append(m)
            elif m.is_file() and m.suffix.lower() in (".zip", ".mod"):
                target = unpacked / m.stem
                if target.is_dir():
                    shutil.rmtree(target)
                target.mkdir(parents=True, exist_ok=True)
                with zipfile.ZipFile(m) as z:
                    z.extractall(target)
                # A zip often has one wrapper folder.
                children = [c for c in target.iterdir() if c.is_dir()]
                mods.append(children[0] if len(children) == 1 and not (target / "mod.json").exists() else target)
    mods.sort(key=lambda m: (mod_priority(m), m.name))
    if not mods:
        print(f"no mods in {mods_dir}")
    applied = []
    for mod in mods:
        result = apply_mod(pack, mod)
        result["priority"] = mod_priority(mod)
        meta_cfg = mod_meta(mod)
        result["version"] = meta_cfg.get("version", "")
        result["author"] = meta_cfg.get("author", "")
        result["description"] = meta_cfg.get("description", "")
        applied.append(result)
        print(f"applied {result['name']}: files={result['files']} campaign={result['campaign']} "
              f"mainmenu={result['mainmenu']} drs={result['drs']}")
    meta = pack / "assets" / "extracted_data" / "mods.json"
    meta.parent.mkdir(parents=True, exist_ok=True)
    meta.write_text(json.dumps({"mods": applied}, ensure_ascii=False, indent=1), encoding="utf-8")
    count = rebuild_manifest(pack)
    print(f"manifest rebuilt: {count} files")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
