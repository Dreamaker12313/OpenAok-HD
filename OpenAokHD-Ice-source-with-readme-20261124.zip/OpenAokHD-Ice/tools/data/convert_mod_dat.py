#!/usr/bin/env python3
"""Convert a mod's empires2*.dat into the pack's extracted rules JSON.

Usage:
    python3 tools/data/convert_mod_dat.py --dat mods/foo/dat/empires2_x1_p1.dat \
        --pack /sdcard/Download/OpenAoK-data

This temporarily points the data tools' assets/ at the pack, runs the existing
extractors, and leaves the generated rules/units/buildings/techtree/media JSON
inside assets/extracted_data. A dat dumper must be buildable (CMake) or present
under build/data-tools/dump_dat.
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
TOOLS = ROOT / "tools" / "data"


def run(script: str, env: dict) -> None:
    subprocess.run([sys.executable, str(TOOLS / script)], check=True, env=env)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--dat", required=True)
    ap.add_argument("--pack", required=True)
    args = ap.parse_args()
    dat = Path(args.dat).resolve()
    pack = Path(args.pack).resolve()
    if not dat.is_file() or not (pack / "assets" / "extracted_data").is_dir():
        print("dat or pack missing", file=sys.stderr)
        return 2

    assets = ROOT / "assets"
    temporary = not assets.exists()
    if temporary:
        assets.symlink_to(pack / "assets", target_is_directory=True)
    try:
        env = dict(os.environ)
        env["AOE_DAT_PATH"] = str(dat)
        env["AOE_DAT_GV"] = "Cysion" if "_x2_" in dat.name else "TC"
        for script in ("extract_rules.py", "extract_tables.py", "extract_techtree.py"):
            print("running", script)
            run(script, env)
    finally:
        if temporary and assets.is_symlink():
            assets.unlink()
    print("converted", dat.name, "into", pack / "assets" / "extracted_data")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
