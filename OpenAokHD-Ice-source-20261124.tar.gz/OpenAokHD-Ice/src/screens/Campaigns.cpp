#include "Campaigns.h"

#include "Slides.h"
#include "Widgets.h"
#include "audio/InterfaceSounds.h"
#include "core/Profile.h"
#include "core/Strings.h"
#include "hal/Audio.h"
#include "hal/GraphicCache.h"
#include "hal/TextureManager.h"
#include "hal/stb/stb_image.h"
#include "hal/SlpFile.h"
#include "rendering/Text.h"
#include "scenario/Campaign.h"

#include <algorithm>
#include <unordered_map>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <nlohmann/json.hpp>
#include <sstream>
#include <string>
#include <vector>

namespace Screens::Campaigns {

namespace Text = Rendering::Text;
using Core::Strings::Get;

namespace {

void Click() { HAL::Audio::Play(Audio::InterfaceSound::kButton2, 1.0f, 0.0f); }

constexpr const char* kCampaignDir = "../assets/original/Campaign/";

// A frame of a screen's own art (the campaign screens keep their emblems
// and markers in the background's SLP, after the background), its hotspot
// on the point.
void DrawFrame(SDL_Renderer* r, const Theme& theme, int frame, int x, int y) {
    const HAL::GraphicAtlas* atlas =
        HAL::GraphicCache::Get().GetInterfaceAtlas(theme.background, theme.style.palette);
    if (atlas == nullptr || atlas->base == nullptr || frame <= 0 ||
        frame >= static_cast<int>(atlas->frames.size())) {
        return;
    }
    const HAL::GraphicFrame& f = atlas->frames[static_cast<size_t>(frame)];
    const SDL_Rect dst = {x - f.hotspot_x, y - f.hotspot_y, f.rect.w, f.rect.h};
    SDL_RenderCopy(r, atlas->base, &f.rect, &dst);
}

void DrawAtlasImage(SDL_Renderer* r, uint32_t id, uint32_t palette, const SDL_Rect& dst) {
    const HAL::GraphicAtlas* atlas = HAL::GraphicCache::Get().GetInterfaceAtlas(id, palette);
    if (atlas == nullptr || atlas->base == nullptr || atlas->frames.empty()) return;
    const HAL::GraphicFrame& f = atlas->frames.front();
    SDL_RenderCopy(r, atlas->base, &f.rect, &dst);
}

// A button with the focus: its label lit as though the mouse were over it.
bool DrawPng(SDL_Renderer* r, const std::string& path, const SDL_Rect& dst) {
    if (path.empty()) return false;
    static std::unordered_map<std::string, SDL_Texture*> cache;
    auto found = cache.find(path);
    SDL_Texture* texture = found == cache.end() ? nullptr : found->second;
    if (texture == nullptr) {
        int w = 0, h = 0, channels = 0;
        stbi_uc* pixels = stbi_load(path.c_str(), &w, &h, &channels, 4);
        if (pixels == nullptr || w <= 0 || h <= 0) {
            if (pixels) stbi_image_free(pixels);
            std::ofstream log("/sdcard/Download/OpenAokHD-log.txt", std::ios::app);
            if (log) log << "DIRECT PNG FAIL: " << path << " | " << stbi_failure_reason() << "\n";
            return false;
        }
        SDL_Surface* surface = SDL_CreateRGBSurfaceWithFormatFrom(
            pixels, w, h, 32, 4 * w, SDL_PIXELFORMAT_ABGR8888);
        if (surface != nullptr) {
            texture = SDL_CreateTextureFromSurface(r, surface);
            SDL_FreeSurface(surface);
        }
        stbi_image_free(pixels);
        if (texture == nullptr) return false;
        cache[path] = texture;
    }
    SDL_RenderCopy(r, texture, nullptr, &dst);
    return true;
}

void DrawFocused(SDL_Renderer* r, const Theme& theme, const Button& b, const Pointer& p) {
    State state = StateOf(b, p.x, p.y, p.held);
    if (state == State::Normal) state = State::Hover;
    DrawButton(r, theme, b, state);
}

// One of a radio group, down while it is the one chosen.
void DrawChoice(SDL_Renderer* r, const Theme& theme, const Button& b, bool chosen,
                const Pointer& p) {
    if (!b.visible) return;
    if (!chosen) {
        DrawButton(r, theme, b, StateOf(b, p.x, p.y, p.held));
        return;
    }
    DrawShaded(r, theme, b.rect);
    DrawBevel(r, theme, b.rect, true);
    const SDL_Rect inside = {b.rect.x + 1, b.rect.y + 1, b.rect.w, b.rect.h};
    DrawTextIn(r, b.font, inside, b.label, theme.state, theme.state_shadow);
}

// ---------------------------------------------------------------------------
// The layouts the campaign screens read from interfac.drs: a line a slot --
// its number, the picture button's x y w h, then its name's x y w h. 50344
// is the Campaigns screen's (slot N for camN.cpn), 50344 + N the map of
// campaign N (a slot a scenario). A button whose x is -1 is not there.

struct Slot {
    SDL_Rect button{-1, -1, 0, 0};
    SDL_Rect label{0, 0, 0, 0};
};

constexpr uint32_t kBookLayout = 50344;
constexpr Ink kHdWhite{3, {255, 255, 255, 255}, {0, 0, 0, 255}};

std::vector<Slot> ReadLayout(uint32_t id) {
    std::vector<Slot> slots;
    const HAL::DrsArchive* archive = HAL::GraphicCache::Get().InterfaceArchive();
    std::string text;
    if (archive == nullptr || !HAL::DrsReadText(*archive, id, text)) return slots;
    std::istringstream lines(text);
    std::string line;
    while (std::getline(lines, line)) {
        std::istringstream in(line);
        int number = 0;
        if (!(in >> number) || number < 1) continue;
        // The values a line leaves out.
        int v[8] = {-1, -1, 100, 100, 0, 0, 50, 50};
        for (int& value : v) {
            int read = 0;
            if (!(in >> read)) break;
            value = read;
        }
        if (static_cast<int>(slots.size()) < number) slots.resize(static_cast<size_t>(number));
        slots[static_cast<size_t>(number - 1)] =
            Slot{SDL_Rect{v[0], v[1], v[2], v[3]}, SDL_Rect{v[4], v[5], v[6], v[7]}};
    }
    return slots;
}

std::string CampaignPath(int number) {
    return std::string(kCampaignDir) + "cam" + std::to_string(number) + ".cpn";
}

std::string Player() { return Core::Profile::Current().name; }

// The difficulty the campaign maps and Custom Scenario share: 0 Hardest to
// 4 Easiest, Easy until chosen.
int g_difficulty = 3;

// The drop-down of the difficulties, easiest first, each standing for its
// level (11220 Easiest as 4 ... 11216 Hardest as 0).
DropDown DifficultyList(const SDL_Rect& rect) {
    DropDown d;
    d.rect = rect;
    for (int id = 11220; id >= 11216; --id) d.items.push_back(Get(id));
    d.selected = 4 - std::clamp(g_difficulty, 0, 4);
    d.font = Text::GameFont(11);
    return d;
}
int DifficultyOf(const DropDown& d) { return 4 - d.selected; }

// Where the last scenario game was started from.
struct Origin {
    Id screen = Id::MainMenu;
    int campaign = 0;
    bool from_main_menu = false;
};
Origin g_origin;
std::string g_mission_audio;
std::string g_mission_title;
std::string g_pending_slide;
std::string g_mission_slide;
int g_mission_campaign = 0;
std::string g_intro_error;
bool g_conquerors_page = false;



// ---------------------------------------------------------------------------
// The Campaigns screen: the book of 50232 in its palette
// (cam.sin, 50267), each campaign's emblem a picture button where 50344 puts
// it -- frame 1 + 4(N - 1) of the art, 2 + 4(N - 1) while the mouse is over
// it -- its line below (LANGUAGE.DLL 34928 + 30(N - 1), font 11), and the
// description of the one the mouse is over (that + 1000) in the box at the
// lower left: 452x190 at (34, 354), the art shaded 47% behind the text, a
// two-line sunken border.

constexpr SDL_Rect kBookTitle = {25, 12, 750, 37};
extern int g_dlc_module;
constexpr SDL_Rect kBookBox = {34, 354, 452, 190};
constexpr SDL_Rect kBackButton = {292, 550, 195, 37};
constexpr int kSlots = 8;

struct Book {
    Theme theme;
    std::vector<Slot> slots;
    bool present[kSlots + 1] = {};
    int pressed = 0;
    Button back;
};

Book& TheBook() {
    static Book book;
    return book;
}

int BookSlotAt(const Book& b, int x, int y) {
    for (int n = 1; n <= kSlots && n <= static_cast<int>(b.slots.size()); ++n) {
        const Slot& s = b.slots[static_cast<size_t>(n - 1)];
        if (b.present[n] && s.button.x >= 0 && Hit(s.button, x, y)) return n;
    }
    return 0;
}

int ListString(int number) { return 34928 + 30 * (number - 1); }

void DrawBook(SDL_Renderer* r, const Pointer& p) {
    const char* cards[5] = {"retail1.png", "retail2.png", "retail3.png", "retail4.png", "retail5.png"};
    const char* labels[5] = {"国王时代", "征服者", "失落帝国", "非洲王国", "蛮王崛起"};
    const int x[5] = {131, 301, 131, 301, 131};
    const int y[5] = {44, 44, 121, 121, 198};
    if (!DrawPng(r, "../assets/extracted_data/campaign_menu/background.png", SDL_Rect{0, 0, 800, 600})) {
        SDL_SetRenderDrawColor(r, 196, 166, 120, 255);
        const SDL_Rect full{0, 0, 800, 600};
        SDL_RenderFillRect(r, &full);
    }
    for (int i = 0; i < 5; ++i) {
        const SDL_Rect rect{x[i], y[i], 153, 66};
        if (!DrawPng(r, std::string("../assets/extracted_data/campaign_menu/campaigns/") + cards[i], rect)) {
            DrawShaded(r, TheBook().theme, rect);
            DrawSunken2(r, TheBook().theme, rect);
        }
        const bool over = p.x >= rect.x && p.x < rect.x + rect.w && p.y >= rect.y && p.y < rect.y + rect.h;
        if (over) DrawPng(r, "../assets/extracted_data/campaign_menu/campaigns/over.png", rect);
        DrawPanelText(r, Text::kArial9, SDL_Rect{rect.x, rect.y + 46, rect.w, 18}, labels[i],
                      Align::Centre, Down::Top, true, kHdWhite);
    }
    DrawPanelText(r, Text::kArial9, SDL_Rect{25, 8, 750, 30}, "官方战役",
                  Align::Centre, Down::Top, false, kHdWhite);
    Button back{SDL_Rect{292, 550, 195, 37}, "主菜单", Text::kArial9};
    DrawFocused(r, TheBook().theme, back, p);
    DrawCloseBox(r, TheBook().theme, p.held && Hit(kCloseBox, p.x, p.y));
}

void BookEvent(const SDL_Event& e, const Pointer& p, Request& request) {
    Book& b = TheBook();
    (void)p;
    if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_LEFT) {
        b.pressed = BookSlotAt(b, e.button.x, e.button.y);
    } else if (e.type == SDL_MOUSEBUTTONUP && e.button.button == SDL_BUTTON_LEFT) {
        const int x[5] = {131, 301, 131, 301, 131};
        const int y[5] = {44, 44, 121, 121, 198};
        int card = -1;
        for (int i = 0; i < 5; ++i)
            if (Hit(SDL_Rect{x[i], y[i], 153, 66}, e.button.x, e.button.y)) card = i;
        if (card >= 0) {
            Click();
            if (card == 0) {
                OpenCampaignMap(1, false);
            } else if (card == 1) {
                PrepareConquerors();
                Open(Id::CustomCampaigns);
            } else {
                g_dlc_module = card == 2 ? 2 : (card == 3 ? 3 : 4);
                PrepareDlc();
                Open(Id::DlcCampaign);
            }
        } else if (Hit(SDL_Rect{292, 550, 195, 37}, e.button.x, e.button.y)) {
            Click();
            Open(Id::MainMenu);
        } else if (Hit(kCloseBox, e.button.x, e.button.y)) {
            request.kind = Request::Kind::Quit;
        }
        b.pressed = 0;
    } else if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_ESCAPE) {
        Open(Id::MainMenu);
    }
}

// ---------------------------------------------------------------------------
// A campaign's map: its art and palette from cam<N>.sin (50250 + N), its
// scenarios' markers and names where 50344 + N puts them. Only the scenarios
// up to the furthest one opened are there; the learning campaign shows all
// seven. A marker is frame
// 1 + 4i of the art, 2 + 4i under the mouse; the learning campaign's won
// scenarios keep frame 2 + 4i, its faded one. A name is the scenario's line
// of LANGUAGE.DLL, font 11, centred and wrapped in its box: black on Saladin's,
// Barbarossa's and Wallace's maps, the parchment's colour on a black shadow
// on the darker maps of Joan of Arc and Genghis Khan.
//
// The title is the campaign's name (font 1, across the top), Wallace's in
// black with "Learning Campaign" under it and the note at the lower left;
// every other has the difficulty at the lower right. Its button back is
// "Campaign Menu" -- "Main Menu" for the learning campaign opened from the
// main menu (Learn to Play).

constexpr int kLearning = 8;
// cam<N>.sin: 50250 + N.
constexpr uint32_t kMapSinBase = 50250;
constexpr SDL_Rect kMapTitle = {25, 12, 750, 37};
constexpr SDL_Rect kWallaceTitle = {25, 4, 750, 200};
constexpr SDL_Rect kWallaceSubtitle = {245, 33, 300, 200};
constexpr SDL_Rect kWallaceNote = {4, 515, 283, 80};
constexpr SDL_Rect kDifficultyLabel = {602, 420, 190, 20};
constexpr SDL_Rect kDifficultyList = {607, 444, 130, 24};
constexpr int kLearningScenarios = 7;

struct Map {
    Theme theme;
    int number = 0;
    bool from_main_menu = false;
    Scenario::Campaign campaign;
    bool loaded = false;
    std::vector<Slot> slots;
    int shown = 0;
    std::vector<bool> won;     // by scenario, from the progress book
    int pressed = -1;
    DropDown difficulty;
    Button back;
};

Map& TheMap() {
    static Map map;
    return map;
}

int MapSlotAt(const Map& m, int x, int y) {
    for (int i = 0; i < m.shown && i < static_cast<int>(m.slots.size()); ++i) {
        const Slot& s = m.slots[static_cast<size_t>(i)];
        if (s.button.x >= 0 && Hit(s.button, x, y)) return i;
    }
    return -1;
}

Ink LabelInk(int number) {
    if (number == 1 || number == 3) return Ink{1, {0, 0, 0, 255}, {227, 212, 182, 255}};
    return kBlackInk;
}

void DrawMap(SDL_Renderer* r, const Pointer& p) {
    Map& m = TheMap();
    const Theme& theme = m.theme;
    DrawBackground(r, theme);
    const Scenario::CampaignStrings strings = Scenario::StringsOf(m.campaign);
    const std::string name = strings.name >= 0 ? Get(strings.name) : m.campaign.name;
    if (m.number == kLearning) {
        DrawPanelText(r, Text::GameFont(1), kWallaceTitle, name, Align::Centre, Down::Top, false,
                      kBlackInk);
        DrawPanelText(r, Text::GameFont(11), kWallaceSubtitle, Get(35147), Align::Centre, Down::Top,
                      false, kBlackInk);
        DrawPanelText(r, Text::GameFont(11), kWallaceNote, Get(36167), Align::Left, Down::Top, true,
                      kBlackInk);
    } else {
        DrawPanelText(r, Text::GameFont(1), kMapTitle, name, Align::Centre, Down::Top, false,
                      SinInk(theme));
    }
    const int over = MapSlotAt(m, p.x, p.y);
    for (int i = 0; i < m.shown && i < static_cast<int>(m.slots.size()); ++i) {
        const Slot& s = m.slots[static_cast<size_t>(i)];
        if (s.button.x < 0) continue;
        const bool won = m.number == kLearning && m.won[static_cast<size_t>(i)];
        const int frame = (won || i == over ? 2 : 1) + 4 * i;
        DrawFrame(r, theme, frame, s.button.x, s.button.y);
        const int label = Scenario::ScenarioString(m.campaign, i);
        DrawPanelText(r, Text::GameFont(11), s.label,
                      label >= 0 ? Get(label) : m.campaign.scenarios[static_cast<size_t>(i)].name,
                      Align::Centre, Down::Top, true, LabelInk(m.number));
    }
    DrawFocused(r, theme, m.back, p);
    DrawCloseBox(r, theme, p.held && Hit(kCloseBox, p.x, p.y));
    if (m.number != kLearning) {
        DrawPanelText(r, Text::GameFont(0), kDifficultyLabel, Get(11215), Align::Left, Down::Top,
                      false, SinInk(theme));
        DrawDropDown(r, theme, m.difficulty, p.x, p.y, p.held, kMenuHeight);
    }
}

void MapEvent(const SDL_Event& e, const Pointer& p, Request& request) {
    Map& m = TheMap();
    (void)p;
    if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_LEFT) {
        if (m.number != kLearning && (m.difficulty.open || Hit(m.difficulty.rect, e.button.x, e.button.y))) {
            ClickDropDown(m.difficulty, e.button.x, e.button.y, kMenuHeight);
            g_difficulty = DifficultyOf(m.difficulty);
            m.pressed = -1;
            return;
        }
        m.pressed = MapSlotAt(m, e.button.x, e.button.y);
    } else if (e.type == SDL_MOUSEBUTTONUP && e.button.button == SDL_BUTTON_LEFT) {
        const int slot = MapSlotAt(m, e.button.x, e.button.y);
        if (slot >= 0 && slot == m.pressed) {
            Click();
            g_origin = Origin{Id::CampaignMap, m.number, m.from_main_menu};
            {
                const Scenario::CampaignStrings strings = Scenario::StringsOf(m.campaign);
                g_mission_title = strings.name >= 0 ? Get(strings.name) : m.campaign.name;
                const int idx = slot + 1;
                if (m.number == 8)
                    g_pending_slide = "c8s" + std::to_string(idx) + "_beg";
                else if (m.number >= 5 && m.number <= 7)
                    g_pending_slide = "x" + std::to_string(m.number - 4) + "s" + std::to_string(idx) + "_beg";
                else if (m.number >= 1 && m.number <= 4)
                    g_pending_slide = "c" + std::to_string(m.number) + "s" + std::to_string(idx) + "_beg";
                g_mission_slide = g_pending_slide;
                g_mission_campaign = m.number;
            }
            {
                const int idx = slot + 1;
                std::string file;
                if (m.number == 8) file = "c8s" + std::to_string(idx);
                else if (m.number >= 1 && m.number <= 4) file = "c" + std::to_string(m.number) + "s" + std::to_string(idx);
                else if (m.number >= 5 && m.number <= 7) file = "xc" + std::to_string(m.number - 4) + "s" + std::to_string(idx);
                if (!file.empty()) {
                    const std::string audio = "../assets/original/Sound/campaign/" + file + ".mp3";
                    std::error_code ec;
                    if (std::filesystem::exists(audio, ec)) g_mission_audio = audio;
                }
            }
            request.kind = Request::Kind::StartScenario;
            request.path = m.campaign.path;
            request.entry = slot;
            request.setup.difficulty = g_difficulty;
        } else if (Hit(m.back.rect, e.button.x, e.button.y)) {
            Click();
            Open(m.from_main_menu ? Id::MainMenu : Id::Campaigns);
        } else if (Hit(kCloseBox, e.button.x, e.button.y)) {
            request.kind = Request::Kind::Quit;
        }
        m.pressed = -1;
    } else if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_ESCAPE) {
        Open(m.from_main_menu ? Id::MainMenu : Id::Campaigns);
    }
}

// ---------------------------------------------------------------------------
// Custom Scenario: on the plain parchment (scr2, 50052), laid out at
// 640x480 and scaled by the screen's size over the layout's, so at 800x600
// everything is a quarter larger than the numbers below. Its text is plain
// black.

constexpr SDL_Rect Scaled(int x, int y, int w, int h) {
    return SDL_Rect{x * kMenuWidth / 640, y * kMenuHeight / 480, w * kMenuWidth / 640,
                    h * kMenuHeight / 480};
}
constexpr SDL_Rect kSelectTitle = Scaled(20, 10, 600, 30);
constexpr SDL_Rect kSelectLabel = Scaled(70, 50, 300, 20);
constexpr SDL_Rect kSelectList = Scaled(70, 70, 500, 290);
constexpr SDL_Rect kSelectDifficultyLabel = Scaled(65, 370, 200, 20);
constexpr SDL_Rect kSelectDifficulty = Scaled(70, 390, 130, 24);
constexpr SDL_Rect kSelectOk = Scaled(170, 440, 140, 30);
constexpr SDL_Rect kSelectCancel = Scaled(330, 440, 140, 30);

struct Select {
    Theme theme;
    ListBox list;
    std::vector<std::string> paths;
    DropDown difficulty;
    Button ok, cancel;
};

Select& TheSelect() {
    static Select select;
    return select;
}

void DrawSelect(SDL_Renderer* r, const Pointer& p) {
    Select& s = TheSelect();
    const Theme& theme = s.theme;
    DrawBackground(r, theme);
    DrawPanelText(r, Text::GameFont(1), kSelectTitle, Get(9722), Align::Centre, Down::Top, false,
                  kBlackInk);
    DrawPanelText(r, Text::GameFont(4), kSelectLabel, Get(9726), Align::Left, Down::Top, false,
                  kBlackInk);
    DrawListBox(r, theme, s.list, p.x, p.y);
    DrawPanelText(r, Text::GameFont(4), kSelectDifficultyLabel, Get(11215), Align::Left,
                  Down::Top, false, kBlackInk);
    Button ok = s.ok;
    ok.enabled = s.list.selected >= 0;
    DrawButton(r, theme, ok, StateOf(ok, p.x, p.y, p.held));
    DrawButton(r, theme, s.cancel, StateOf(s.cancel, p.x, p.y, p.held));
    DrawDropDown(r, theme, s.difficulty, p.x, p.y, p.held, kMenuHeight);
    DrawCloseBox(r, theme, p.held && Hit(kCloseBox, p.x, p.y));
}

void SelectEvent(const SDL_Event& e, const Pointer& p, Request& request) {
    Select& s = TheSelect();
    (void)p;
    if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_LEFT) {
        if (s.difficulty.open || Hit(s.difficulty.rect, e.button.x, e.button.y)) {
            ClickDropDown(s.difficulty, e.button.x, e.button.y, kMenuHeight);
            g_difficulty = DifficultyOf(s.difficulty);
            return;
        }
        ClickListBox(s.list, e.button.x, e.button.y);
    } else if (e.type == SDL_MOUSEBUTTONUP && e.button.button == SDL_BUTTON_LEFT) {
        if (Hit(s.ok.rect, e.button.x, e.button.y) && s.list.selected >= 0) {
            Click();
            g_origin = Origin{Id::ScenarioSelect, 0, false};
            request.kind = Request::Kind::StartScenario;
            request.path = s.paths[static_cast<size_t>(s.list.selected)];
            request.entry = -1;
            request.setup.difficulty = g_difficulty;
        } else if (Hit(s.cancel.rect, e.button.x, e.button.y)) {
            Click();
            Open(Id::MainMenu);
        } else if (Hit(kCloseBox, e.button.x, e.button.y)) {
            request.kind = Request::Kind::Quit;
        }
    } else if (e.type == SDL_MOUSEWHEEL) {
        const int most = std::max(0, static_cast<int>(s.list.items.size()) - ListBoxRows(s.list));
        s.list.scroll = std::clamp(s.list.scroll - e.wheel.y, 0, most);
    } else if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_ESCAPE) {
        Open(Id::MainMenu);
    }
}

// ---------------------------------------------------------------------------
// Custom Campaign: the Campaign Selection Screen, on the plain parchment
// (scr2) as Custom Scenario is, laid out at 640x480 and scaled the same way.
// The custom campaigns -- any but the game's five -- above; the chosen one's
// scenarios below, from its first to the furthest the player has opened, the
// furthest chosen; the difficulty; OK and Cancel.

constexpr SDL_Rect kCustomTitle = Scaled(20, 10, 600, 30);
constexpr SDL_Rect kCustomCampaignLabel = Scaled(72, 80, 200, 20);
constexpr SDL_Rect kCustomCampaigns = Scaled(70, 100, 500, 120);
constexpr SDL_Rect kCustomScenarioLabel = Scaled(72, 228, 200, 20);
constexpr SDL_Rect kCustomScenarios = Scaled(70, 248, 500, 120);
constexpr SDL_Rect kCustomModuleLabel = Scaled(70, 30, 200, 20);
constexpr SDL_Rect kCustomModules = Scaled(70, 50, 470, 24);

struct Custom {
    ListBox campaigns;
    ListBox scenarios;
    std::vector<std::string> paths;
    std::vector<std::string> all_paths;
    int module = 0;
    Button modules[5];
    Scenario::Campaign chosen;
    int shown = -1;           // the campaign whose scenarios are listed
    DropDown difficulty;
    Button ok, cancel;
};

Custom& TheCustom() {
    static Custom custom;
    return custom;
}

// The chosen campaign's scenarios, from the first to the furthest opened.
void ListScenarios(Custom& c) {
    c.shown = c.campaigns.selected;
    c.scenarios = ListBox{kCustomScenarios, {}, -1, 0, Text::GameFont(11)};
    if (c.shown < 0 || !Scenario::LoadCampaign(c.paths[static_cast<size_t>(c.shown)], c.chosen)) return;
    const Scenario::Progress::Book book = Scenario::Progress::Load();
    const int open = std::min(static_cast<int>(c.chosen.scenarios.size()),
                              Scenario::Progress::Unlocked(book, Player(), c.chosen.name));
    for (int i = 0; i < open; ++i) {
        const int string_id = Scenario::ScenarioString(c.chosen, i);
        c.scenarios.items.push_back(string_id >= 0 ? Get(string_id)
                                                   : c.chosen.scenarios[static_cast<size_t>(i)].name);
    }
    c.scenarios.selected = open - 1;
    c.scenarios.scroll = std::max(0, open - ListBoxRows(c.scenarios));
}

void DrawCustom(SDL_Renderer* r, const Pointer& p) {
    Custom& c = TheCustom();
    const Theme& theme = TheSelect().theme;
    DrawBackground(r, theme);
    DrawPanelText(r, Text::GameFont(1), kCustomTitle, g_conquerors_page ? "征服者战役" : Get(11213),
                  Align::Centre, Down::Top, false, kBlackInk);
    DrawPanelText(r, Text::GameFont(4), kCustomModuleLabel, "战役模块", Align::Left, Down::Top, false, kBlackInk);
    for (int i = 0; i < 5; ++i) DrawChoice(r, theme, c.modules[i], i == c.module, p);
    DrawPanelText(r, Text::GameFont(4), kCustomCampaignLabel, Get(11214), Align::Left, Down::Top, false, kBlackInk);
    DrawListBox(r, theme, c.campaigns, p.x, p.y);
    DrawPanelText(r, Text::GameFont(4), kCustomScenarioLabel, Get(9726), Align::Left, Down::Top, false, kBlackInk);
    DrawListBox(r, theme, c.scenarios, p.x, p.y);
    DrawPanelText(r, Text::GameFont(4), kSelectDifficultyLabel, Get(11215), Align::Left, Down::Top, false,
                  kBlackInk);
    Button ok = c.ok;
    ok.enabled = c.scenarios.selected >= 0;
    DrawButton(r, theme, ok, StateOf(ok, p.x, p.y, p.held));
    DrawButton(r, theme, c.cancel, StateOf(c.cancel, p.x, p.y, p.held));
    DrawDropDown(r, theme, c.difficulty, p.x, p.y, p.held, kMenuHeight);
    DrawCloseBox(r, theme, p.held && Hit(kCloseBox, p.x, p.y));
}

void RefreshCustom() {
    Custom& c = TheCustom();
    const int module = std::clamp(c.module, 0, 4);
    c.paths.clear();
    for (const std::string& path : c.all_paths) {
        const std::string name = std::filesystem::path(path).stem().string();
        bool keep = false;
        if (module == 0) keep = name.rfind("cam", 0) == 0 && name.rfind("xcam", 0) != 0;
        if (module == 1) keep = name.rfind("xcam", 0) == 0;
        if (module == 2) keep = name.rfind("失落-", 0) == 0;
        if (module == 3) keep = name.rfind("非洲-", 0) == 0;
        if (module == 4) keep = name.rfind("蛮王-", 0) == 0;
        if (keep) c.paths.push_back(path);
    }
    c.campaigns = ListBox{kCustomCampaigns, {}, c.paths.empty() ? -1 : 0, 0, Text::GameFont(11)};
    for (const std::string& path : c.paths) {
        Scenario::Campaign campaign;
        std::string label = std::filesystem::path(path).stem().string();
        if (Scenario::LoadCampaign(path, campaign)) {
            const Scenario::CampaignStrings strings = Scenario::StringsOf(campaign);
            if (strings.name >= 0) label = Get(strings.name);
        }
        c.campaigns.items.push_back(std::move(label));
    }
    ListScenarios(c);
}

int g_dlc_module = 3;

void CustomEvent(const SDL_Event& e, Request& request) {
    Custom& c = TheCustom();
    if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_LEFT) {
        if (c.difficulty.open || Hit(c.difficulty.rect, e.button.x, e.button.y)) {
            ClickDropDown(c.difficulty, e.button.x, e.button.y, kMenuHeight);
            g_difficulty = DifficultyOf(c.difficulty);
            return;
        }
        if (ClickListBox(c.campaigns, e.button.x, e.button.y)) {
            if (c.campaigns.selected != c.shown) ListScenarios(c);
            return;
        }
        ClickListBox(c.scenarios, e.button.x, e.button.y);
    } else if (e.type == SDL_MOUSEBUTTONUP && e.button.button == SDL_BUTTON_LEFT) {
        for (int i = 0; i < 5; ++i) {
            if (Hit(c.modules[i].rect, e.button.x, e.button.y)) {
                if (i >= 2) {
                    g_dlc_module = i;
                    PrepareDlc();
                    Open(Id::DlcCampaign);
                } else {
                    c.module = i;
                    RefreshCustom();
                }
                Click();
                return;
            }
        }
        if (Hit(c.ok.rect, e.button.x, e.button.y) && c.scenarios.selected >= 0) {
            Click();
            g_origin = Origin{Id::CustomCampaigns, 0, false};
            request.kind = Request::Kind::StartScenario;
            request.path = c.paths[static_cast<size_t>(c.shown)];
            request.entry = c.scenarios.selected;
            request.setup.difficulty = g_difficulty;
        } else if (Hit(c.cancel.rect, e.button.x, e.button.y)) {
            Click();
            Open(Id::MainMenu);
        } else if (Hit(kCloseBox, e.button.x, e.button.y)) {
            request.kind = Request::Kind::Quit;
        }
    } else if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_ESCAPE) {
        Open(Id::MainMenu);
    }
}

// ---------------------------------------------------------------------------
// The Campaign Editor, from the Map Editor's menu: on the parchment of scr4,
// at 800x600. The campaign's file name, typed or chosen from the campaigns
// there are, and Save; the scenarios to choose from, Add and Remove; the
// campaign's scenarios in the order they are played, Up and Down; OK and
// Cancel. A campaign is saved under its name in Screens::CampaignsDir().

constexpr SDL_Rect kEditorTitle = {25, 12, 750, 37};
constexpr SDL_Rect kEditorFileLabel = {100, 100, 260, 20};
constexpr SDL_Rect kEditorFile = {100, 120, 380, 24};
constexpr SDL_Rect kEditorName = {100, 120, 360, 24};
constexpr SDL_Rect kEditorSave = {500, 120, 200, 30};
constexpr SDL_Rect kEditorScenariosLabel = {100, 160, 200, 20};
constexpr SDL_Rect kEditorScenarios = {100, 180, 600, 130};
constexpr SDL_Rect kEditorAdd = {360, 320, 160, 30};
constexpr SDL_Rect kEditorRemove = {540, 320, 160, 30};
constexpr SDL_Rect kEditorChosenLabel = {100, 340, 200, 20};
constexpr SDL_Rect kEditorChosen = {100, 360, 500, 130};
constexpr SDL_Rect kEditorUp = {610, 360, 90, 30};
constexpr SDL_Rect kEditorDown = {610, 400, 90, 30};
constexpr SDL_Rect kEditorOk = {212, 550, 175, 37};
constexpr SDL_Rect kEditorCancel = {412, 550, 175, 37};
constexpr size_t kCampaignNameLength = 255;

struct CampaignEditor {
    Theme theme;
    Theme dialog;
    DropDown file;
    std::vector<std::string> file_paths;
    TextField name;
    ListBox scenarios;
    std::vector<std::string> scenario_paths;
    ListBox chosen;
    std::vector<Scenario::CampaignScenario> entries;
    Button save, add, remove, up, down, ok, cancel;
    bool dirty = false;
    // A message; a question asks Yes or No.
    Notice notice;
    Button no;
    bool asking = false;
};

CampaignEditor& TheEditor() {
    static CampaignEditor editor;
    return editor;
}

void ShowEntries(CampaignEditor& c) {
    c.chosen.items.clear();
    for (const auto& e : c.entries) c.chosen.items.push_back(e.name);
    if (c.chosen.selected >= static_cast<int>(c.entries.size())) c.chosen.selected = static_cast<int>(c.entries.size()) - 1;
}

void ListCampaigns(CampaignEditor& c) {
    c.file_paths = CustomCampaigns();
    std::vector<std::string> names;
    for (const auto& path : c.file_paths) names.push_back(std::filesystem::path(path).stem().string());
    c.file = DropDown{kEditorFile, names, -1};
    c.file.font = Text::GameFont(11);
}

void LoadInto(CampaignEditor& c, const std::string& path) {
    Scenario::Campaign campaign;
    if (!Scenario::LoadCampaign(path, campaign)) return;
    c.entries.clear();
    for (size_t i = 0; i < campaign.scenarios.size(); ++i) {
        Scenario::CampaignScenario e{campaign.scenarios[i].name, campaign.scenarios[i].file, {}};
        if (Scenario::ReadCampaignScenario(path, static_cast<int>(i), e.bytes)) c.entries.push_back(std::move(e));
    }
    c.name.text = campaign.name;
    c.chosen.selected = c.entries.empty() ? -1 : 0;
    ShowEntries(c);
    c.dirty = false;
}

// Saves the campaign; false, with the reason shown, when it cannot be.
bool SaveCampaign(CampaignEditor& c) {
    if (c.name.text.empty()) {
        OpenNotice(c.notice, c.dialog, Get(11212), Get(4001));
        return false;
    }
    if (c.entries.empty()) {
        OpenNotice(c.notice, c.dialog, Get(11211), Get(4001));
        return false;
    }
    if (!Scenario::WriteCampaign(CampaignsDir() + c.name.text + ".cpn", c.name.text, c.entries)) return false;
    c.dirty = false;
    ListCampaigns(c);
    return true;
}

void DrawCampaignEditor(SDL_Renderer* r, const Pointer& p) {
    CampaignEditor& c = TheEditor();
    const Theme& theme = c.theme;
    DrawBackground(r, theme);
    DrawPanelText(r, Text::GameFont(1), kEditorTitle, Get(11201), Align::Centre, Down::Top, false, kBlackInk);
    DrawPanelText(r, Text::GameFont(4), kEditorFileLabel, Get(11202), Align::Left, Down::Top, false, kBlackInk);
    DrawPanelText(r, Text::GameFont(4), kEditorScenariosLabel, Get(11207), Align::Left, Down::Top, false, kBlackInk);
    DrawListBox(r, theme, c.scenarios, p.x, p.y);
    DrawPanelText(r, Text::GameFont(4), kEditorChosenLabel, Get(11208), Align::Left, Down::Top, false, kBlackInk);
    DrawListBox(r, theme, c.chosen, p.x, p.y);
    Button add = c.add, remove = c.remove, up = c.up, down = c.down;
    add.enabled = c.scenarios.selected >= 0;
    remove.enabled = c.chosen.selected >= 0;
    up.enabled = c.chosen.selected > 0;
    down.enabled = c.chosen.selected >= 0 && c.chosen.selected + 1 < static_cast<int>(c.entries.size());
    const Button* buttons[] = {&c.save, &add, &remove, &up, &down, &c.ok, &c.cancel};
    for (const Button* b : buttons) {
        DrawButton(r, theme, *b, StateOf(*b, p.x, p.y, p.held));
    }
    // The name typed over the list of campaigns, its arrow beside it.
    DropDown file = c.file;
    file.items.insert(file.items.begin(), std::string{});
    DrawDropDown(r, theme, c.file.open ? c.file : file, p.x, p.y, p.held, kMenuHeight);
    if (!c.file.open) DrawTextField(r, theme, c.name);
    DrawNotice(r, c.dialog, c.notice, p);
    if (c.notice.open && c.asking) DrawButton(r, c.dialog, c.no, StateOf(c.no, p.x, p.y, p.held));
    DrawCloseBox(r, theme, p.held && Hit(kCloseBox, p.x, p.y));
}

void CampaignEditorEvent(const SDL_Event& e, Request& request) {
    CampaignEditor& c = TheEditor();
    const bool down = e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_LEFT;
    const bool up = e.type == SDL_MOUSEBUTTONUP && e.button.button == SDL_BUTTON_LEFT;
    if (c.notice.open) {
        if (up && Hit(c.notice.ok.rect, e.button.x, e.button.y)) {
            Click();
            c.notice.open = false;
            // Saving the changes asked about, then out.
            if (c.asking && SaveCampaign(c)) Open(Id::MainMenu);
        } else if (up && c.asking && Hit(c.no.rect, e.button.x, e.button.y)) {
            Click();
            c.notice.open = false;
            Open(Id::MainMenu);
        }
        return;
    }
    if (TypeIntoField(c.name, e)) {
        c.dirty = true;
        return;
    }
    if (down) {
        if (c.file.open || Hit(SDL_Rect{kEditorName.x + kEditorName.w, kEditorFile.y,
                                        kEditorFile.w - kEditorName.w, kEditorFile.h}, e.button.x, e.button.y)) {
            const int before = c.file.selected;
            ClickDropDown(c.file, e.button.x, e.button.y, kMenuHeight);
            if (!c.file.open && c.file.selected >= 0 && c.file.selected != before) {
                LoadInto(c, c.file_paths[static_cast<size_t>(c.file.selected)]);
            }
            return;
        }
        c.name.focused = Hit(kEditorName, e.button.x, e.button.y);
        if (ClickListBox(c.scenarios, e.button.x, e.button.y)) return;
        ClickListBox(c.chosen, e.button.x, e.button.y);
    } else if (up) {
        const int at = c.chosen.selected;
        if (Hit(c.save.rect, e.button.x, e.button.y)) {
            Click();
            SaveCampaign(c);
        } else if (Hit(c.add.rect, e.button.x, e.button.y) && c.scenarios.selected >= 0) {
            Click();
            const std::filesystem::path path = c.scenario_paths[static_cast<size_t>(c.scenarios.selected)];
            std::ifstream in(path, std::ios::binary);
            Scenario::CampaignScenario entry{path.stem().string(), path.filename().string(),
                                             {std::istreambuf_iterator<char>(in), std::istreambuf_iterator<char>()}};
            // After the one chosen, or at the end.
            const size_t place = at >= 0 ? static_cast<size_t>(at) + 1 : c.entries.size();
            c.entries.insert(c.entries.begin() + static_cast<long>(place), std::move(entry));
            c.chosen.selected = static_cast<int>(place);
            ShowEntries(c);
            c.dirty = true;
        } else if (Hit(c.remove.rect, e.button.x, e.button.y) && at >= 0) {
            Click();
            c.entries.erase(c.entries.begin() + at);
            ShowEntries(c);
            c.dirty = true;
        } else if (Hit(c.up.rect, e.button.x, e.button.y) && at > 0) {
            Click();
            std::swap(c.entries[static_cast<size_t>(at)], c.entries[static_cast<size_t>(at - 1)]);
            c.chosen.selected = at - 1;
            ShowEntries(c);
            c.dirty = true;
        } else if (Hit(c.down.rect, e.button.x, e.button.y) && at >= 0 &&
                   at + 1 < static_cast<int>(c.entries.size())) {
            Click();
            std::swap(c.entries[static_cast<size_t>(at)], c.entries[static_cast<size_t>(at + 1)]);
            c.chosen.selected = at + 1;
            ShowEntries(c);
            c.dirty = true;
        } else if (Hit(c.ok.rect, e.button.x, e.button.y)) {
            Click();
            if (!c.dirty || SaveCampaign(c)) Open(Id::MainMenu);
        } else if (Hit(c.cancel.rect, e.button.x, e.button.y)) {
            Click();
            if (c.dirty) {
                // "Do you want to save your changes to campaign %s?"
                char text[512];
                std::snprintf(text, sizeof(text), Get(11209).c_str(), c.name.text.c_str());
                OpenNotice(c.notice, c.dialog, text, Get(4003));
                c.asking = true;
                c.no = c.notice.ok;
                c.no.label = Get(4004);
                c.notice.ok.rect.x -= c.notice.ok.rect.w / 2 + 8;
                c.no.rect.x += c.no.rect.w / 2 + 8;
            } else {
                Open(Id::MainMenu);
            }
        } else if (Hit(kCloseBox, e.button.x, e.button.y)) {
            request.kind = Request::Kind::Quit;
        }
    } else if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_ESCAPE) {
        Open(Id::MainMenu);
    }
}

// ---------------------------------------------------------------------------
// The scenario's instructions before its game: the "Mission Dialog", on
// the loading screen's art (scr9, 50060). Across the top the
// scenario's name (font 1, centred in 794x40 at (3, 12)); its map picture,
// when it has one, at (144, 97) -- the 548x288 of the parchment the editor's
// scenariobkg.bmp is cut to; below, the text in a 553x122 box at (142, 405),
// font 11, black on a grey shadow, with a scroll
// bar; along the bottom History, Instructions and Hints (10801, 10802,
// 10807) at x 5, 205 and 405 and OK at 605, each 190x37 at y 560.
//
// The instructions show first, else the history, else the hints; the three
// buttons are there only when more than one of the texts is, and the box
// only when one is.

constexpr SDL_Rect kMissionTitle = {3, 12, 794, 40};
constexpr SDL_Point kMissionMap = {144, 97};
constexpr SDL_Rect kMissionText = {205, 120, 375, 260};
constexpr int kScrollW = 10;
constexpr Ink kMissionInk{2, {0, 0, 0, 255}, {200, 200, 200, 255}};

enum Tab : int { kHistory, kInstructions, kHints, kTabs };
constexpr int kTabText[kTabs] = {Scenario::kHistory, Scenario::kInstructions, Scenario::kHints};
constexpr int kTabLabel[kTabs] = {10801, 10802, 10807};

struct Mission {
    Theme theme;
    std::string title;
    std::string texts[kTabs];
    int tab = kInstructions;
    bool tabs_shown = false;
    bool text_shown = false;
    int scroll = 0;
    uint32_t next_scroll = 0;
    Button buttons[kTabs];
    Button ok;
    Button replay;
    SDL_Texture* picture = nullptr;
    int picture_w = 0, picture_h = 0;
};

Mission& TheMission() {
    static Mission mission;
    return mission;
}

// The scenario's own map picture, 8 bits a pixel in its own palette, rows
// bottom up and padded to four bytes as a BMP keeps them.
SDL_Texture* PictureOf(SDL_Renderer* r, const Scenario::Bitmap& bitmap) {
    if (bitmap.width <= 0 || bitmap.height <= 0 || bitmap.pixels.empty()) return nullptr;
    const size_t stride = bitmap.pixels.size() / static_cast<size_t>(bitmap.height);
    if (stride < static_cast<size_t>(bitmap.width)) return nullptr;
    SDL_Surface* s = SDL_CreateRGBSurfaceWithFormat(0, bitmap.width, bitmap.height, 32,
                                                    SDL_PIXELFORMAT_ARGB8888);
    if (s == nullptr) return nullptr;
    auto* out = static_cast<uint32_t*>(s->pixels);
    for (int y = 0; y < bitmap.height; ++y) {
        const uint8_t* row = bitmap.pixels.data() + static_cast<size_t>(bitmap.height - 1 - y) * stride;
        for (int x = 0; x < bitmap.width; ++x) {
            const uint8_t index = row[x];
            const uint32_t rgb = index < bitmap.palette.size() ? bitmap.palette[index] : 0;
            out[y * (s->pitch / 4) + x] = 0xFF000000u | rgb;
        }
    }
    SDL_Texture* texture = SDL_CreateTextureFromSurface(r, s);
    SDL_FreeSurface(s);
    return texture;
}

const Scenario::File* g_mission_file = nullptr;

int MissionLines(const Mission& m) {
    return static_cast<int>(
        PanelLines(Text::GameFont(11), m.texts[m.tab], PanelWrapWidth(kMissionText.w - kScrollW, 0), true)
            .size());
}
int MissionRows() { return kMissionText.h / std::max(1, PanelPitch(Text::GameFont(11))); }

void DrawMission(SDL_Renderer* r, const Pointer& p) {
    HAL::Audio::PumpNarration();
    Mission& m = TheMission();
    const Theme& theme = m.theme;
    if (g_mission_file != nullptr && m.picture == nullptr) {
        m.picture = PictureOf(r, g_mission_file->bitmap);
        if (m.picture != nullptr) {
            m.picture_w = g_mission_file->bitmap.width;
            m.picture_h = g_mission_file->bitmap.height;
        }
    }
    DrawBackground(r, theme);
    DrawPanelText(r, Text::GameFont(1), kMissionTitle, m.title, Align::Centre, Down::Centre,
                  false, SinInk(theme));
    if (m.text_shown) {
        const int most = std::max(0, MissionLines(m) - MissionRows());
        const uint32_t now = SDL_GetTicks();
        if (now >= m.next_scroll && m.scroll < most) {
            ++m.scroll;
            m.next_scroll = now + 140;
        } else if (m.scroll >= most) {
            m.next_scroll = now + 1000;
        }
    }
    if (m.picture != nullptr) {
        const SDL_Rect dst = {kMissionMap.x, kMissionMap.y, m.picture_w, m.picture_h};
        SDL_RenderCopy(r, m.picture, nullptr, &dst);
    }
    if (m.text_shown) {
        const SDL_Rect text = {kMissionText.x, kMissionText.y, kMissionText.w - kScrollW,
                               kMissionText.h};
        const int lines = DrawPanelText(r, Text::GameFont(11), text, m.texts[m.tab], Align::Left,
                                        Down::Top, true, kMissionInk, m.scroll);
        if (lines > MissionRows()) {
            const int most = std::max(1, MissionLines(m) - MissionRows());
            const int x = kMissionText.x + kMissionText.w - 7;
            const int track = kMissionText.h - 4;
            const int thumb = std::max(18, track * MissionRows() / std::max(1, MissionLines(m)));
            const int y = kMissionText.y + 2 + (track - thumb) * m.scroll / most;
            SDL_SetRenderDrawColor(r, theme.bevel[3].r, theme.bevel[3].g, theme.bevel[3].b, 255);
            const SDL_Rect rail{x, kMissionText.y + 2, 5, track};
            SDL_RenderFillRect(r, &rail);
            SDL_SetRenderDrawColor(r, theme.focus.r, theme.focus.g, theme.focus.b, 255);
            const SDL_Rect grip{x + 1, y, 3, thumb};
            SDL_RenderFillRect(r, &grip);
        }
    }
    if (m.tabs_shown) {
        for (int t = 0; t < kTabs; ++t) DrawChoice(r, theme, m.buttons[t], t == m.tab, p);
    }
    if (!g_mission_slide.empty()) {
        DrawFocused(r, theme, m.replay, p);
        if (!g_intro_error.empty())
            DrawPanelText(r, Text::GameFont(0), SDL_Rect{25, 520, 400, 30},
                          "过场加载失败: " + g_intro_error, Align::Left, Down::Top, false, kMissionInk);
    }
    DrawFocused(r, theme, m.ok, p);
}

void MissionEvent(const SDL_Event& e, const Pointer& p, Request& request) {
    Mission& m = TheMission();
    (void)p;
    const int most = std::max(0, MissionLines(m) - MissionRows());
    if (e.type == SDL_MOUSEBUTTONUP && e.button.button == SDL_BUTTON_LEFT) {
        const int x = e.button.x, y = e.button.y;
        if (Hit(m.ok.rect, x, y)) {
            Click();
            request.kind = Request::Kind::Begin;
            return;
        }
            if (Hit(m.replay.rect, x, y) && !g_mission_slide.empty()) {
            g_intro_error.clear();
            Click();
            request.kind = Request::Kind::PlayIntro;
            request.path = g_mission_slide;
            request.entry = g_mission_campaign;
            return;
        }
        for (int t = 0; t < kTabs && m.tabs_shown; ++t) {
            if (m.buttons[t].visible && Hit(m.buttons[t].rect, x, y)) {
                Click();
                m.tab = t;
                m.scroll = 0;
                return;
            }
        }
        const SDL_Rect track = {kMissionText.x + kMissionText.w - kScrollW, kMissionText.y,
                                kScrollW, kMissionText.h};
        if (Hit(track, x, y)) {
            m.scroll = std::clamp((y - track.y) * most / std::max(1, track.h - 1), 0, most);
            m.next_scroll = SDL_GetTicks() + 3000;
        }
    } else if (e.type == SDL_MOUSEMOTION && (e.motion.state & SDL_BUTTON_LMASK)) {
        const SDL_Rect track{kMissionText.x + kMissionText.w - kScrollW, kMissionText.y,
                             kScrollW, kMissionText.h};
        if (Hit(track, e.motion.x, e.motion.y))
            m.scroll = std::clamp((e.motion.y - track.y) * most / std::max(1, track.h - 1), 0, most);
    } else if (e.type == SDL_MOUSEWHEEL) {
        m.scroll = std::clamp(m.scroll - e.wheel.y, 0, most);
    } else if (e.type == SDL_KEYDOWN &&
               (e.key.keysym.sym == SDLK_RETURN || e.key.keysym.sym == SDLK_ESCAPE)) {
        request.kind = Request::Kind::Begin;
    }
}

// ---------------------------------------------------------------------------
// A scenario's end, the "Aftermath Screen": after a scenario that is not a
// campaign's, its victory text when the player won, its loss text when not
// (no screen when that text is empty), then the achievements. On the plain
// parchment (scr2, 50052), laid out at 800x600: "Aftermath" (50001, font 1)
// centred in 794x40 at (3, 12), black; the text in a 626x426 box at
// (87, 87), font 11, in the .sin's colours with its two-line sunken border
// and a scroll bar; "Achievements" (50002) 190x37 at (305, 550), which has
// the focus. Its music is the end's own (won1, won2 or lost), already
// playing from the game's end.

constexpr SDL_Rect kAftermathTitle = {3, 12, 794, 40};
constexpr SDL_Rect kAftermathText = {87, 87, 626, 426};
constexpr SDL_Rect kAftermathButton = {305, 550, 190, 37};

struct Aftermath {
    Theme theme;
    std::string text;
    int scroll = 0;
    Button go_on;
};

Aftermath& TheAftermath() {
    static Aftermath aftermath;
    return aftermath;
}

int AftermathLines(const Aftermath& a) {
    return static_cast<int>(PanelLines(Text::GameFont(11), a.text,
                                       PanelWrapWidth(kAftermathText.w - kScrollW, 2), true)
                                .size());
}
int AftermathRows() { return (kAftermathText.h - 4) / PanelPitch(Text::GameFont(11)); }

void DrawAftermath(SDL_Renderer* r, const Pointer& p) {
    Aftermath& a = TheAftermath();
    const Theme& theme = a.theme;
    DrawBackground(r, theme);
    DrawPanelText(r, Text::GameFont(1), kAftermathTitle, Get(50001), Align::Centre, Down::Centre,
                  false, kBlackInk);
    DrawShaded(r, theme, kAftermathText);
    DrawSunken2(r, theme, kAftermathText);
    const SDL_Rect text = {kAftermathText.x, kAftermathText.y, kAftermathText.w - kScrollW,
                           kAftermathText.h};
    const int lines = DrawPanelText(r, Text::GameFont(11), text, a.text, Align::Left, Down::Top,
                                    true, SinInk(theme), a.scroll, 2);
    if (lines > AftermathRows()) {
        DrawButtonArt(r, theme, 8, kAftermathText.x + kAftermathText.w - kScrollW - 2,
                      kAftermathText.y + 2);
        DrawButtonArt(r, theme, 10, kAftermathText.x + kAftermathText.w - kScrollW - 2,
                      kAftermathText.y + kAftermathText.h - kScrollW - 2);
    }
    DrawFocused(r, theme, a.go_on, p);
}

void AftermathEvent(const SDL_Event& e, const Pointer& p, Request& request) {
    Aftermath& a = TheAftermath();
    (void)p;
    const int most = std::max(0, AftermathLines(a) - AftermathRows());
    if (e.type == SDL_MOUSEBUTTONUP && e.button.button == SDL_BUTTON_LEFT) {
        const int x = e.button.x, y = e.button.y;
        if (Hit(a.go_on.rect, x, y)) {
            Click();
            request.kind = Request::Kind::Begin;
            return;
        }
        const int bar = kAftermathText.x + kAftermathText.w - kScrollW - 2;
        if (Hit(SDL_Rect{bar, kAftermathText.y + 2, kScrollW, kScrollW}, x, y)) {
            a.scroll = std::max(0, a.scroll - 1);
        } else if (Hit(SDL_Rect{bar, kAftermathText.y + kAftermathText.h - kScrollW - 2, kScrollW,
                                kScrollW}, x, y)) {
            a.scroll = std::min(most, a.scroll + 1);
        }
    } else if (e.type == SDL_MOUSEWHEEL) {
        a.scroll = std::clamp(a.scroll - e.wheel.y, 0, most);
    } else if (e.type == SDL_KEYDOWN &&
               (e.key.keysym.sym == SDLK_RETURN || e.key.keysym.sym == SDLK_ESCAPE)) {
        request.kind = Request::Kind::Begin;
    }
}

} // namespace

void Init() {
    TheBook().theme = MakeTheme(Sin::kCampaigns, kMenuWidth, kMenuHeight);
    TheBook().slots = ReadLayout(kBookLayout);
    TheSelect().theme = MakeTheme(Sin::kParchment2, kMenuWidth, kMenuHeight);
    TheMission().theme = MakeTheme(Sin::kLoading, kMenuWidth, kMenuHeight);
    TheAftermath().theme = MakeTheme(Sin::kParchment2, kMenuWidth, kMenuHeight);
    TheEditor().theme = MakeTheme(Sin::kParchment4, kMenuWidth, kMenuHeight);
    TheEditor().dialog = MakeTheme(Sin::kParchmentDialog, kMenuWidth, kMenuHeight, true);
}

void PrepareBook() {
    Book& b = TheBook();
    for (int n = 1; n <= kSlots; ++n) {
        std::error_code ec;
        b.present[n] = std::filesystem::exists(CampaignPath(n), ec);
    }
    b.pressed = 0;
    b.back = Button{kBackButton, Get(11241), Text::GameFont(0)};
}

void PrepareMap(int number, bool from_main_menu) {
    Slides::ArmIntro();
    Map& m = TheMap();
    m.number = number;
    m.from_main_menu = from_main_menu;
    m.theme = MakeTheme(kMapSinBase + static_cast<uint32_t>(number), kMenuWidth, kMenuHeight);
    m.slots = ReadLayout(kBookLayout + static_cast<uint32_t>(number));
    m.loaded = Scenario::LoadCampaign(CampaignPath(number), m.campaign);
    const int count = m.loaded ? static_cast<int>(m.campaign.scenarios.size()) : 0;
    const Scenario::Progress::Book book = Scenario::Progress::Load();
    m.shown = number == kLearning
        ? std::min(count, kLearningScenarios)
        : std::min(count, Scenario::Progress::Unlocked(book, Player(), m.campaign.name));
    m.won.assign(static_cast<size_t>(count), false);
    for (int i = 0; i < count; ++i) {
        m.won[static_cast<size_t>(i)] = Scenario::Progress::Won(book, Player(), m.campaign.name, i);
    }
    m.pressed = -1;
    m.difficulty = DifficultyList(kDifficultyList);
    m.back = Button{kBackButton, Get(number == kLearning && from_main_menu ? 11252 : 11251),
                    Text::GameFont(0)};
}

void PrepareSelect() {
    Select& s = TheSelect();
    s.paths = FilesIn("../assets/original/Scenario", {".scn", ".scx"});
    // And those the scenario editor saved, beside the saved games.
    for (const std::string& p : FilesIn(ScenariosDir(), {".scn", ".scx"})) s.paths.push_back(p);
    const auto goodies = FilesIn("../original_game_1999/GOODIES", {".scn", ".scx"});
    s.paths.insert(s.paths.end(), goodies.begin(), goodies.end());
    s.list = ListBox{kSelectList, {}, s.paths.empty() ? -1 : 0, 0, Text::GameFont(11)};
    for (const auto& path : s.paths) {
        s.list.items.push_back(std::filesystem::path(path).stem().string());
    }
    s.difficulty = DifficultyList(kSelectDifficulty);
    s.ok = Button{kSelectOk, Get(4001), Text::GameFont(0)};
    s.cancel = Button{kSelectCancel, Get(4002), Text::GameFont(0)};
}

std::vector<std::string> CustomCampaigns() {
    std::vector<std::string> out;
    std::vector<std::string> found = FilesIn(kCampaignDir, {".cpn", ".cpx"});
    const auto own = FilesIn(CampaignsDir(), {".cpn", ".cpx"});
    found.insert(found.end(), own.begin(), own.end());
    for (const std::string& path : found) {
        Scenario::Campaign campaign;
        if (!Scenario::LoadCampaign(path, campaign)) continue;
        // The book has the Age of Kings' campaigns; The Conquerors' four are
        // offered here until the book's own screen has their art.
        const int number = Scenario::CampaignNumber(campaign);
        const bool conquerors = campaign.name.compare(0, 4, "xcam") == 0;
        if (number != 0 && !(conquerors && number >= 5 && number <= 8)) continue;
        out.push_back(path);
    }
    return out;
}


void PrepareConquerors() {
    PrepareCustom();
    g_conquerors_page = true;
    Custom& c = TheCustom();
    c.module = 1;
    RefreshCustom();
}

void PrepareCustom() {
    g_conquerors_page = false;
    Custom& c = TheCustom();
    c.all_paths = CustomCampaigns();
    for (const std::string& path : FilesIn(kCampaignDir, {".cpn", ".cpx"})) {
        if (std::find(c.all_paths.begin(), c.all_paths.end(), path) == c.all_paths.end()) {
            c.all_paths.push_back(path);
        }
    }
    static const char* kModuleNames[5] = {"国王时代", "征服者", "失落帝国", "非洲王国", "蛮王崛起"};
    for (int i = 0; i < 5; ++i) {
        c.modules[i] = Button{SDL_Rect{kCustomModules.x + i * (kCustomModules.w / 5), kCustomModules.y,
                                       kCustomModules.w / 5 - 2, kCustomModules.h},
                              kModuleNames[i], Text::GameFont(11)};
    }
    RefreshCustom();
    // Back from a scenario, the campaign it was in stays chosen.
    for (size_t i = 0; i < c.paths.size(); ++i) {
        if (c.paths[i] == c.chosen.path) c.campaigns.selected = static_cast<int>(i);
    }
    if (!c.paths.empty()) ListScenarios(c);
    c.difficulty = DifficultyList(kSelectDifficulty);
    c.ok = Button{kSelectOk, Get(4001), Text::GameFont(0)};
    c.cancel = Button{kSelectCancel, Get(4002), Text::GameFont(0)};
}

void PrepareCampaignEditor() {
    CampaignEditor& c = TheEditor();
    ListCampaigns(c);
    c.name = TextField{kEditorName, Get(11210), kCampaignNameLength, true, Text::GameFont(11)};
    c.scenario_paths = FilesIn("../assets/original/Scenario", {".scn", ".scx"});
    for (const std::string& p : FilesIn(ScenariosDir(), {".scn", ".scx"})) c.scenario_paths.push_back(p);
    for (const std::string& p : FilesIn("../original_game_1999/GOODIES", {".scn", ".scx"})) c.scenario_paths.push_back(p);
    c.scenarios = ListBox{kEditorScenarios, {}, c.scenario_paths.empty() ? -1 : 0, 0, Text::GameFont(11)};
    for (const auto& path : c.scenario_paths) c.scenarios.items.push_back(std::filesystem::path(path).stem().string());
    c.entries.clear();
    c.chosen = ListBox{kEditorChosen, {}, -1, 0, Text::GameFont(11)};
    c.save = Button{kEditorSave, Get(11204), Text::GameFont(0)};
    c.add = Button{kEditorAdd, Get(11205), Text::GameFont(0)};
    c.remove = Button{kEditorRemove, Get(11206), Text::GameFont(0)};
    c.up = Button{kEditorUp, Get(11221), Text::GameFont(0)};
    c.down = Button{kEditorDown, Get(11222), Text::GameFont(0)};
    c.ok = Button{kEditorOk, Get(4001), Text::GameFont(0)};
    c.cancel = Button{kEditorCancel, Get(4002), Text::GameFont(0)};
    c.dirty = false;
    c.asking = false;
    c.notice.open = false;
}

void PrepareMission(const Scenario::File& file) {
    Mission& m = TheMission();
    if (m.picture != nullptr) SDL_DestroyTexture(m.picture);
    m.picture = nullptr;
    g_mission_file = &file;
    // The scenario's name: the file name it was saved under (as
    // "Joan_scn1.scn"), its last four characters cut off.
    std::string name = file.original_name;
    if (name.size() >= 4) name.resize(name.size() - 4);
    m.title = g_mission_title.empty() ? name : g_mission_title;
    m.scroll = 0;
    m.next_scroll = SDL_GetTicks() + 1200;
    g_mission_title.clear();
    if (!g_mission_audio.empty()) {
        std::ofstream log("/sdcard/Download/OpenAokHD-log.txt", std::ios::app);
        if (log) log << "MISSION AUDIO: " << g_mission_audio << "\n";
        const bool ok = HAL::Audio::PlayNarration(g_mission_audio);
        if (log) log << "MISSION AUDIO PLAY: " << (ok ? "ok" : "fail") << "\n";
    }
    for (int t = 0; t < kTabs; ++t) m.texts[t] = Scenario::Show(file.texts[kTabText[t]]);
    // The text shown first: the instructions, else the history, else the
    // hints.
    int present = 0;
    m.tab = -1;
    for (int t : {kInstructions, kHistory, kHints}) {
        if (m.texts[t].empty()) continue;
        if (m.tab < 0) m.tab = t;
        ++present;
    }
    m.text_shown = present > 0;
    m.tabs_shown = present > 1;
    if (m.tab < 0) m.tab = kInstructions;
    m.scroll = 0;
    for (int t = 0; t < kTabs; ++t) {
        m.buttons[t] = Button{SDL_Rect{5 + 200 * t, 560, 190, 37}, Get(kTabLabel[t]),
                              Text::GameFont(0)};
        m.buttons[t].visible = !m.texts[t].empty();
    }
    m.ok = Button{SDL_Rect{605, 560, 190, 37}, Get(4001), Text::GameFont(0)};
    m.replay = Button{SDL_Rect{25, 560, 190, 37}, "播放过场", Text::GameFont(0)};
}

bool PrepareAftermath(const Scenario::File& file, bool won) {
    Aftermath& a = TheAftermath();
    a.text = Scenario::Show(file.texts[won ? Scenario::kVictory : Scenario::kLoss]);
    a.scroll = 0;
    a.go_on = Button{kAftermathButton, Get(50002), Text::GameFont(0)};
    return !a.text.empty();
}

void Return() {
    switch (g_origin.screen) {
    case Id::CampaignMap: OpenCampaignMap(g_origin.campaign, g_origin.from_main_menu); break;
    case Id::ScenarioSelect: Open(Id::ScenarioSelect); break;
    case Id::DlcCampaign: OpenDlcMap(); break;
    default: Open(Id::MainMenu); break;
    }
}


// A HD expansion campaign's map: the expansion's own background and the
// campaign's scenario markers. The scenarios themselves are HD format 3 and
// cannot be started yet; the markers say so.
struct DlcPage {
    Theme theme;
    nlohmann::json data;
    int module = 3;
    int chosen = 0;
    std::vector<SDL_Rect> nodes;
    std::vector<std::string> labels;
    std::vector<std::string> intros;
    std::vector<std::string> group_images;
    std::vector<bool> won;
    std::vector<bool> playable;
    std::string campaign_key;
    Scenario::Bitmap preview;
    std::string converted;
    bool group = true;
    bool fallback_bg = false;
    int map_bg = 0, map_palette = 0;
    int group_bg = 0, group_palette = 0;
    std::string group_title;
    std::string group_png;
    std::string group_banner;
    std::string card_png;
    std::string map_png;
    std::string intro_png;
    std::vector<nlohmann::json> slides;
    int slide = 0;
    int group_icon[8] = {}, group_icon_palette[8] = {}, group_x[8] = {}, group_y[8] = {};
    int icon = 0, icon_palette = 0, intro_bg = 0, intro_palette = 0;
    std::vector<int> images, image_palettes;
    int selected = -1;
    std::vector<std::string> pages;
    int page = 0;
    Button prev, next, skip;
    Button campaigns[8];
    Button start;
    int campaign_count = 0;
    Button back;
    bool notice = false;
    bool story = false;
    Button story_button;
    Button story_back;
    Button intro_back;
};

int DlcModuleIndex(int module) {
    if (module == 2) return 2;
    return module - 3;
}

DlcPage& TheDlc() {
    static DlcPage page;
    return page;
}

void MakeIntroPages(const std::string& text, std::vector<std::string>& pages) {
    pages.clear();
    std::string page;
    size_t start = 0;
    while (start < text.size()) {
        size_t end = text.find("\n\n", start);
        std::string para = text.substr(start, end == std::string::npos ? std::string::npos : end - start);
        if (!page.empty() && page.size() + para.size() > 300) { pages.push_back(page); page.clear(); }
        if (!page.empty()) page += "\n\n";
        page += para;
        if (end == std::string::npos) break;
        start = end + 2;
    }
    if (!page.empty()) pages.push_back(page);
}

void LoadDlcCampaign() {
    DlcPage& d = TheDlc();
    d.nodes.clear(); d.labels.clear(); d.intros.clear(); d.group_images.clear();
    d.won.clear(); d.playable.clear(); d.campaign_key.clear(); d.preview = {};
    d.images.clear(); d.image_palettes.clear(); d.selected = -1; d.campaign_count = 0;
    d.pages.clear(); d.page = 0;
    if (!d.data.contains("modules") || d.data["modules"].size() < 2) return;
    const int mi = DlcModuleIndex(d.module);
    if (mi < 0 || mi > 2) return;
    const auto& mod = d.data["modules"][mi];
    if (!mod.contains("campaigns") || mod["campaigns"].empty()) return;
    d.campaign_count = std::min(8, static_cast<int>(mod["campaigns"].size()));
    d.chosen = std::clamp(d.chosen, 0, d.campaign_count - 1);
    const auto& camp = mod["campaigns"][d.chosen];
    d.converted = camp.value("converted", "");
    d.map_png = camp.value("png", "");
    d.intro_png = camp.value("intro_png", "");
    d.slides.clear(); d.slide = 0;
    if (camp.contains("slides")) for (const auto& sl : camp["slides"]) d.slides.push_back(sl);
    d.icon = camp.value("icon", 0); d.icon_palette = camp.value("icon_palette", 0);
    d.intro_bg = camp.value("intro_bg", 0); d.intro_palette = camp.value("intro_palette", 0);
    d.fallback_bg = !camp.contains("slp") || camp.value("slp", 0) == 0;
    d.map_bg = camp.value("slp", 0); d.map_palette = camp.value("palette", 0);
    d.start = Button{SDL_Rect{540, 495, 200, 30}, "开始战役", Text::kArial9};
    if (DlcModuleIndex(d.module) == 2) {
        d.back = Button{SDL_Rect{290, 548, 220, 34}, "返回", Text::kArial9};
        d.story_button = Button{SDL_Rect{530, 548, 150, 34}, "战役背景", Text::kArial9};
        d.story_back = Button{SDL_Rect{290, 530, 220, 34}, "返回", Text::kArial9};
    }
    const int sin = camp.value("sin", 50640);
    d.theme = MakeTheme(static_cast<uint32_t>(sin), kMenuWidth, kMenuHeight);
    for (int i = 0; i < d.campaign_count; ++i) {
        const auto& c = mod["campaigns"][i];
        const int bx = 20 + (i % 4) * 190;
        const int by = 42 + (i / 4) * 28;
        d.campaigns[i] = Button{SDL_Rect{bx, by, 180, 24}, c.value("name", ""), Text::kArial9};
    }
    const double sx = 800.0 / std::max(1, camp.value("width", 1366));
    const double sy = 600.0 / std::max(1, camp.value("height", 768));
    if (camp.contains("scenarios")) {
        for (const auto& s : camp["scenarios"]) {
            const int x = static_cast<int>(s.value("x", 0) * sx);
            const int y = static_cast<int>(s.value("y", 0) * sy);
            const bool painted = DlcModuleIndex(d.module) == 2 && !d.map_png.empty();
            d.nodes.push_back(painted ? SDL_Rect{x - 65, y - 80, 160, 170}
                                      : SDL_Rect{x - 35, y - 55, 90, 90});
            d.labels.push_back(s.value("label", ""));
            d.intros.push_back(s.value("intro", ""));
            d.images.push_back(s.value("image", 0));
            d.image_palettes.push_back(s.value("image_palette", 0));
        }
    }
    // Real scenario text beats the JSON placeholder: read the campaign's
    // instructions, history or hints for every mission. The same campaign
    // record tells which missions are unlocked and already won.
    Scenario::Campaign from_file;
    if (!d.converted.empty() && Scenario::LoadCampaign(d.converted, from_file)) {
        d.campaign_key = from_file.name;
        const Scenario::Progress::Book book = Scenario::Progress::Load();
        const int unlocked = Scenario::Progress::Unlocked(book, Player(), d.campaign_key);
        for (int i = 0; i < static_cast<int>(d.intros.size()); ++i) {
            d.won.push_back(Scenario::Progress::Won(book, Player(), d.campaign_key, i));
            d.playable.push_back(i < unlocked);
        }
        for (int i = 0; i < static_cast<int>(d.intros.size()) && i < static_cast<int>(from_file.scenarios.size()); ++i) {
            Scenario::File file;
            if (!Scenario::Load(d.converted, i, file)) continue;
            std::string text = Scenario::Show(file.texts[Scenario::kInstructions]);
            if (text.empty()) text = Scenario::Show(file.texts[Scenario::kHistory]);
            if (text.empty()) text = Scenario::Show(file.texts[Scenario::kHints]);
            if (!text.empty()) d.intros[i] = text;
        }
    }
}

void LoadDlcGroup() {
    DlcPage& d = TheDlc();
    d.group = true;
    const int mi = DlcModuleIndex(d.module);
    if (mi < 0 || mi > 2 || !d.data.contains("modules") || d.data["modules"].size() < 3) return;
    const auto& mod = d.data["modules"][mi];
    d.group_bg = mod.value("group_bg", 0); d.group_palette = mod.value("group_palette", 0);
    d.group_title = mod.value("group_title", "HD 战役");
    if (DlcModuleIndex(d.module) == 2) {
        d.back = Button{SDL_Rect{20, 548, 220, 34}, "返回", Text::kArial9};
    }
    d.group_png = mod.value("group_png", "");
    d.group_banner = mod.value("group_banner", "");
    d.card_png = mod.value("card_png", "");
    if (DlcModuleIndex(d.module) == 2) {
        d.back = Button{SDL_Rect{20, 548, 220, 34}, "返回", Text::kArial9};
    }
    const auto& camps = mod["campaigns"];
    d.campaign_count = std::min(8, static_cast<int>(camps.size()));
    for (int i = 0; i < d.campaign_count; ++i) {
        const auto& c = camps[i];
        d.group_icon[i] = c.value("group_icon", 0); d.group_icon_palette[i] = c.value("group_icon_palette", 0);
        d.group_images.push_back(c.value("png", ""));
        d.group_x[i] = c.value("group_x", 100 + i * 300); d.group_y[i] = c.value("group_y", 200);
    }
}

void PrepareDlc() {
    DlcPage& d = TheDlc();
    d.module = g_dlc_module;
    d.chosen = 0;
    d.group = true;
    d.theme = TheSelect().theme;
    d.back = Button{SDL_Rect{25, 550, 200, 30}, "返回", Text::kArial9};
    std::ifstream in("../assets/extracted_data/dlc_campaigns.json");
    if (in) in >> d.data;
    LoadDlcGroup();
}

void DrawPreview(SDL_Renderer* r, const Scenario::Bitmap& bmp, const SDL_Rect& rect) {
    if (bmp.width <= 0 || bmp.height <= 0 || bmp.pixels.empty() || bmp.palette.empty()) return;
    static SDL_Texture* tex = nullptr;
    static const void* cached = nullptr;
    static int cached_w = 0, cached_h = 0;
    if (tex == nullptr || cached != bmp.pixels.data() || cached_w != bmp.width || cached_h != bmp.height) {
        if (tex != nullptr) SDL_DestroyTexture(tex);
        tex = SDL_CreateTexture(r, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_STATIC,
                                bmp.width, bmp.height);
        if (tex == nullptr) return;
        std::vector<uint8_t> rgba(static_cast<size_t>(bmp.width) * bmp.height * 4);
        for (size_t i = 0; i < bmp.pixels.size() && i < rgba.size() / 4; ++i) {
            const uint32_t p = bmp.palette[bmp.pixels[i] % bmp.palette.size()];
            rgba[i * 4 + 0] = static_cast<uint8_t>((p >> 16) & 0xFF);
            rgba[i * 4 + 1] = static_cast<uint8_t>((p >> 8) & 0xFF);
            rgba[i * 4 + 2] = static_cast<uint8_t>(p & 0xFF);
            rgba[i * 4 + 3] = 255;
        }
        SDL_UpdateTexture(tex, nullptr, rgba.data(), bmp.width * 4);
        cached = bmp.pixels.data(); cached_w = bmp.width; cached_h = bmp.height;
    }
    SDL_RenderCopy(r, tex, nullptr, &rect);
}

void ShowDlcMap() {
    TheDlc().group = false;
    LoadDlcCampaign();
}

void DrawDlc(SDL_Renderer* r, const Pointer& p) {
    DlcPage& d = TheDlc();
    if (d.group) {
        DrawBackground(r, d.theme);
        if (!DrawPng(r, d.group_png, SDL_Rect{0, 0, 800, 600}))
            DrawAtlasImage(r, d.group_bg, d.group_palette, SDL_Rect{0, 0, 800, 600});
        if (DlcModuleIndex(d.module) != 2 && d.group_png.empty()) {
            DrawPanelText(r, Text::kArial9, SDL_Rect{25, 8, 750, 30}, d.group_title, Align::Centre, Down::Top, false, kHdWhite);
        }
        if (d.campaign_count == 0) {
            DrawPanelText(r, Text::kArial9, SDL_Rect{100, 300, 600, 40},
                          "未找到 HD 战役数据，请重新导入 OpenAoK-data", Align::Centre, Down::Top, false, kBlackInk);
        }
        if (!d.group_banner.empty()) {
            DrawPng(r, d.group_banner, SDL_Rect{278, 4, 244, 94});
        } else {
            DrawPanelText(r, Text::kBlackletter14, SDL_Rect{0, 8, 800, 32}, d.group_title,
                          Align::Centre, Down::Top, false, kHdWhite);
        }
        if (DlcModuleIndex(d.module) == 2) {
            DrawPanelText(r, Text::kBlackletter14, SDL_Rect{0, 8, 800, 30}, d.group_title,
                          Align::Centre, Down::Top, true, kHdWhite);
            DrawFocused(r, d.theme, d.back, p);
            DrawCloseBox(r, d.theme, p.held && Hit(kCloseBox, p.x, p.y));
            return;
        }
        for (int i = 0; i < d.campaign_count; ++i) {
            const int x = d.group_x[i] * 800 / 1366, y = d.group_y[i] * 600 / 768;
            if (d.group_icon[i] != 0) {
                DrawAtlasImage(r, d.group_icon[i], d.group_icon_palette[i], SDL_Rect{x, y, 64, 64});
            } else if (i < static_cast<int>(d.group_images.size())) {
                DrawPng(r, d.group_images[i], SDL_Rect{x - 28, y, 120, 64});
            }
            const auto& c = d.data["modules"][DlcModuleIndex(d.module)]["campaigns"][i];
            DrawPanelText(r, Text::kArial9, SDL_Rect{x - 50, y + 48, 160, 20}, c.value("name", ""),
                          Align::Centre, Down::Top, true, kHdWhite);
            const std::string desc = c.value("desc", "");
            if (!desc.empty()) {
                DrawPanelText(r, Text::kArial9, SDL_Rect{x - 54, y + 68, 168, 38}, desc,
                              Align::Centre, Down::Top, false, kHdWhite);
            }
        }
        DrawFocused(r, d.theme, d.back, p);
        DrawCloseBox(r, d.theme, p.held && Hit(kCloseBox, p.x, p.y));
        return;
    }
    if (!DrawPng(r, d.map_png, SDL_Rect{0, 0, 800, 600}) && d.fallback_bg) {
        DrawAtlasImage(r, d.group_bg, d.group_palette, SDL_Rect{0, 0, 800, 600});
    } else if (d.map_bg != 0) {
        DrawAtlasImage(r, d.map_bg, d.map_palette, SDL_Rect{0, 0, 800, 600});
    } else {
        DrawBackground(r, d.theme);
    }
    const bool painted = DlcModuleIndex(d.module) == 2 && !d.map_png.empty();
    if (painted) {
        const auto& camp = d.data["modules"][2]["campaigns"][d.chosen];
        DrawPanelText(r, Text::GameFont(4), SDL_Rect{0, 6, 800, 30}, camp.value("name", ""),
                      Align::Centre, Down::Top, true, kHdWhite);
        Text::Draw(r, Text::kArial9, 190, 548, Get(11215), SDL_Color{255,255,255,210});
        Text::Draw(r, Text::kArial9, 232, 548, Get(11216 + std::clamp(g_difficulty, 0, 4)),
                   SDL_Color{255,255,255,210});
        if (d.story) {
            DrawPng(r, "../assets/extracted_data/campaign_menu/background.png", SDL_Rect{0, 0, 800, 600});
            const SDL_Rect panel{70, 60, 660, 440};
            DrawShaded(r, d.theme, panel);
            DrawSunken2(r, d.theme, panel);
            DrawWrapped(r, Text::GameFont(4), panel.x + 24, panel.y + 20, panel.w - 48,
                        camp.value("name", ""), SDL_Color{255,255,255,255}, SDL_Color{0,0,0,255}, true);
            const std::string story = camp.value("background", "") + "\n\n" + camp.value("desc", "");
            DrawWrapped(r, Text::GameFont(0), panel.x + 24, panel.y + 60, panel.w - 48,
                        story, SDL_Color{255,255,255,255}, SDL_Color{0,0,0,255}, true);
            DrawFocused(r, d.theme, d.story_back, p);
            DrawCloseBox(r, d.theme, p.held && Hit(kCloseBox, p.x, p.y));
            return;
        }
        DrawFocused(r, d.theme, d.story_button, p);
    }
    if (!painted) {
        DrawPanelText(r, Text::kArial9, SDL_Rect{25, 8, 750, 30}, "HD 战役地图", Align::Centre, Down::Top, false, kHdWhite);
        for (int i = 0; i < d.campaign_count; ++i) {
            DrawButton(r, d.theme, d.campaigns[i], StateOf(d.campaigns[i], p.x, p.y, p.held));
        }
    }
    for (size_t i = 0; i < d.nodes.size(); ++i) {
        const SDL_Rect& node = d.nodes[i];
        if (painted) {
            const bool won = i < d.won.size() && d.won[i];
            const bool open = i < d.playable.size() && d.playable[i];
            const SDL_Rect badge{node.x + 55, node.y + 24, 8, 8};
            SDL_SetRenderDrawColor(r, won ? 80 : (open ? 230 : 40),
                                   won ? 190 : (open ? 180 : 40),
                                   won ? 90 : (open ? 70 : 40), 235);
            SDL_RenderFillRect(r, &badge);
            SDL_SetRenderDrawColor(r, 20, 16, 10, 255);
            SDL_RenderDrawRect(r, &badge);
            continue;
        }
        const SDL_Rect marker{node.x + 15, node.y, 60, 60};
        if (d.icon != 0) {
            DrawAtlasImage(r, d.icon, d.icon_palette, marker);
        } else {
            DrawShaded(r, d.theme, marker);
            DrawSunken2(r, d.theme, marker);
            char number[8];
            std::snprintf(number, sizeof(number), "%d", static_cast<int>(i) + 1);
            DrawPanelText(r, Text::kBlackletter14, marker, number, Align::Centre, Down::Centre,
                          false, kHdWhite);
        }
        DrawPanelText(r, Text::kArial9, SDL_Rect{node.x - 35, node.y + 55, 160, 44}, d.labels[i],
                      Align::Centre, Down::Top, true, kHdWhite);
    }
    if (d.campaign_count == 0) {
        DrawPanelText(r, Text::kArial9, SDL_Rect{100, 300, 600, 40},
                      "未找到 HD 战役数据，请重新导入 OpenAoK-data", Align::Centre, Down::Top, false,
                      kBlackInk);
    }
    if (d.selected >= 0 && !d.slides.empty() && d.slide < static_cast<int>(d.slides.size())) {
        HAL::Audio::PumpNarration();
        const auto& sl = d.slides[d.slide];
        if (!DrawPng(r, d.intro_png, SDL_Rect{0, 0, 800, 600})) DrawBackground(r, d.theme);
        const std::string img = sl.value("image", "");
        if (!img.empty()) DrawPng(r, "../assets/original/" + img, SDL_Rect{420, 185, 150, 140});
        const SDL_Rect panel{215, 170, 360, 180};
        DrawPanelText(r, Text::kArial9, SDL_Rect{panel.x + 14, panel.y + 8, panel.w - 28, 20}, "场景说明",
                      Align::Left, Down::Top, false, kBlackInk);
        DrawPanelText(r, Text::kArial9, SDL_Rect{panel.x + 14, panel.y + 32, panel.w - 180, panel.h - 60},
                      sl.value("text", ""), Align::Left, Down::Top, true, kBlackInk);
        d.prev = Button{SDL_Rect{panel.x + 14, panel.y + panel.h - 24, 70, 20}, "上一页", Text::kArial9};
        d.skip = Button{SDL_Rect{panel.x + panel.w - 84, panel.y + panel.h - 24, 70, 20}, "跳过", Text::kArial9};
        d.next = Button{SDL_Rect{panel.x + panel.w / 2 - 35, panel.y + panel.h - 24, 70, 20},
                        d.slide + 1 < static_cast<int>(d.slides.size()) ? "下一页" : "开始", Text::kArial9};
        if (d.slide > 0) DrawFocused(r, d.theme, d.prev, p);
        DrawFocused(r, d.theme, d.next, p); DrawFocused(r, d.theme, d.skip, p);
        DrawFocused(r, d.theme, d.back, p); DrawCloseBox(r, d.theme, p.held && Hit(kCloseBox, p.x, p.y));
        return;
    }
    if (d.selected >= 0 && d.selected < static_cast<int>(d.intros.size())) {
        SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
        const SDL_Rect shade{0, 0, 800, 600};
        SDL_SetRenderDrawColor(r, 0, 0, 0, 165);
        SDL_RenderFillRect(r, &shade);
        if (d.pages.empty()) MakeIntroPages(d.intros[d.selected], d.pages);
        if (d.intro_bg != 0) {
            DrawAtlasImage(r, d.intro_bg, d.intro_palette, SDL_Rect{0, 0, 800, 600});
        }
        d.intro_back = Button{SDL_Rect{30, 298, 170, 26}, "返回关卡选择", Text::kArial9};
        DrawFocused(r, d.theme, d.intro_back, p);
        const SDL_Rect panel{30, 330, 740, 205};
        SDL_SetRenderDrawColor(r, 24, 19, 12, 238);
        SDL_RenderFillRect(r, &panel);
        DrawSunken2(r, d.theme, panel);
        DrawPanelText(r, Text::GameFont(4), SDL_Rect{panel.x + 12, panel.y + 6, panel.w - 24, 20},
                      "场景说明", Align::Left, Down::Top, false, kHdWhite);
        const bool has_preview = d.preview.width > 0 && !d.preview.pixels.empty();
        if (has_preview) {
            DrawPreview(r, d.preview, SDL_Rect{panel.x + panel.w - 270, panel.y + 20, 250, 160});
        } else if (d.selected < static_cast<int>(d.images.size()) && d.images[d.selected] != 0) {
            DrawAtlasImage(r, d.images[d.selected], d.image_palettes[d.selected],
                           SDL_Rect{panel.x + panel.w - 270, panel.y + 20, 250, 160});
        }
        const int text_w = (has_preview ||
                            (d.selected < static_cast<int>(d.images.size()) && d.images[d.selected] != 0))
            ? panel.w - 300 : panel.w - 24;
        const std::string& page_text = d.page < static_cast<int>(d.pages.size()) ? d.pages[d.page] : d.intros[d.selected];
        DrawPanelText(r, Text::kArial9, SDL_Rect{panel.x + 12, panel.y + 28, text_w, panel.h - 52},
                      page_text, Align::Left, Down::Top, true, kHdWhite);
        d.prev = Button{SDL_Rect{panel.x + 12, panel.y + panel.h - 24, 70, 18}, "上一页", Text::kArial9};
        d.next = Button{SDL_Rect{panel.x + 90, panel.y + panel.h - 24, 70, 18}, "下一页", Text::kArial9};
        d.skip = Button{SDL_Rect{panel.x + panel.w - 76, panel.y + 4, 64, 18}, "跳过", Text::kArial9};
        if (d.page > 0) DrawFocused(r, d.theme, d.prev, p);
        if (d.page + 1 < static_cast<int>(d.pages.size())) DrawFocused(r, d.theme, d.next, p);
        if (!d.converted.empty()) DrawFocused(r, d.theme, d.skip, p);
        if (d.pages.size() > 1) {
            char num[32]; std::snprintf(num, sizeof(num), "%d / %d", d.page + 1, static_cast<int>(d.pages.size()));
            DrawPanelText(r, Text::kArial9, SDL_Rect{panel.x + panel.w - 80, panel.y + panel.h - 24, 68, 18},
                          num, Align::Right, Down::Top, false, kHdWhite);
        }
        if (!d.converted.empty()) {
            DrawFocused(r, d.theme, d.start, p);
        } else {
            DrawPanelText(r, Text::kArial9, SDL_Rect{panel.x + 12, panel.y + panel.h - 18, panel.w - 24, 16},
                          "HD 格式 3，暂不能开局", Align::Right, Down::Top, false, kHdWhite);
        }
    }
    DrawFocused(r, d.theme, d.back, p);
    DrawCloseBox(r, d.theme, p.held && Hit(kCloseBox, p.x, p.y));
}

void DlcEvent(const SDL_Event& e, Request& request) {
    DlcPage& d = TheDlc();
    if (d.group) {
        if (e.type == SDL_MOUSEBUTTONUP && e.button.button == SDL_BUTTON_LEFT) {
            for (int i = 0; i < d.campaign_count; ++i) {
                SDL_Rect hit;
                if (DlcModuleIndex(d.module) == 2) {
                    static const SDL_Rect hits[7] = {
                        {202, 372, 100, 100}, {401, 372, 100, 100}, {255, 91, 100, 100},
                        {565, 208, 100, 100}, {372, 231, 100, 100}, {196, 220, 100, 100},
                        {85, 161, 100, 100}};
                    hit = hits[std::min(i, 6)];
                } else {
                    const int x = d.group_x[i] * 800 / 1366, y = d.group_y[i] * 600 / 768;
                    hit = SDL_Rect{x, y, 90, 90};
                }
                if (Hit(hit, e.button.x, e.button.y)) {
                    Click(); d.group = false; d.chosen = i; LoadDlcCampaign(); return;
                }
            }
            if (Hit(d.back.rect, e.button.x, e.button.y)) { Click(); Open(Id::Campaigns); }
            else if (Hit(kCloseBox, e.button.x, e.button.y)) request.kind = Request::Kind::Quit;
        } else if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_ESCAPE) {
            Open(Id::Campaigns);
        }
        return;
    }
    if (e.type == SDL_MOUSEBUTTONUP && e.button.button == SDL_BUTTON_LEFT) {
        if (DlcModuleIndex(d.module) == 2 && d.story) {
            if (Hit(d.story_back.rect, e.button.x, e.button.y)) { Click(); d.story = false; return; }
            if (Hit(kCloseBox, e.button.x, e.button.y)) request.kind = Request::Kind::Quit;
            return;
        }
        if (DlcModuleIndex(d.module) == 2 && !d.map_png.empty() &&
            Hit(d.story_button.rect, e.button.x, e.button.y)) {
            Click(); d.story = true; return;
        }
        if (DlcModuleIndex(d.module) == 2 && !d.map_png.empty() &&
            Hit(SDL_Rect{190, 544, 95, 30}, e.button.x, e.button.y)) {
            Click(); g_difficulty = (g_difficulty + 1) % 5; return;
        }
        if (!(DlcModuleIndex(d.module) == 2 && !d.map_png.empty())) {
            for (int i = 0; i < d.campaign_count; ++i) {
                if (Hit(d.campaigns[i].rect, e.button.x, e.button.y)) {
                    Click(); d.chosen = i; d.selected = -1; LoadDlcCampaign(); return;
                }
            }
        }
        int choose = -1;
        int best = 0x7fffffff;
        for (size_t i = 0; i < d.nodes.size(); ++i) {
            if (!Hit(d.nodes[i], e.button.x, e.button.y)) continue;
            const int cx = d.nodes[i].x + d.nodes[i].w / 2;
            const int cy = d.nodes[i].y + d.nodes[i].h / 2;
            const int dist = (e.button.x - cx) * (e.button.x - cx) + (e.button.y - cy) * (e.button.y - cy);
            if (dist < best) { best = dist; choose = static_cast<int>(i); }
        }
        if (choose >= 0) {
            {
                Click();
                if (choose < static_cast<int>(d.playable.size()) && !d.playable[choose]) return;
                d.selected = choose;
                d.preview = {};
                Scenario::File preview_file;
                if (Scenario::Load(d.converted, choose, preview_file)) d.preview = preview_file.bitmap;
                d.page = 0; d.pages.clear(); d.slide = 0;
                if (!d.slides.empty()) {
                    const std::string snd = d.slides[0].value("sound", "");
                    if (!snd.empty()) HAL::Audio::PlayNarration("../assets/original/" + snd);
                }
                return;
            }
        }
        if (d.selected >= 0 && !d.slides.empty()) {
            if (Hit(d.skip.rect, e.button.x, e.button.y)) {
                Click();
                if (!d.converted.empty()) { request.kind = Request::Kind::StartScenario; request.path = d.converted; request.entry = 0; }
                return;
            }
            if (d.slide > 0 && Hit(d.prev.rect, e.button.x, e.button.y)) {
                Click(); --d.slide;
                const std::string snd = d.slides[d.slide].value("sound", "");
                if (!snd.empty()) HAL::Audio::PlayNarration("../assets/original/" + snd);
                return;
            }
            if (Hit(d.next.rect, e.button.x, e.button.y)) {
                Click();
                if (d.slide + 1 < static_cast<int>(d.slides.size())) {
                    ++d.slide;
                    const std::string snd = d.slides[d.slide].value("sound", "");
                    if (!snd.empty()) HAL::Audio::PlayNarration("../assets/original/" + snd);
                } else if (!d.converted.empty()) {
                    request.kind = Request::Kind::StartScenario; request.path = d.converted; request.entry = 0;
                }
                return;
            }
        }
        if (d.selected >= 0 && Hit(d.intro_back.rect, e.button.x, e.button.y)) {
            Click(); d.selected = -1; d.pages.clear(); d.preview = {}; return;
        }
        if (d.selected >= 0 && d.page > 0 && Hit(d.prev.rect, e.button.x, e.button.y)) { Click(); --d.page; return; }
        if (d.selected >= 0 && d.page + 1 < static_cast<int>(d.pages.size()) && Hit(d.next.rect, e.button.x, e.button.y)) { Click(); ++d.page; return; }
        if (d.selected >= 0 && !d.converted.empty() && Hit(d.skip.rect, e.button.x, e.button.y)) {
            Click();
            g_origin = Origin{Id::DlcCampaign, 0, false};
            request.kind = Request::Kind::StartScenario;
            request.path = d.converted; request.entry = d.selected;
            request.setup.difficulty = g_difficulty; return;
        }
        if (d.selected >= 0 && !d.converted.empty() && Hit(d.start.rect, e.button.x, e.button.y)) {
            Click();
            g_origin = Origin{Id::DlcCampaign, 0, false};
            request.kind = Request::Kind::StartScenario;
            request.path = d.converted;
            request.entry = d.selected;
            request.setup.difficulty = g_difficulty;
            return;
        }
        if (Hit(d.back.rect, e.button.x, e.button.y)) { Click(); LoadDlcGroup(); }
        else if (Hit(kCloseBox, e.button.x, e.button.y)) request.kind = Request::Kind::Quit;
    } else if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_ESCAPE) {
        Open(Id::Campaigns);
    }
}

void Draw(Id screen, SDL_Renderer* r, const Pointer& p) {
    switch (screen) {
    case Id::Campaigns: DrawBook(r, p); break;
    case Id::CampaignMap: DrawMap(r, p); break;
    case Id::ScenarioSelect: DrawSelect(r, p); break;
    case Id::CustomCampaigns: DrawCustom(r, p); break;
    case Id::CampaignEditor: DrawCampaignEditor(r, p); break;
    case Id::DlcCampaign: DrawDlc(r, p); break;
    case Id::Mission: DrawMission(r, p); break;
    case Id::Aftermath: DrawAftermath(r, p); break;
    default: break;
    }
}

void HandleEvent(Id screen, const SDL_Event& e, const Pointer& p, Request& request) {
    switch (screen) {
    case Id::Campaigns: BookEvent(e, p, request); break;
    case Id::CampaignMap: MapEvent(e, p, request); break;
    case Id::ScenarioSelect: SelectEvent(e, p, request); break;
    case Id::CustomCampaigns: CustomEvent(e, request); break;
    case Id::CampaignEditor: CampaignEditorEvent(e, request); break;
    case Id::DlcCampaign: DlcEvent(e, request); break;
    case Id::Mission: MissionEvent(e, p, request); break;
    case Id::Aftermath: AftermathEvent(e, p, request); break;
    default: break;
    }
}

void SetIntroError(const std::string& text) { g_intro_error = text; }

bool TakePendingSlide(std::string& name) {
    if (g_pending_slide.empty()) return false;
    name = g_pending_slide;
    g_pending_slide.clear();
    return true;
}

} // namespace Screens::Campaigns
