#include "hal/Touch.h"

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>

#include "hal/Pad.h"
#include "hal/Pointer.h"
#include "hal/Window.h"

#ifdef __ANDROID__
#include <android/log.h>
#include <jni.h>
#endif

namespace HAL::Touch {

namespace {

// How long a finger stays put to right-click, and how far it may wander
// meanwhile -- of the screen's height -- and still be a tap or a hold.
constexpr Uint32 kHoldMs = 300;
constexpr Uint32 kBoxHoldMs = 220;
constexpr Uint32 kMiniHoldMs = 450;
constexpr float kSlop = 10.0f;   // window pixels before a press becomes a drag
constexpr int kMaxFingers = 10;
#ifdef __IPHONEOS__
// How long a finger of a pan may go unreported before a new one coming down
// takes it for one the system let go of without a finger-up.
constexpr Uint32 kLostMs = 200;
#endif

enum class Mode : uint8_t {
    Idle,      // no finger down
    Pending,   // one finger, not yet a tap, a hold or a drag
    Dragging,  // one finger that moved: the left button is down
    Held,      // one finger that stayed: its right click is given
    Aiming,    // one finger moving the pointer, to click where it lifts
    OnePan,    // a quick one-finger drag: the map moves, nothing is selected
    Panning,   // two fingers or more: the map follows them
    MiniPending, // finger on the minimap, still a view jump
    MiniHeld,    // held on the minimap: orders, not a jump
};

struct Finger {
    SDL_FingerID id = 0;
    float x = 0.0f;   // window pixels
    float y = 0.0f;
    Uint32 last = 0;  // when it was last reported, SDL's ticks
};

struct State {
    bool enabled = false;
    bool aiming = false;
    Uint32 hold_event = 0;
    Mode mode = Mode::Idle;
    Finger fingers[kMaxFingers];
    int count = 0;
    SDL_FingerID primary = 0;
    float start_x = 0.0f;   // where the first finger went down
    float start_y = 0.0f;
    Uint32 serial = 0;      // which touch the hold timer is timing
    Uint32 started = 0;     // when the first finger went down
    Uint32 last_mini_order = 0;
    float pan_x = 0.0f;     // the fingers' middle, last seen
    float pan_y = 0.0f;
    float pan_dx = 0.0f;    // the drag waiting for TakePan, frame pixels
    float pan_dy = 0.0f;
    float spread = 0.0f;    // the fingers' distance from their middle, last seen
    float zoom = 1.0f;      // the pinch waiting for TakeZoom
    int win_w = 0;          // the window, last time it could be asked
    int win_h = 0;
    SDL_Rect mini{0, 0, 0, 0};
    int hud_top = 0, hud_panel = 0;
    bool ui_only = false;
    bool group_hold = false;
    SDL_Rect ui_button{0, 0, 0, 0};
    SDL_Rect ui_groups[5] = {};
    Uint8 world_button = SDL_BUTTON_RIGHT;
    bool tap_active = false;
    float tap_x = 0.0f, tap_y = 0.0f;
    bool tap_right = true;

    SDL_Haptic* haptic = nullptr;
    bool haptic_tried = false;
};
State g;

// Written by the system's thread (GameActivity), read by the game's.
std::atomic<bool> g_mouse{true};

float FrameScale();

// Frame pixels to the window's, where SDL's mouse lives. The game's event loop
// then translates the mouse event back into the frame.
void MovePointer(float x, float y) {
    Window* window = MainWindow();
    if (window == nullptr) {
        Pointer::Move(x, y, true);
        return;
    }
    const SDL_Rect at = window->ToWindow(
        SDL_Rect{static_cast<int>(x), static_cast<int>(y), 0, 0});
    Pointer::Move(static_cast<float>(at.x), static_cast<float>(at.y), true);
}

void Click(Uint8 button, float x, float y) {
    MovePointer(x, y);
    Pointer::Click(button);
}


// Android's native-mouse bridge is reliable for the primary button; a right
// button pushed as an SDL event reaches the world's order handler directly.
void PushClick(Uint8 button, float x, float y) {
    Uint32 window_id = 0;
    if (Window* window = MainWindow()) {
        if (SDL_Window* sdl = window->GetSDLWindow()) window_id = SDL_GetWindowID(sdl);
    }
    SDL_Event down{};
    down.type = SDL_MOUSEBUTTONDOWN;
    down.button.button = button;
    down.button.state = SDL_PRESSED;
    down.button.clicks = 1;
    down.button.which = 0;
    down.button.windowID = window_id;
    down.button.x = static_cast<Sint32>(x);
    down.button.y = static_cast<Sint32>(y);
    SDL_PushEvent(&down);
    SDL_Event up = down;
    up.type = SDL_MOUSEBUTTONUP;
    up.button.state = SDL_RELEASED;
    SDL_PushEvent(&up);
}

// The window's size in pixels, kept from the last time it could be asked: a
// finger's whole gesture has to be tracked through one of these, so an event
// is never dropped for want of it.
bool WindowSize(int& w, int& h) {
    Window* window = MainWindow();
    if (window != nullptr && window->GetSDLWindow() != nullptr) {
        SDL_GetWindowSize(window->GetSDLWindow(), &w, &h);
        if (w > 0 && h > 0) {
            g.win_w = w;
            g.win_h = h;
            return true;
        }
    }
    w = g.win_w;
    h = g.win_h;
    return w > 0 && h > 0;
}

// Window pixels to one of the frame's, as the frame is scaled into the window.
float FrameScale() {
    Window* window = MainWindow();
    int w = 0, h = 0;
    if (window == nullptr || !WindowSize(w, h) || window->GetWidth() <= 0 ||
        window->GetHeight() <= 0) {
        return 1.0f;
    }
    return std::min(static_cast<float>(w) / window->GetWidth(),
                    static_cast<float>(h) / window->GetHeight());
}

Finger* Find(SDL_FingerID id) {
    for (int i = 0; i < g.count; ++i) {
        if (g.fingers[i].id == id) return &g.fingers[i];
    }
    return nullptr;
}

void Remove(SDL_FingerID id) {
    for (int i = 0; i < g.count; ++i) {
        if (g.fingers[i].id == id) {
            g.fingers[i] = g.fingers[--g.count];
            return;
        }
    }
}

void Middle(float& x, float& y) {
    x = y = 0.0f;
    for (int i = 0; i < g.count; ++i) {
        x += g.fingers[i].x;
        y += g.fingers[i].y;
    }
    if (g.count > 0) {
        x /= g.count;
        y /= g.count;
    }
}

// How far, on average, the fingers are from their middle; 0 for one finger.
float Spread() {
    if (g.count < 2) return 0.0f;
    float mx = 0.0f, my = 0.0f;
    Middle(mx, my);
    float sum = 0.0f;
    for (int i = 0; i < g.count; ++i) sum += std::hypot(g.fingers[i].x - mx, g.fingers[i].y - my);
    return sum / static_cast<float>(g.count);
}

// A short tick of the phone's vibrator, or the controller's, so a hold is
// felt to have clicked.
void Tick() {
    if (!g.haptic_tried) {
        g.haptic_tried = true;
        if (SDL_InitSubSystem(SDL_INIT_HAPTIC) == 0 && SDL_NumHaptics() > 0) {
            g.haptic = SDL_HapticOpen(0);
            if (g.haptic != nullptr && SDL_HapticRumbleInit(g.haptic) != 0) {
                SDL_HapticClose(g.haptic);
                g.haptic = nullptr;
            }
        }
    }
    if (g.haptic != nullptr) {
        SDL_HapticRumblePlay(g.haptic, 0.6f, 25);
    } else {
        Pad::Rumble();
    }
}

// The timer's own thread: it only posts, and the game's thread decides.
Uint32 HoldElapsed(Uint32, void* touch) {
    SDL_Event event{};
    event.type = g.hold_event;
    event.user.code = static_cast<Sint32>(reinterpret_cast<uintptr_t>(touch));
    SDL_PushEvent(&event);
    return 0;
}

#ifdef __IPHONEOS__
// Forgets the fingers nobody has reported lately. iOS can end a touch without
// the app being told -- when a system gesture takes it over, say -- and a
// finger like that would otherwise stay down forever: the pan it was part of
// would never end, and every later touch would join that pan instead of
// starting a gesture, so the pointer would stop following the screen. A
// single finger waiting for its hold is the one kind of rest that is not
// that, and is left alone.
void ForgetLostFingers(Uint32 now) {
    if (g.mode != Mode::Panning && g.count <= 1) return;
    for (int i = g.count - 1; i >= 0; --i) {
        if (now - g.fingers[i].last < kLostMs) continue;
        Remove(g.fingers[i].id);
    }
}
#endif

bool InMinimap(float x, float y) {
    if (g.mini.w > 0 && g.mini.h > 0 && x >= g.mini.x && x < g.mini.x + g.mini.w &&
        y >= g.mini.y && y < g.mini.y + g.mini.h) return true;
    // A frame wider than the art can leave the configured well a little off;
    // the minimap always occupies the bottom-right corner.
    const Window* window = MainWindow();
    const int fw = window != nullptr && window->GetWidth() > 0 ? window->GetWidth() : g.win_w;
    const int fh = window != nullptr && window->GetHeight() > 0 ? window->GetHeight() : g.win_h;
    return fw > 0 && fh > 0 && x > fw * 0.80f && y > fh * 0.72f;
}

void MiniOrder(float x, float y) {
    MovePointer(x, y);
    Pointer::Click(SDL_BUTTON_RIGHT);
    g.last_mini_order = SDL_GetTicks();
}

bool InGroupButton(float x, float y) {
    for (const SDL_Rect& r : g.ui_groups) {
        if (r.w > 0 && x >= r.x && x < r.x + r.w && y >= r.y && y < r.y + r.h) return true;
    }
    return false;
}

void Down(SDL_FingerID id, float x, float y) {
    const Uint32 now = SDL_GetTicks();
#ifdef __IPHONEOS__
    if (Find(id) == nullptr) ForgetLostFingers(now);
#endif
    if (Find(id) == nullptr && g.count < kMaxFingers) g.fingers[g.count++] = Finger{id, x, y, now};
    if (g.count == 1) {
        g.primary = id;
        g.start_x = x;
        g.start_y = y;
        g.started = now;
        // The pointer goes to the finger, so what is under it shows as under
        // a mouse: the cursor, the help, a building waiting to be placed.
        MovePointer(x, y);
        if (g.aiming) {
            g.mode = Mode::Aiming;
            return;
        }
        g.mode = InMinimap(x, y) ? Mode::MiniPending : Mode::Pending;
        if (InGroupButton(x, y)) {
            // Press now, so a long hold can assign the group; the release
            // decides between select and assign.
            g.group_hold = true;
            MovePointer(x, y);
            Pointer::Press(SDL_BUTTON_LEFT);
        }
        ++g.serial;
        SDL_AddTimer(g.mode == Mode::MiniPending ? kMiniHoldMs : kHoldMs, HoldElapsed,
                     reinterpret_cast<void*>(static_cast<uintptr_t>(g.serial)));
        return;
    }
    // Another finger: whatever the first was doing gives way to moving the map.
    if (g.mode == Mode::Dragging) {
        const Finger* first = Find(g.primary);
        MovePointer(first != nullptr ? first->x : x, first != nullptr ? first->y : y);
        Pointer::Release(SDL_BUTTON_LEFT);
    }
    if (g.mode != Mode::Panning) {
        g.pan_dx = 0.0f;
        g.pan_dy = 0.0f;
        g.zoom = 1.0f;
    }
    g.mode = Mode::Panning;
    Middle(g.pan_x, g.pan_y);
    g.spread = Spread();
}

void Motion(SDL_FingerID id, float x, float y, int window_h) {
    Finger* finger = Find(id);
    if (finger == nullptr) return;
    const float old_x = finger->x;
    const float old_y = finger->y;
    finger->x = x;
    finger->y = y;
    finger->last = SDL_GetTicks();
    switch (g.mode) {
    case Mode::Pending:
        if (id != g.primary || std::hypot(x - g.start_x, y - g.start_y) <= kSlop) return;
        // With the left button chosen a drag boxes; with the right button it
        // pans the map. No hold is needed to start a box.
        if (g.aiming || g.world_button == SDL_BUTTON_LEFT) {
            g.mode = Mode::Dragging;
            MovePointer(g.start_x, g.start_y);
            Pointer::Press(SDL_BUTTON_LEFT);
            MovePointer(x, y);
        } else {
            g.mode = Mode::OnePan;
            MovePointer(x, y);
        }
        return;
    case Mode::OnePan: {
        if (id != g.primary) return;
        g.pan_dx += x - old_x;
        g.pan_dy += y - old_y;
        MovePointer(x, y);
        return;
    }
    case Mode::MiniPending:
        if (id == g.primary) MovePointer(x, y);
        return;
    case Mode::MiniHeld:
        if (id == g.primary) MovePointer(x, y);
        return;
    case Mode::Held:
        if (id == g.primary && std::hypot(x - g.start_x, y - g.start_y) > kSlop) {
            g.mode = Mode::Dragging;
            MovePointer(g.start_x, g.start_y);
            Pointer::Press(SDL_BUTTON_LEFT);
            MovePointer(x, y);
        }
        return;
    case Mode::Dragging:
    case Mode::Aiming:
        if (id == g.primary) MovePointer(x, y);
        return;
    case Mode::Panning: {
        float mx = 0.0f, my = 0.0f;
        Middle(mx, my);
        g.pan_dx += mx - g.pan_x;
        g.pan_dy += my - g.pan_y;
        g.pan_x = mx;
        g.pan_y = my;
        // Spread apart, in; drawn together, out.
        const float spread = Spread();
        if (g.spread > 0.0f && spread > 0.0f) g.zoom *= spread / g.spread;
        g.spread = spread;
        return;
    }
    default:
        return;
    }
}

void Up(SDL_FingerID id, float x, float y) {
    const bool first = id == g.primary;
    Remove(id);
    switch (g.mode) {
    case Mode::Pending:
    case Mode::Held:
        // A tap: clicked where it went down, which a shaking finger may have
        // wandered a little from. The interface always takes the left button;
        // the world takes the one the mouse-mode button chose. A hold that
        // never turned into a box still counts as one tap.
        if (g.group_hold) {
            g.group_hold = false;
            if (first) {
                MovePointer(x, y);
                Pointer::Release(SDL_BUTTON_LEFT);
            }
            break;
        }
        if (first) {
            const bool on_button = g.ui_button.w > 0 &&
                                   g.start_x >= g.ui_button.x && g.start_x < g.ui_button.x + g.ui_button.w &&
                                   g.start_y >= g.ui_button.y && g.start_y < g.ui_button.y + g.ui_button.h;
            bool on_group = false;
            for (const SDL_Rect& gr : g.ui_groups) {
                if (gr.w > 0 && g.start_x >= gr.x && g.start_x < gr.x + gr.w &&
                    g.start_y >= gr.y && g.start_y < gr.y + gr.h) {
                    on_group = true;
                    break;
                }
            }
            const bool on_interface = g.ui_only || on_button || on_group ||
                                      g.start_y < g.hud_top || g.start_y >= g.hud_panel;
            __android_log_print(ANDROID_LOG_INFO, "OpenAokHD",
                                "TOUCHUP y=%.1f hud=(%d,%d) ui=%d interface=%d",
                                g.start_y, g.hud_top, g.hud_panel, g.ui_only ? 1 : 0,
                                on_interface ? 1 : 0);
            if (!on_interface) {
                g.tap_active = true;
                g.tap_x = g.start_x;
                g.tap_y = g.start_y;
                g.tap_right = g.world_button == SDL_BUTTON_RIGHT;
                MovePointer(g.start_x, g.start_y);
            } else {
                Click(SDL_BUTTON_LEFT, g.start_x, g.start_y);
            }
        }
        break;
    case Mode::OnePan:
        // A quick swipe has already moved the map; it is not a click.
        break;
    case Mode::MiniPending:
        if (first) Click(SDL_BUTTON_LEFT, x, y);
        break;
    case Mode::MiniHeld:
        break;
    case Mode::Dragging:
        if (first) {
            MovePointer(x, y);
            Pointer::Release(SDL_BUTTON_LEFT);
        }
        break;
    case Mode::Aiming:
        if (first) Click(SDL_BUTTON_LEFT, x, y);
        break;
    case Mode::Panning:
        // The fingers still down go on moving the map, from where they are.
        if (g.count > 0) {
            Middle(g.pan_x, g.pan_y);
            g.spread = Spread();
            return;
        }
        break;
    default:
        break;
    }
    if (g.count == 0) g.mode = Mode::Idle;
}

} // namespace

void Enable() {
    g.enabled = true;
    g_mouse = false;   // until the system says one is plugged in
    g.hold_event = SDL_RegisterEvents(1);
    SDL_SetHint(SDL_HINT_TOUCH_MOUSE_EVENTS, "0");
    // A touch is one click: do not let SDL turn two ordinary taps into a
    // double-click (which would select every unit of the kind).
    SDL_SetHint(SDL_HINT_MOUSE_DOUBLE_CLICK_TIME, "1");
    SDL_SetHint(SDL_HINT_MOUSE_DOUBLE_CLICK_RADIUS, "1");
}

bool Enabled() { return g.enabled; }

bool MouseAttached() { return g_mouse || !Pointer::ByFinger(); }

void TakeZoom(float& factor, float& x, float& y) {
    factor = g.zoom;
    x = g.pan_x;
    y = g.pan_y;
    g.zoom = 1.0f;
}

void SetAiming(bool aiming) { g.aiming = aiming; }

void SetMinimapRect(int x, int y, int w, int h) { g.mini = SDL_Rect{x, y, w, h}; }
void SetHudBands(int top, int panel) { g.hud_top = top; g.hud_panel = panel; }
void SetUiOnly(bool ui_only) { g.ui_only = ui_only; }
void SetUiButtonRect(int x, int y, int w, int h) { g.ui_button = SDL_Rect{x, y, w, h}; }
void SetGroupButtonRect(int index, int x, int y, int w, int h) {
    if (index >= 0 && index < 5) g.ui_groups[index] = SDL_Rect{x, y, w, h};
}

void Reset() {
    const bool enabled = g.enabled;
    const Uint32 hold_event = g.hold_event;
    const SDL_Haptic* haptic = g.haptic;
    g = State{};
    g.enabled = enabled;
    g.hold_event = hold_event;
    g.haptic = const_cast<SDL_Haptic*>(haptic);
    g.world_button = SDL_BUTTON_RIGHT;
}
Uint8 WorldButton() { return g.world_button; }
void ToggleWorldButton() {
    g.world_button = g.world_button == SDL_BUTTON_LEFT ? SDL_BUTTON_RIGHT : SDL_BUTTON_LEFT;
}

bool TakeWorldTap(float& x, float& y, bool& right) {
    if (!g.tap_active) return false;
    g.tap_active = false;
    x = g.tap_x;
    y = g.tap_y;
    right = g.tap_right;
    return true;
}

void TakePan(float& dx, float& dy) {
    dx = g.pan_dx;
    dy = g.pan_dy;
    g.pan_dx = 0.0f;
    g.pan_dy = 0.0f;
}

bool Handle(const SDL_Event& event) {
    if (!g.enabled) return false;
    if (g.hold_event != 0 && g.hold_event != static_cast<Uint32>(-1) && event.type == g.hold_event) {
        if (static_cast<Uint32>(event.user.code) == g.serial) {
            if (g.mode == Mode::Pending) {
                g.mode = Mode::Held;
                Tick();
            } else if (g.mode == Mode::MiniPending) {
                g.mode = Mode::MiniHeld;
                Tick();
            }
        }
        return true;
    }
    if (event.type != SDL_FINGERDOWN && event.type != SDL_FINGERMOTION && event.type != SDL_FINGERUP) {
        return false;
    }
    // The screen itself, not a touchpad, nor a mouse's own made-up fingers.
    // Some handheld touch panels are reported as indirect; only SDL's own
    // made-up mouse fingers are ignored.
    if (event.tfinger.touchId == SDL_MOUSE_TOUCHID) return false;
    int w = 0, h = 0;
    if (!WindowSize(w, h)) return true;
    // The window is the screen; the frame inside it is smaller. Everything
    // the gesture layer, the pointer and the game's hit tests use is frame
    // pixels, so convert once here.
    const float scale = std::max(0.0001f, FrameScale());
    int gx = 0, gy = 0;
    if (Window* window = MainWindow()) {
        window->ToGame(static_cast<int>(event.tfinger.x * w),
                       static_cast<int>(event.tfinger.y * h), gx, gy);
    }
    const float x = static_cast<float>(gx);
    const float y = static_cast<float>(gy);
    switch (event.type) {
    case SDL_FINGERDOWN:
        Down(event.tfinger.fingerId, x, y);
        break;
    case SDL_FINGERMOTION:
        Motion(event.tfinger.fingerId, x, y, h / scale);
        break;
    default:
        Up(event.tfinger.fingerId, x, y);
        break;
    }
    return true;
}

} // namespace HAL::Touch

#ifdef __ANDROID__
// GameActivity, whenever a device comes or goes: whether one of them is a mouse.
extern "C" JNIEXPORT void JNICALL Java_org_openaok_game_GameActivity_nativeMouseAttached(
    JNIEnv*, jclass, jboolean attached) {
    HAL::Touch::g_mouse = attached == JNI_TRUE;
    __android_log_print(ANDROID_LOG_INFO, "OpenAoK", "[Touch] mouse %s",
                        attached == JNI_TRUE ? "plugged in" : "not plugged in");
}
#endif
