.class public final synthetic Lorg/libsdl/app/SDLAudioManager$1$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/Consumer;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 0

    .line 0
    check-cast p1, Landroid/media/AudioDeviceInfo;

    invoke-static {p1}, Lorg/libsdl/app/SDLAudioManager$1;->lambda$onAudioDevicesRemoved$1(Landroid/media/AudioDeviceInfo;)V

    return-void
.end method
