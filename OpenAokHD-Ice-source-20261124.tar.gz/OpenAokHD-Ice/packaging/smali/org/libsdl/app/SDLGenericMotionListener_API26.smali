.class Lorg/libsdl/app/SDLGenericMotionListener_API26;
.super Lorg/libsdl/app/SDLGenericMotionListener_API24;
.source "SDLControllerManager.java"


# instance fields
.field private mRelativeModeEnabled:Z


# direct methods
.method constructor <init>()V
    .locals 0

    .line 749
    invoke-direct {p0}, Lorg/libsdl/app/SDLGenericMotionListener_API24;-><init>()V

    return-void
.end method


# virtual methods
.method public getEventX(Landroid/view/MotionEvent;)F
    .locals 0

    const/4 p0, 0x0

    .line 848
    invoke-virtual {p1, p0}, Landroid/view/MotionEvent;->getX(I)F

    move-result p0

    return p0
.end method

.method public getEventY(Landroid/view/MotionEvent;)F
    .locals 0

    const/4 p0, 0x0

    .line 854
    invoke-virtual {p1, p0}, Landroid/view/MotionEvent;->getY(I)F

    move-result p0

    return p0
.end method

.method public inRelativeMode()Z
    .locals 0

    .line 819
    iget-boolean p0, p0, Lorg/libsdl/app/SDLGenericMotionListener_API26;->mRelativeModeEnabled:Z

    return p0
.end method

.method public onGenericMotion(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 6

    .line 758
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getSource()I

    move-result p0

    const/16 p1, 0x2002

    const/16 v0, 0x9

    const/16 v1, 0xa

    const/16 v2, 0x8

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eq p0, p1, :cond_4

    const/16 p1, 0x3002

    if-eq p0, p1, :cond_4

    const p1, 0x20004

    if-eq p0, p1, :cond_1

    const p1, 0x1000010

    if-eq p0, p1, :cond_0

    goto :goto_0

    .line 760
    :cond_0
    invoke-static {p2}, Lorg/libsdl/app/SDLControllerManager;->handleJoystickMotionEvent(Landroid/view/MotionEvent;)Z

    move-result p0

    return p0

    .line 785
    :cond_1
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result p0

    if-eq p0, v3, :cond_3

    if-eq p0, v2, :cond_2

    goto :goto_0

    .line 788
    :cond_2
    invoke-virtual {p2, v1, v5}, Landroid/view/MotionEvent;->getAxisValue(II)F

    move-result p1

    .line 789
    invoke-virtual {p2, v0, v5}, Landroid/view/MotionEvent;->getAxisValue(II)F

    move-result p2

    .line 790
    invoke-static {v5, p0, p1, p2, v5}, Lorg/libsdl/app/SDLActivity;->onNativeMouse(IIFFZ)V

    return v4

    .line 794
    :cond_3
    invoke-virtual {p2, v5}, Landroid/view/MotionEvent;->getX(I)F

    move-result p1

    .line 795
    invoke-virtual {p2, v5}, Landroid/view/MotionEvent;->getY(I)F

    move-result p2

    .line 796
    invoke-static {v5, p0, p1, p2, v4}, Lorg/libsdl/app/SDLActivity;->onNativeMouse(IIFFZ)V

    return v4

    .line 765
    :cond_4
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result p0

    if-eq p0, v3, :cond_6

    if-eq p0, v2, :cond_5

    :goto_0
    return v5

    .line 768
    :cond_5
    invoke-virtual {p2, v1, v5}, Landroid/view/MotionEvent;->getAxisValue(II)F

    move-result p1

    .line 769
    invoke-virtual {p2, v0, v5}, Landroid/view/MotionEvent;->getAxisValue(II)F

    move-result p2

    .line 770
    invoke-static {v5, p0, p1, p2, v5}, Lorg/libsdl/app/SDLActivity;->onNativeMouse(IIFFZ)V

    return v4

    .line 774
    :cond_6
    invoke-virtual {p2, v5}, Landroid/view/MotionEvent;->getX(I)F

    move-result p1

    .line 775
    invoke-virtual {p2, v5}, Landroid/view/MotionEvent;->getY(I)F

    move-result p2

    .line 776
    invoke-static {v5, p0, p1, p2, v5}, Lorg/libsdl/app/SDLActivity;->onNativeMouse(IIFFZ)V

    return v4
.end method

.method public reclaimRelativeMouseModeIfNeeded()V
    .locals 0

    .line 840
    iget-boolean p0, p0, Lorg/libsdl/app/SDLGenericMotionListener_API26;->mRelativeModeEnabled:Z

    if-eqz p0, :cond_0

    invoke-static {}, Lorg/libsdl/app/SDLActivity;->isDeXMode()Z

    move-result p0

    if-nez p0, :cond_0

    .line 841
    invoke-static {}, Lorg/libsdl/app/SDLActivity;->getContentView()Landroid/view/View;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/View;->requestPointerCapture()V

    :cond_0
    return-void
.end method

.method public setRelativeMouseEnabled(Z)Z
    .locals 1

    .line 824
    invoke-static {}, Lorg/libsdl/app/SDLActivity;->isDeXMode()Z

    if-eqz p1, :cond_0

    .line 826
    invoke-static {}, Lorg/libsdl/app/SDLActivity;->getContentView()Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->requestPointerCapture()V

    goto :goto_0

    .line 828
    :cond_0
    invoke-static {}, Lorg/libsdl/app/SDLActivity;->getContentView()Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->releasePointerCapture()V

    .line 830
    :goto_0
    iput-boolean p1, p0, Lorg/libsdl/app/SDLGenericMotionListener_API26;->mRelativeModeEnabled:Z

    const/4 p0, 0x1

    return p0
.end method

.method public supportsRelativeMouse()Z
    .locals 0

    .line 814
    invoke-static {}, Lorg/libsdl/app/SDLActivity;->isDeXMode()Z

    const/4 p0, 0x1

    return p0
.end method
