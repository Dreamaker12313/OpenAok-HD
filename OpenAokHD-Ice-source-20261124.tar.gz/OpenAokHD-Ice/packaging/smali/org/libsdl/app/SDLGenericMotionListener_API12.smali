.class Lorg/libsdl/app/SDLGenericMotionListener_API12;
.super Ljava/lang/Object;
.source "SDLControllerManager.java"

# interfaces
.implements Landroid/view/View$OnGenericMotionListener;


# direct methods
.method constructor <init>()V
    .locals 0

    .line 622
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public getEventX(Landroid/view/MotionEvent;)F
    .locals 0

    const/4 p0, 0x0

    .line 680
    invoke-virtual {p1, p0}, Landroid/view/MotionEvent;->getX(I)F

    move-result p0

    return p0
.end method

.method public getEventY(Landroid/view/MotionEvent;)F
    .locals 0

    const/4 p0, 0x0

    .line 684
    invoke-virtual {p1, p0}, Landroid/view/MotionEvent;->getY(I)F

    move-result p0

    return p0
.end method

.method public inRelativeMode()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public onGenericMotion(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 3

    .line 629
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getSource()I

    move-result p0

    const/16 p1, 0x2002

    const/4 v0, 0x0

    if-eq p0, p1, :cond_1

    const p1, 0x1000010

    if-eq p0, p1, :cond_0

    goto :goto_0

    .line 631
    :cond_0
    invoke-static {p2}, Lorg/libsdl/app/SDLControllerManager;->handleJoystickMotionEvent(Landroid/view/MotionEvent;)Z

    move-result p0

    return p0

    .line 634
    :cond_1
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result p0

    const/4 p1, 0x7

    const/4 v1, 0x1

    if-eq p0, p1, :cond_3

    const/16 p1, 0x8

    if-eq p0, p1, :cond_2

    :goto_0
    return v0

    :cond_2
    const/16 p1, 0xa

    .line 637
    invoke-virtual {p2, p1, v0}, Landroid/view/MotionEvent;->getAxisValue(II)F

    move-result p1

    const/16 v2, 0x9

    .line 638
    invoke-virtual {p2, v2, v0}, Landroid/view/MotionEvent;->getAxisValue(II)F

    move-result p2

    .line 639
    invoke-static {v0, p0, p1, p2, v0}, Lorg/libsdl/app/SDLActivity;->onNativeMouse(IIFFZ)V

    return v1

    .line 643
    :cond_3
    invoke-virtual {p2, v0}, Landroid/view/MotionEvent;->getX(I)F

    move-result p1

    .line 644
    invoke-virtual {p2, v0}, Landroid/view/MotionEvent;->getY(I)F

    move-result p2

    .line 646
    invoke-static {v0, p0, p1, p2, v0}, Lorg/libsdl/app/SDLActivity;->onNativeMouse(IIFFZ)V

    return v1
.end method

.method public reclaimRelativeMouseModeIfNeeded()V
    .locals 0

    return-void
.end method

.method public setRelativeMouseEnabled(Z)Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method

.method public supportsRelativeMouse()Z
    .locals 0

    const/4 p0, 0x0

    return p0
.end method
