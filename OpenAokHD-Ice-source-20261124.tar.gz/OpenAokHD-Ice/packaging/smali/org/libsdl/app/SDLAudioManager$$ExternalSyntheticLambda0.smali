.class public final synthetic Lorg/libsdl/app/SDLAudioManager$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/function/ToIntFunction;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final applyAsInt(Ljava/lang/Object;)I
    .locals 0

    .line 0
    check-cast p1, Landroid/media/AudioDeviceInfo;

    invoke-static {p1}, Lorg/libsdl/app/SDLAudioManager;->$r8$lambda$iPF4QPypmKNdEynIqZOm9XoZWY4(Landroid/media/AudioDeviceInfo;)I

    move-result p0

    return p0
.end method
