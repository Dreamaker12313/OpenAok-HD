.class Lorg/libsdl/app/SDLJoystickHandler_API19;
.super Lorg/libsdl/app/SDLJoystickHandler_API16;
.source "SDLControllerManager.java"


# direct methods
.method constructor <init>()V
    .locals 0

    .line 328
    invoke-direct {p0}, Lorg/libsdl/app/SDLJoystickHandler_API16;-><init>()V

    return-void
.end method


# virtual methods
.method public getAxisMask(Ljava/util/List;)I
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/view/InputDevice$MotionRange;",
            ">;)I"
        }
    .end annotation

    .line 345
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    const/4 v0, 0x2

    const/4 v1, 0x0

    if-lt p0, v0, :cond_0

    const/4 p0, 0x3

    goto :goto_0

    :cond_0
    move p0, v1

    .line 349
    :goto_0
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x4

    if-lt v0, v2, :cond_1

    or-int/lit8 p0, p0, 0xc

    .line 353
    :cond_1
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x6

    if-lt v0, v2, :cond_2

    or-int/lit8 p0, p0, 0x30

    .line 361
    :cond_2
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    move v0, v1

    :cond_3
    :goto_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/view/InputDevice$MotionRange;

    .line 362
    invoke-virtual {v2}, Landroid/view/InputDevice$MotionRange;->getAxis()I

    move-result v2

    const/4 v3, 0x1

    const/16 v4, 0xb

    if-ne v2, v4, :cond_4

    move v1, v3

    goto :goto_1

    :cond_4
    if-le v2, v4, :cond_3

    const/16 v4, 0xe

    if-ge v2, v4, :cond_3

    move v0, v3

    goto :goto_1

    :cond_5
    if-eqz v1, :cond_6

    if-eqz v0, :cond_6

    const p1, 0x8000

    or-int/2addr p0, p1

    :cond_6
    return p0
.end method

.method public getButtonMask(Landroid/view/InputDevice;)I
    .locals 4

    const/16 p0, 0x26

    .line 380
    new-array v0, p0, [I

    fill-array-data v0, :array_0

    .line 422
    new-array v1, p0, [I

    fill-array-data v1, :array_1

    .line 463
    invoke-virtual {p1, v0}, Landroid/view/InputDevice;->hasKeys([I)[Z

    move-result-object p1

    const/4 v0, 0x0

    move v2, v0

    :goto_0
    if-ge v0, p0, :cond_1

    .line 465
    aget-boolean v3, p1, v0

    if-eqz v3, :cond_0

    .line 466
    aget v3, v1, v0

    or-int/2addr v2, v3

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return v2

    nop

    :array_0
    .array-data 4
        0x60
        0x61
        0x63
        0x64
        0x4
        0x52
        0x6e
        0x6c
        0x6a
        0x6b
        0x66
        0x67
        0x13
        0x14
        0x15
        0x16
        0x6d
        0x17
        0x68
        0x69
        0x62
        0x65
        0xbc
        0xbd
        0xbe
        0xbf
        0xc0
        0xc1
        0xc2
        0xc3
        0xc4
        0xc5
        0xc6
        0xc7
        0xc8
        0xc9
        0xca
        0xcb
    .end array-data

    :array_1
    .array-data 4
        0x1
        0x2
        0x4
        0x8
        0x10
        0x40
        0x20
        0x40
        0x80
        0x100
        0x200
        0x400
        0x800
        0x1000
        0x2000
        0x4000
        0x10
        0x1
        0x8000
        0x10000
        0x20000
        0x40000
        0x100000
        0x200000
        0x400000
        0x800000
        0x1000000
        0x2000000
        0x4000000
        0x8000000
        0x10000000
        0x20000000
        0x40000000    # 2.0f
        -0x80000000
        -0x1
        -0x1
        -0x1
        -0x1
    .end array-data
.end method

.method public getProductId(Landroid/view/InputDevice;)I
    .locals 0

    .line 332
    invoke-virtual {p1}, Landroid/view/InputDevice;->getProductId()I

    move-result p0

    return p0
.end method

.method public getVendorId(Landroid/view/InputDevice;)I
    .locals 0

    .line 337
    invoke-virtual {p1}, Landroid/view/InputDevice;->getVendorId()I

    move-result p0

    return p0
.end method
