.class public final Lorg/openaok/game/R$string;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/openaok/game/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "string"
.end annotation


# static fields
.field public static app_name:I = 0x7f030000

.field public static choose_folder:I = 0x7f030001

.field public static copying:I = 0x7f030002

.field public static deck_age_up:I = 0x7f030003

.field public static deck_alert:I = 0x7f030004

.field public static deck_clock:I = 0x7f030005

.field public static deck_delete:I = 0x7f030006

.field public static deck_delete_confirm:I = 0x7f030007

.field public static deck_flare:I = 0x7f030008

.field public static deck_food:I = 0x7f030009

.field public static deck_gold:I = 0x7f03000a

.field public static deck_goto_empty:I = 0x7f03000b

.field public static deck_group_hint:I = 0x7f03000c

.field public static deck_idle:I = 0x7f03000d

.field public static deck_idle_caption:I = 0x7f03000e

.field public static deck_idle_military:I = 0x7f03000f

.field public static deck_idle_villager:I = 0x7f030010

.field public static deck_map_combat:I = 0x7f030011

.field public static deck_map_economic:I = 0x7f030012

.field public static deck_map_normal:I = 0x7f030013

.field public static deck_menu:I = 0x7f030014

.field public static deck_nothing:I = 0x7f030015

.field public static deck_objectives:I = 0x7f030016

.field public static deck_placing:I = 0x7f030017

.field public static deck_pop:I = 0x7f030018

.field public static deck_speed:I = 0x7f030019

.field public static deck_stats:I = 0x7f03001a

.field public static deck_stone:I = 0x7f03001b

.field public static deck_tab_commands:I = 0x7f03001c

.field public static deck_tab_game:I = 0x7f03001d

.field public static deck_tab_goto:I = 0x7f03001e

.field public static deck_techtree:I = 0x7f03001f

.field public static deck_to_selection:I = 0x7f030020

.field public static deck_town_center:I = 0x7f030021

.field public static deck_wood:I = 0x7f030022

.field public static launch_need:I = 0x7f030023

.field public static launch_newer:I = 0x7f030024

.field public static launch_ready:I = 0x7f030025

.field public static play:I = 0x7f030026

.field public static play_anyway:I = 0x7f030027

.field public static reading:I = 0x7f030028


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
