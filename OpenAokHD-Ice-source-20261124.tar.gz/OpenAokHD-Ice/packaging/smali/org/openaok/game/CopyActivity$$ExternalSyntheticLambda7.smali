.class public final synthetic Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lorg/openaok/game/CopyActivity;

.field public final synthetic f$1:Landroid/net/Uri;


# direct methods
.method public synthetic constructor <init>(Lorg/openaok/game/CopyActivity;Landroid/net/Uri;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda7;->f$0:Lorg/openaok/game/CopyActivity;

    iput-object p2, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda7;->f$1:Landroid/net/Uri;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda7;->f$0:Lorg/openaok/game/CopyActivity;

    iget-object v1, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda7;->f$1:Landroid/net/Uri;

    invoke-virtual {v0, v1}, Lorg/openaok/game/CopyActivity;->lambda$importMods$5$org-openaok-game-CopyActivity(Landroid/net/Uri;)V

    return-void
.end method
