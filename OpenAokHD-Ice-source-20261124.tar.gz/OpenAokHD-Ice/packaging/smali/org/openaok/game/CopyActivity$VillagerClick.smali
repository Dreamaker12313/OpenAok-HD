.class public final Lorg/openaok/game/CopyActivity$VillagerClick;
.super Ljava/lang/Object;
.implements Landroid/view/View$OnClickListener;
.implements Ljava/lang/Runnable;

.field private final activity:Lorg/openaok/game/CopyActivity;

.method public constructor <init>(Lorg/openaok/game/CopyActivity;)V
    .registers 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    iput-object p1, p0, Lorg/openaok/game/CopyActivity$VillagerClick;->activity:Lorg/openaok/game/CopyActivity;
    return-void
.end method

.method public onClick(Landroid/view/View;)V
    .registers 4
    const-string v0, "fa.wav"
    invoke-direct {p0, v0}, Lorg/openaok/game/CopyActivity$VillagerClick;->play(Ljava/lang/String;)V
    const-string v0, "伐"
    invoke-direct {p0, v0}, Lorg/openaok/game/CopyActivity$VillagerClick;->append(Ljava/lang/String;)V
    invoke-virtual {p1, p0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z
    const-wide/16 v0, 0x1a4
    invoke-virtual {p1, p0, v0, v1}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z
    return-void
.end method

.method public run()V
    .registers 2
    const-string v0, "mugong.wav"
    invoke-direct {p0, v0}, Lorg/openaok/game/CopyActivity$VillagerClick;->play(Ljava/lang/String;)V
    const-string v0, "木工"
    invoke-direct {p0, v0}, Lorg/openaok/game/CopyActivity$VillagerClick;->append(Ljava/lang/String;)V
    return-void
.end method

.method private append(Ljava/lang/String;)V
    .registers 8
    iget-object v0, p0, Lorg/openaok/game/CopyActivity$VillagerClick;->activity:Lorg/openaok/game/CopyActivity;
    iget-object v1, v0, Lorg/openaok/game/CopyActivity;->bubble:Landroid/widget/TextView;
    iget-object v2, v0, Lorg/openaok/game/CopyActivity;->tail:Landroid/view/View;
    const/4 v3, 0x0
    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setVisibility(I)V
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setVisibility(I)V
    const/high16 v3, 0x3f800000
    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setAlpha(F)V
    iget-object v3, v0, Lorg/openaok/game/CopyActivity;->clear:Lorg/openaok/game/CopyActivity$VillagerClear;
    invoke-virtual {v1, v3}, Landroid/widget/TextView;->removeCallbacks(Ljava/lang/Runnable;)Z
    invoke-virtual {v1}, Landroid/widget/TextView;->animate()Landroid/view/ViewPropertyAnimator;
    move-result-object v4
    invoke-virtual {v4}, Landroid/view/ViewPropertyAnimator;->cancel()V
    invoke-virtual {v1}, Landroid/widget/TextView;->animate()Landroid/view/ViewPropertyAnimator;
    move-result-object v4
    const/4 v3, 0x0
    invoke-virtual {v4, v3}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;
    const-wide/16 v5, 0x708
    invoke-virtual {v4, v5, v6}, Landroid/view/ViewPropertyAnimator;->setStartDelay(J)Landroid/view/ViewPropertyAnimator;
    const-wide/16 v5, 0x258
    invoke-virtual {v4, v5, v6}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;
    invoke-virtual {v4}, Landroid/view/ViewPropertyAnimator;->start()V
    iget-object v3, v0, Lorg/openaok/game/CopyActivity;->clear:Lorg/openaok/game/CopyActivity$VillagerClear;
    const-wide/16 v5, 0xbb8
    invoke-virtual {v1, v3, v5, v6}, Landroid/widget/TextView;->postDelayed(Ljava/lang/Runnable;J)Z
    invoke-virtual {v1, p1}, Landroid/widget/TextView;->append(Ljava/lang/CharSequence;)V
    return-void
.end method

.method private play(Ljava/lang/String;)V
    .registers 10
    iget-object v7, p0, Lorg/openaok/game/CopyActivity$VillagerClick;->activity:Lorg/openaok/game/CopyActivity;
    iget-boolean v7, v7, Lorg/openaok/game/CopyActivity;->muted:Z
    if-eqz v7, :go
    return-void
    :go
    :try_start
    new-instance v0, Landroid/media/MediaPlayer;

    invoke-direct {v0}, Landroid/media/MediaPlayer;-><init>()V

    iget-object v1, p0, Lorg/openaok/game/CopyActivity$VillagerClick;->activity:Lorg/openaok/game/CopyActivity;

    invoke-virtual {v1}, Lorg/openaok/game/CopyActivity;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v1

    invoke-virtual {v1, p1}, Landroid/content/res/AssetManager;->openFd(Ljava/lang/String;)Landroid/content/res/AssetFileDescriptor;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/AssetFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;

    move-result-object v2

    invoke-virtual {v1}, Landroid/content/res/AssetFileDescriptor;->getStartOffset()J

    move-result-wide v3

    invoke-virtual {v1}, Landroid/content/res/AssetFileDescriptor;->getLength()J

    move-result-wide v5

    move-object v1, v2

    move-wide/from16 v2, v3

    move-wide/from16 v4, v5

    invoke-virtual/range {v0 .. v5}, Landroid/media/MediaPlayer;->setDataSource(Ljava/io/FileDescriptor;JJ)V

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->prepare()V

    invoke-virtual {v0}, Landroid/media/MediaPlayer;->start()V

    :try_end
    .catch Ljava/lang/Exception; {:try_start .. :try_end} :catch
    return-void
    :catch
    return-void
.end method
