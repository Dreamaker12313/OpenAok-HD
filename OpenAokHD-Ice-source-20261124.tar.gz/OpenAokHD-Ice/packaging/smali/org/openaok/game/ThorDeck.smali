.class public Lorg/openaok/game/ThorDeck;
.super Landroid/view/View;
.source "ThorDeck.java"


# static fields
.field private static final AMBER:I = -0x174fb6

.field private static final ART_BAR:Landroid/graphics/Rect;

.field private static final ART_BASE:I = 0xc7c5

.field private static final ART_H:I = 0x400

.field private static final ART_PARCHMENT:Landroid/graphics/Rect;

.field private static final ART_SLOT_RIGHT:[I

.field private static final ART_STONE:Landroid/graphics/Rect;

.field private static final ART_W:I = 0x500

.field private static final BG:I = -0xf1f2f5

.field private static final BRONZE:I = -0x4765a6

.field private static final CONFIRM_MS:J = 0xbb8L

.field private static final DIM:I = -0x737c8e

.field private static final GAME_NAMES:[I

.field private static final GREEN:I = -0x9040b6

.field private static final H:I = 0x438

.field private static final HOLD_MS:J = 0x1a4L

.field private static final INK:I = -0xd5e3f4

.field private static final INK_DIM:I = -0x94aac6

.field private static final LINE:I = -0xc5ccd8

.field private static final PANEL:I = -0xe5e7ec

.field private static final PANEL_HI:I = -0xd9dde5

.field private static final POLL_MS:J = 0x32L

.field private static final RED:I = -0x26a8c1

.field private static final ROMAN:[Ljava/lang/String;

.field private static final SHADE:I = -0x50000000

.field private static final TEXT:I = -0x12192a

.field private static final W:I = 0x4d8


# instance fields
.field private ageName:Ljava/lang/String;

.field private art:Landroid/graphics/Bitmap;

.field private artCiv:I

.field private final bmp:Landroid/graphics/Paint;

.field private final buttons:[Landroid/graphics/RectF;

.field private deleteArmedUntil:J

.field private final fill:Landroid/graphics/Paint;

.field private goToCount:I

.field private final goToEntry:[I

.field private final goToName:[Ljava/lang/String;

.field private final grid:Landroid/graphics/RectF;

.field private final groups:[Landroid/graphics/RectF;

.field private final handler:Landroid/os/Handler;

.field private final header:Landroid/graphics/RectF;

.field private held:Z

.field private help:Ljava/lang/String;

.field private helpUntil:J

.field private final iconBuf:[I

.field private final iconWh:[I

.field private final icons:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Long;",
            "Landroid/graphics/Bitmap;",
            ">;"
        }
    .end annotation
.end field

.field private inGame:Z

.field private final labels:[Ljava/lang/String;

.field private lastMapPush:J

.field private final mapArea:Landroid/graphics/RectF;

.field private mapBitmap:Landroid/graphics/Bitmap;

.field private final mapButtons:[Landroid/graphics/RectF;

.field private mapDrag:Z

.field private final mapPanel:Landroid/graphics/RectF;

.field private final mapPx:[I

.field private mapSerial:I

.field private nextAge:Ljava/lang/String;

.field private final path:Landroid/graphics/Path;

.field private final poll:Ljava/lang/Runnable;

.field private pressedAt:J

.field private pressedButton:I

.field private pressedGroup:I

.field private pressedSmall:I

.field private pressedTab:I

.field private pressedTile:I

.field private final queueRects:[Landroid/graphics/RectF;

.field private queueSlot:[I

.field private running:Z

.field private s:F

.field private selName:Ljava/lang/String;

.field private final selPanel:Landroid/graphics/RectF;

.field private final small:[Landroid/graphics/RectF;

.field private final snap:[I

.field private snapLen:I

.field private final speedBox:Landroid/graphics/RectF;

.field private stone:Landroid/graphics/Bitmap;

.field private stoneShader:Landroid/graphics/BitmapShader;

.field private final stroke:Landroid/graphics/Paint;

.field private tab:I

.field private final tabs:[Landroid/graphics/RectF;

.field private final text:Landroid/text/TextPaint;

.field private final tiles:[Landroid/graphics/RectF;

.field private final words:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static bridge synthetic -$$Nest$fgethandler(Lorg/openaok/game/ThorDeck;)Landroid/os/Handler;
    .locals 0

    iget-object p0, p0, Lorg/openaok/game/ThorDeck;->handler:Landroid/os/Handler;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetheld(Lorg/openaok/game/ThorDeck;)Z
    .locals 0

    iget-boolean p0, p0, Lorg/openaok/game/ThorDeck;->held:Z

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetpressedAt(Lorg/openaok/game/ThorDeck;)J
    .locals 2

    iget-wide v0, p0, Lorg/openaok/game/ThorDeck;->pressedAt:J

    return-wide v0
.end method

.method static bridge synthetic -$$Nest$fgetpressedGroup(Lorg/openaok/game/ThorDeck;)I
    .locals 0

    iget p0, p0, Lorg/openaok/game/ThorDeck;->pressedGroup:I

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetpressedTile(Lorg/openaok/game/ThorDeck;)I
    .locals 0

    iget p0, p0, Lorg/openaok/game/ThorDeck;->pressedTile:I

    return p0
.end method

.method static bridge synthetic -$$Nest$fgetrunning(Lorg/openaok/game/ThorDeck;)Z
    .locals 0

    iget-boolean p0, p0, Lorg/openaok/game/ThorDeck;->running:Z

    return p0
.end method

.method static bridge synthetic -$$Nest$fgettab(Lorg/openaok/game/ThorDeck;)I
    .locals 0

    iget p0, p0, Lorg/openaok/game/ThorDeck;->tab:I

    return p0
.end method

.method static bridge synthetic -$$Nest$fputheld(Lorg/openaok/game/ThorDeck;Z)V
    .locals 0

    iput-boolean p1, p0, Lorg/openaok/game/ThorDeck;->held:Z

    return-void
.end method

.method static bridge synthetic -$$Nest$mrefresh(Lorg/openaok/game/ThorDeck;)V
    .locals 0

    invoke-direct {p0}, Lorg/openaok/game/ThorDeck;->refresh()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mshowHelp(Lorg/openaok/game/ThorDeck;I)V
    .locals 0

    invoke-direct {p0, p1}, Lorg/openaok/game/ThorDeck;->showHelp(I)V

    return-void
.end method

.method static constructor <clinit>()V
    .locals 6

    .line 56
    new-instance v0, Landroid/graphics/Rect;

    const/16 v1, 0x1dd

    const/16 v2, 0x20

    const/4 v3, 0x0

    invoke-direct {v0, v3, v3, v1, v2}, Landroid/graphics/Rect;-><init>(IIII)V

    sput-object v0, Lorg/openaok/game/ThorDeck;->ART_BAR:Landroid/graphics/Rect;

    new-instance v0, Landroid/graphics/Rect;

    const/16 v1, 0x3fa

    const/16 v2, 0x15a

    const/16 v4, 0x338

    const/16 v5, 0x34e

    invoke-direct {v0, v2, v4, v5, v1}, Landroid/graphics/Rect;-><init>(IIII)V

    sput-object v0, Lorg/openaok/game/ThorDeck;->ART_PARCHMENT:Landroid/graphics/Rect;

    .line 57
    new-instance v0, Landroid/graphics/Rect;

    const/16 v1, 0x3e4

    const/16 v2, 0x24

    const/16 v4, 0x132

    invoke-direct {v0, v2, v5, v4, v1}, Landroid/graphics/Rect;-><init>(IIII)V

    sput-object v0, Lorg/openaok/game/ThorDeck;->ART_STONE:Landroid/graphics/Rect;

    const/16 v0, 0xe5

    const/16 v1, 0x17f

    const/16 v2, 0x4b

    const/16 v5, 0x98

    .line 58
    filled-new-array {v2, v5, v0, v4, v1}, [I

    move-result-object v0

    sput-object v0, Lorg/openaok/game/ThorDeck;->ART_SLOT_RIGHT:[I

    const/4 v0, 0x4

    .line 549
    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "I"

    aput-object v1, v0, v3

    const/4 v1, 0x1

    const-string v2, "II"

    aput-object v2, v0, v1

    const/4 v1, 0x2

    const-string v2, "III"

    aput-object v2, v0, v1

    const/4 v1, 0x3

    const-string v2, "IV"

    aput-object v2, v0, v1

    sput-object v0, Lorg/openaok/game/ThorDeck;->ROMAN:[Ljava/lang/String;

    .line 614
    sget v0, Lorg/openaok/game/R$string;->deck_objectives:I

    sget v1, Lorg/openaok/game/R$string;->deck_techtree:I

    sget v2, Lorg/openaok/game/R$string;->deck_stats:I

    sget v3, Lorg/openaok/game/R$string;->deck_clock:I

    sget v4, Lorg/openaok/game/R$string;->deck_menu:I

    filled-new-array {v0, v1, v2, v3, v4}, [I

    move-result-object v0

    sput-object v0, Lorg/openaok/game/ThorDeck;->GAME_NAMES:[I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 16

    move-object/from16 v0, p0

    .line 136
    invoke-direct/range {p0 .. p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 60
    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v1, v0, Lorg/openaok/game/ThorDeck;->handler:Landroid/os/Handler;

    const/16 v1, 0x800

    .line 61
    new-array v1, v1, [I

    iput-object v1, v0, Lorg/openaok/game/ThorDeck;->snap:[I

    const/high16 v1, 0x20000

    .line 63
    new-array v1, v1, [I

    iput-object v1, v0, Lorg/openaok/game/ThorDeck;->mapPx:[I

    const/4 v1, -0x1

    .line 65
    iput v1, v0, Lorg/openaok/game/ThorDeck;->mapSerial:I

    .line 66
    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    iput-object v2, v0, Lorg/openaok/game/ThorDeck;->icons:Ljava/util/Map;

    const/high16 v2, 0x10000

    .line 67
    new-array v2, v2, [I

    iput-object v2, v0, Lorg/openaok/game/ThorDeck;->iconBuf:[I

    const/4 v2, 0x2

    .line 68
    new-array v3, v2, [I

    iput-object v3, v0, Lorg/openaok/game/ThorDeck;->iconWh:[I

    .line 70
    iput v1, v0, Lorg/openaok/game/ThorDeck;->artCiv:I

    const/16 v3, 0xf

    .line 73
    new-array v4, v3, [Ljava/lang/String;

    iput-object v4, v0, Lorg/openaok/game/ThorDeck;->goToName:[Ljava/lang/String;

    .line 74
    new-array v4, v3, [I

    iput-object v4, v0, Lorg/openaok/game/ThorDeck;->goToEntry:[I

    .line 76
    iput v1, v0, Lorg/openaok/game/ThorDeck;->pressedGroup:I

    iput v1, v0, Lorg/openaok/game/ThorDeck;->pressedSmall:I

    iput v1, v0, Lorg/openaok/game/ThorDeck;->pressedTab:I

    .line 77
    new-instance v4, Ljava/util/HashMap;

    invoke-direct {v4}, Ljava/util/HashMap;-><init>()V

    iput-object v4, v0, Lorg/openaok/game/ThorDeck;->words:Ljava/util/Map;

    .line 80
    new-array v4, v3, [Ljava/lang/String;

    const/4 v5, 0x0

    const-string v6, ""

    aput-object v6, v4, v5

    const/4 v7, 0x1

    aput-object v6, v4, v7

    aput-object v6, v4, v2

    const/4 v8, 0x3

    aput-object v6, v4, v8

    const/4 v9, 0x4

    aput-object v6, v4, v9

    const/4 v10, 0x5

    aput-object v6, v4, v10

    const/4 v10, 0x6

    aput-object v6, v4, v10

    const/4 v11, 0x7

    aput-object v6, v4, v11

    const/16 v11, 0x8

    aput-object v6, v4, v11

    const/16 v11, 0x9

    aput-object v6, v4, v11

    const/16 v11, 0xa

    aput-object v6, v4, v11

    const/16 v11, 0xb

    aput-object v6, v4, v11

    const/16 v11, 0xc

    aput-object v6, v4, v11

    const/16 v11, 0xd

    aput-object v6, v4, v11

    const/16 v11, 0xe

    aput-object v6, v4, v11

    iput-object v4, v0, Lorg/openaok/game/ThorDeck;->labels:[Ljava/lang/String;

    .line 81
    iput-object v6, v0, Lorg/openaok/game/ThorDeck;->ageName:Ljava/lang/String;

    iput-object v6, v0, Lorg/openaok/game/ThorDeck;->nextAge:Ljava/lang/String;

    iput-object v6, v0, Lorg/openaok/game/ThorDeck;->selName:Ljava/lang/String;

    iput-object v6, v0, Lorg/openaok/game/ThorDeck;->help:Ljava/lang/String;

    .line 83
    iput v1, v0, Lorg/openaok/game/ThorDeck;->pressedTile:I

    iput v1, v0, Lorg/openaok/game/ThorDeck;->pressedButton:I

    const/high16 v1, 0x3f800000    # 1.0f

    .line 92
    iput v1, v0, Lorg/openaok/game/ThorDeck;->s:F

    .line 93
    new-instance v1, Landroid/graphics/RectF;

    const/high16 v4, 0x449b0000    # 1240.0f

    const/high16 v6, 0x42a80000    # 84.0f

    const/4 v11, 0x0

    invoke-direct {v1, v11, v11, v4, v6}, Landroid/graphics/RectF;-><init>(FFFF)V

    iput-object v1, v0, Lorg/openaok/game/ThorDeck;->header:Landroid/graphics/RectF;

    .line 94
    new-instance v1, Landroid/graphics/RectF;

    const/high16 v4, 0x41800000    # 16.0f

    const/high16 v6, 0x42c00000    # 96.0f

    const/high16 v11, 0x44200000    # 640.0f

    const/high16 v12, 0x43ca0000    # 404.0f

    invoke-direct {v1, v4, v6, v11, v12}, Landroid/graphics/RectF;-><init>(FFFF)V

    iput-object v1, v0, Lorg/openaok/game/ThorDeck;->mapPanel:Landroid/graphics/RectF;

    .line 95
    new-instance v1, Landroid/graphics/RectF;

    const/high16 v11, 0x441e0000    # 632.0f

    const/high16 v13, 0x43c60000    # 396.0f

    const/high16 v14, 0x41c00000    # 24.0f

    const/high16 v15, 0x42d00000    # 104.0f

    invoke-direct {v1, v14, v15, v11, v13}, Landroid/graphics/RectF;-><init>(FFFF)V

    iput-object v1, v0, Lorg/openaok/game/ThorDeck;->mapArea:Landroid/graphics/RectF;

    .line 96
    new-array v1, v9, [Landroid/graphics/RectF;

    iput-object v1, v0, Lorg/openaok/game/ThorDeck;->mapButtons:[Landroid/graphics/RectF;

    .line 97
    new-instance v1, Landroid/graphics/RectF;

    const/high16 v11, 0x44350000    # 724.0f

    const/high16 v13, 0x44990000    # 1224.0f

    invoke-direct {v1, v11, v6, v13, v12}, Landroid/graphics/RectF;-><init>(FFFF)V

    iput-object v1, v0, Lorg/openaok/game/ThorDeck;->selPanel:Landroid/graphics/RectF;

    .line 98
    new-array v1, v10, [Landroid/graphics/RectF;

    iput-object v1, v0, Lorg/openaok/game/ThorDeck;->buttons:[Landroid/graphics/RectF;

    .line 99
    new-array v1, v9, [Landroid/graphics/RectF;

    iput-object v1, v0, Lorg/openaok/game/ThorDeck;->groups:[Landroid/graphics/RectF;

    .line 100
    new-array v1, v9, [Landroid/graphics/RectF;

    iput-object v1, v0, Lorg/openaok/game/ThorDeck;->small:[Landroid/graphics/RectF;

    .line 101
    new-instance v1, Landroid/graphics/RectF;

    const/high16 v6, 0x447f0000    # 1020.0f

    const/high16 v10, 0x43f70000    # 494.0f

    const/high16 v11, 0x44900000    # 1152.0f

    const/high16 v12, 0x440b0000    # 556.0f

    invoke-direct {v1, v6, v10, v11, v12}, Landroid/graphics/RectF;-><init>(FFFF)V

    iput-object v1, v0, Lorg/openaok/game/ThorDeck;->speedBox:Landroid/graphics/RectF;

    .line 102
    new-array v1, v8, [Landroid/graphics/RectF;

    iput-object v1, v0, Lorg/openaok/game/ThorDeck;->tabs:[Landroid/graphics/RectF;

    .line 103
    new-instance v1, Landroid/graphics/RectF;

    const v6, 0x441a8000    # 618.0f

    const/high16 v11, 0x44850000    # 1064.0f

    invoke-direct {v1, v4, v6, v13, v11}, Landroid/graphics/RectF;-><init>(FFFF)V

    iput-object v1, v0, Lorg/openaok/game/ThorDeck;->grid:Landroid/graphics/RectF;

    .line 104
    new-array v1, v3, [Landroid/graphics/RectF;

    iput-object v1, v0, Lorg/openaok/game/ThorDeck;->tiles:[Landroid/graphics/RectF;

    .line 105
    new-array v1, v3, [Landroid/graphics/RectF;

    iput-object v1, v0, Lorg/openaok/game/ThorDeck;->queueRects:[Landroid/graphics/RectF;

    .line 106
    new-array v1, v3, [I

    iput-object v1, v0, Lorg/openaok/game/ThorDeck;->queueSlot:[I

    .line 108
    new-instance v1, Landroid/graphics/Paint;

    invoke-direct {v1, v7}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v1, v0, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    .line 109
    new-instance v1, Landroid/graphics/Paint;

    invoke-direct {v1, v7}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v1, v0, Lorg/openaok/game/ThorDeck;->stroke:Landroid/graphics/Paint;

    .line 110
    new-instance v6, Landroid/text/TextPaint;

    invoke-direct {v6, v7}, Landroid/text/TextPaint;-><init>(I)V

    iput-object v6, v0, Lorg/openaok/game/ThorDeck;->text:Landroid/text/TextPaint;

    .line 111
    new-instance v11, Landroid/graphics/Paint;

    invoke-direct {v11, v2}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v11, v0, Lorg/openaok/game/ThorDeck;->bmp:Landroid/graphics/Paint;

    .line 112
    new-instance v11, Landroid/graphics/Path;

    invoke-direct {v11}, Landroid/graphics/Path;-><init>()V

    iput-object v11, v0, Lorg/openaok/game/ThorDeck;->path:Landroid/graphics/Path;

    .line 114
    new-instance v11, Lorg/openaok/game/ThorDeck$1;

    invoke-direct {v11, v0}, Lorg/openaok/game/ThorDeck$1;-><init>(Lorg/openaok/game/ThorDeck;)V

    iput-object v11, v0, Lorg/openaok/game/ThorDeck;->poll:Ljava/lang/Runnable;

    const v11, -0xf1f2f5

    .line 137
    invoke-virtual {v0, v11}, Lorg/openaok/game/ThorDeck;->setBackgroundColor(I)V

    .line 138
    sget-object v11, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v11}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 139
    const-string v1, "serif"

    invoke-static {v1, v5}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v1

    invoke-virtual {v6, v1}, Landroid/text/TextPaint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    move v1, v5

    .line 141
    :goto_0
    iget-object v6, v0, Lorg/openaok/game/ThorDeck;->buttons:[Landroid/graphics/RectF;

    array-length v11, v6

    if-ge v1, v11, :cond_0

    int-to-float v11, v1

    const v14, 0x434b5555

    mul-float/2addr v11, v14

    add-float/2addr v11, v4

    .line 143
    new-instance v14, Landroid/graphics/RectF;

    const v15, 0x433f5555

    add-float/2addr v15, v11

    move/from16 p1, v2

    const/high16 v2, 0x43f30000    # 486.0f

    const/high16 v4, 0x43cf0000    # 414.0f

    invoke-direct {v14, v11, v4, v15, v2}, Landroid/graphics/RectF;-><init>(FFFF)V

    aput-object v14, v6, v1

    add-int/lit8 v1, v1, 0x1

    move/from16 v2, p1

    const/high16 v4, 0x41800000    # 16.0f

    goto :goto_0

    :cond_0
    move/from16 p1, v2

    move v1, v5

    :goto_1
    if-ge v1, v9, :cond_1

    .line 146
    iget-object v2, v0, Lorg/openaok/game/ThorDeck;->mapButtons:[Landroid/graphics/RectF;

    new-instance v4, Landroid/graphics/RectF;

    mul-int/lit8 v6, v1, 0x4e

    add-int/lit8 v11, v6, 0x60

    int-to-float v11, v11

    add-int/lit16 v6, v6, 0xaa

    int-to-float v6, v6

    const/high16 v14, 0x44220000    # 648.0f

    const/high16 v15, 0x44330000    # 716.0f

    invoke-direct {v4, v14, v11, v15, v6}, Landroid/graphics/RectF;-><init>(FFFF)V

    aput-object v4, v2, v1

    .line 147
    iget-object v2, v0, Lorg/openaok/game/ThorDeck;->groups:[Landroid/graphics/RectF;

    new-instance v4, Landroid/graphics/RectF;

    mul-int/lit16 v6, v1, 0x9e

    add-int/lit8 v11, v6, 0x10

    int-to-float v11, v11

    add-int/lit16 v6, v6, 0xa4

    int-to-float v6, v6

    invoke-direct {v4, v11, v10, v6, v12}, Landroid/graphics/RectF;-><init>(FFFF)V

    aput-object v4, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    .line 149
    :cond_1
    iget-object v1, v0, Lorg/openaok/game/ThorDeck;->small:[Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    const/high16 v4, 0x44240000    # 656.0f

    const v6, 0x444e8000    # 826.0f

    invoke-direct {v2, v4, v10, v6, v12}, Landroid/graphics/RectF;-><init>(FFFF)V

    aput-object v2, v1, v5

    .line 150
    iget-object v1, v0, Lorg/openaok/game/ThorDeck;->small:[Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    const/high16 v4, 0x44510000    # 836.0f

    const/high16 v6, 0x446c0000    # 944.0f

    invoke-direct {v2, v4, v10, v6, v12}, Landroid/graphics/RectF;-><init>(FFFF)V

    aput-object v2, v1, v7

    .line 151
    iget-object v1, v0, Lorg/openaok/game/ThorDeck;->small:[Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    const v4, 0x446e8000    # 954.0f

    const/high16 v6, 0x447e0000    # 1016.0f

    invoke-direct {v2, v4, v10, v6, v12}, Landroid/graphics/RectF;-><init>(FFFF)V

    aput-object v2, v1, p1

    .line 152
    iget-object v1, v0, Lorg/openaok/game/ThorDeck;->small:[Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    const v4, 0x44908000    # 1156.0f

    invoke-direct {v2, v4, v10, v13, v12}, Landroid/graphics/RectF;-><init>(FFFF)V

    aput-object v2, v1, v8

    move v1, v5

    :goto_2
    if-ge v1, v8, :cond_2

    .line 153
    iget-object v2, v0, Lorg/openaok/game/ThorDeck;->tabs:[Landroid/graphics/RectF;

    new-instance v4, Landroid/graphics/RectF;

    mul-int/lit16 v6, v1, 0x196

    add-int/lit8 v7, v6, 0x10

    int-to-float v7, v7

    add-int/lit16 v6, v6, 0x19c

    int-to-float v6, v6

    const v9, 0x44188000    # 610.0f

    const/high16 v10, 0x440d0000    # 564.0f

    invoke-direct {v4, v7, v10, v6, v9}, Landroid/graphics/RectF;-><init>(FFFF)V

    aput-object v4, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    .line 154
    :cond_2
    iget-object v1, v0, Lorg/openaok/game/ThorDeck;->grid:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->width()F

    move-result v1

    const/high16 v2, 0x42200000    # 40.0f

    sub-float/2addr v1, v2

    const/high16 v2, 0x40a00000    # 5.0f

    div-float/2addr v1, v2

    iget-object v2, v0, Lorg/openaok/game/ThorDeck;->grid:Landroid/graphics/RectF;

    invoke-virtual {v2}, Landroid/graphics/RectF;->height()F

    move-result v2

    const/high16 v4, 0x41a00000    # 20.0f

    sub-float/2addr v2, v4

    const/high16 v4, 0x40400000    # 3.0f

    div-float/2addr v2, v4

    move v4, v5

    :goto_3
    if-ge v4, v3, :cond_3

    .line 156
    iget-object v6, v0, Lorg/openaok/game/ThorDeck;->grid:Landroid/graphics/RectF;

    iget v6, v6, Landroid/graphics/RectF;->left:F

    rem-int/lit8 v7, v4, 0x5

    int-to-float v7, v7

    const/high16 v8, 0x41200000    # 10.0f

    add-float v9, v1, v8

    mul-float/2addr v7, v9

    add-float/2addr v6, v7

    iget-object v7, v0, Lorg/openaok/game/ThorDeck;->grid:Landroid/graphics/RectF;

    iget v7, v7, Landroid/graphics/RectF;->top:F

    div-int/lit8 v9, v4, 0x5

    int-to-float v9, v9

    add-float/2addr v8, v2

    mul-float/2addr v9, v8

    add-float/2addr v7, v9

    .line 157
    iget-object v8, v0, Lorg/openaok/game/ThorDeck;->tiles:[Landroid/graphics/RectF;

    new-instance v9, Landroid/graphics/RectF;

    add-float v10, v6, v1

    add-float v11, v7, v2

    invoke-direct {v9, v6, v7, v10, v11}, Landroid/graphics/RectF;-><init>(FFFF)V

    aput-object v9, v8, v4

    add-int/lit8 v4, v4, 0x1

    goto :goto_3

    :cond_3
    :goto_4
    if-ge v5, v3, :cond_4

    .line 159
    iget-object v1, v0, Lorg/openaok/game/ThorDeck;->queueRects:[Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    aput-object v2, v1, v5

    add-int/lit8 v5, v5, 0x1

    goto :goto_4

    :cond_4
    return-void
.end method

.method private buttonLabel(I)Ljava/lang/String;
    .locals 1

    if-eqz p1, :cond_5

    const/4 v0, 0x1

    if-eq p1, v0, :cond_4

    const/4 v0, 0x2

    if-eq p1, v0, :cond_3

    const/4 v0, 0x3

    if-eq p1, v0, :cond_1

    const/4 v0, 0x4

    if-eq p1, v0, :cond_0

    .line 513
    invoke-virtual {p0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object p0

    sget p1, Lorg/openaok/game/R$string;->deck_menu:I

    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 512
    :cond_0
    invoke-virtual {p0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object p0

    sget p1, Lorg/openaok/game/R$string;->deck_delete:I

    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 511
    :cond_1
    iget-object p1, p0, Lorg/openaok/game/ThorDeck;->nextAge:Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-virtual {p0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object p0

    sget p1, Lorg/openaok/game/R$string;->deck_age_up:I

    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_2
    iget-object p0, p0, Lorg/openaok/game/ThorDeck;->nextAge:Ljava/lang/String;

    return-object p0

    .line 510
    :cond_3
    invoke-virtual {p0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object p0

    sget p1, Lorg/openaok/game/R$string;->deck_town_center:I

    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 509
    :cond_4
    invoke-virtual {p0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object p0

    sget p1, Lorg/openaok/game/R$string;->deck_idle_military:I

    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 508
    :cond_5
    invoke-virtual {p0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object p0

    sget p1, Lorg/openaok/game/R$string;->deck_idle_villager:I

    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private commandAt(I)I
    .locals 4

    const/16 v0, 0x12

    .line 266
    invoke-direct {p0, v0}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_1

    .line 268
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->snap:[I

    invoke-direct {p0, v1}, Lorg/openaok/game/ThorDeck;->commandBase(I)I

    move-result v3

    aget v2, v2, v3

    if-ne v2, p1, :cond_0

    return v1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    const/4 p0, -0x1

    return p0
.end method

.method private commandBase(I)I
    .locals 0

    mul-int/lit8 p1, p1, 0x8

    add-int/lit8 p1, p1, 0x27

    return p1
.end method

.method private drawButtons(Landroid/graphics/Canvas;)V
    .locals 19

    move-object/from16 v0, p0

    const/16 v1, 0x9

    .line 518
    invoke-direct {v0, v1}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v1

    and-int/lit8 v1, v1, 0x2

    const/4 v10, 0x1

    if-eqz v1, :cond_0

    move v11, v10

    goto :goto_0

    :cond_0
    const/4 v11, 0x0

    :goto_0
    const/4 v12, 0x0

    .line 519
    :goto_1
    iget-object v1, v0, Lorg/openaok/game/ThorDeck;->buttons:[Landroid/graphics/RectF;

    array-length v2, v1

    if-ge v12, v2, :cond_c

    .line 520
    aget-object v13, v1, v12

    .line 521
    iget v1, v0, Lorg/openaok/game/ThorDeck;->pressedButton:I

    if-ne v1, v12, :cond_1

    move v1, v10

    goto :goto_2

    :cond_1
    const/4 v1, 0x0

    :goto_2
    const/4 v2, 0x4

    if-ne v12, v2, :cond_2

    .line 522
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v3

    iget-wide v5, v0, Lorg/openaok/game/ThorDeck;->deleteArmedUntil:J

    cmp-long v3, v3, v5

    if-gez v3, :cond_2

    move v3, v10

    goto :goto_3

    :cond_2
    const/4 v3, 0x0

    :goto_3
    if-eqz v3, :cond_3

    const v1, -0x85dbe8

    :goto_4
    move-object/from16 v4, p1

    goto :goto_5

    :cond_3
    if-eqz v1, :cond_4

    const v1, -0xd9dde5

    goto :goto_4

    :cond_4
    const v1, -0xe5e7ec

    goto :goto_4

    .line 523
    :goto_5
    invoke-direct {v0, v4, v13, v1}, Lorg/openaok/game/ThorDeck;->panel(Landroid/graphics/Canvas;Landroid/graphics/RectF;I)V

    const v1, -0x12192a

    const/4 v5, 0x3

    if-ne v12, v5, :cond_6

    if-eqz v11, :cond_5

    const v6, -0x9040b6

    goto :goto_6

    :cond_5
    const v6, -0x174fb6

    goto :goto_6

    :cond_6
    move v6, v1

    :goto_6
    if-ne v12, v2, :cond_8

    if-eqz v3, :cond_7

    goto :goto_7

    :cond_7
    const v1, -0x26a8c1

    :goto_7
    move v14, v1

    goto :goto_8

    :cond_8
    move v14, v6

    .line 526
    :goto_8
    invoke-direct {v0, v12}, Lorg/openaok/game/ThorDeck;->buttonLabel(I)Ljava/lang/String;

    move-result-object v15

    const/high16 v16, 0x42600000    # 56.0f

    const/high16 v1, 0x41d00000    # 26.0f

    if-eqz v3, :cond_9

    .line 528
    invoke-virtual {v0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object v2

    sget v3, Lorg/openaok/game/R$string;->deck_delete_confirm:I

    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v13}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    iget v5, v13, Landroid/graphics/RectF;->top:F

    add-float/2addr v5, v1

    sget-object v7, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/4 v8, 0x1

    move v4, v5

    const/high16 v5, 0x41500000    # 13.0f

    const v6, -0x12192a

    move-object/from16 v1, p1

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    .line 530
    invoke-virtual {v13}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    iget v0, v13, Landroid/graphics/RectF;->top:F

    add-float v4, v0, v16

    sget-object v7, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/high16 v5, 0x41b80000    # 23.0f

    move-object/from16 v0, p0

    move v6, v14

    move-object v2, v15

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    goto/16 :goto_9

    :cond_9
    move-object/from16 v18, v15

    move v15, v14

    move-object/from16 v14, v18

    const/high16 v17, 0x41400000    # 12.0f

    const/high16 v0, 0x41b80000    # 23.0f

    if-gt v12, v10, :cond_a

    .line 532
    invoke-virtual/range {p0 .. p0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object v2

    sget v3, Lorg/openaok/game/R$string;->deck_idle_caption:I

    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v13}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    iget v4, v13, Landroid/graphics/RectF;->top:F

    add-float/2addr v4, v1

    sget-object v7, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/4 v8, 0x0

    const/high16 v5, 0x41700000    # 15.0f

    const v6, -0x737c8e

    move-object/from16 v1, p1

    move v9, v0

    move-object/from16 v0, p0

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    .line 534
    invoke-direct {v0, v9}, Lorg/openaok/game/ThorDeck;->measure(F)Landroid/text/TextPaint;

    move-result-object v1

    invoke-virtual {v13}, Landroid/graphics/RectF;->width()F

    move-result v2

    sub-float v2, v2, v17

    sget-object v3, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-static {v14, v1, v2, v3}, Landroid/text/TextUtils;->ellipsize(Ljava/lang/CharSequence;Landroid/text/TextPaint;FLandroid/text/TextUtils$TruncateAt;)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    .line 535
    invoke-virtual {v13}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    iget v1, v13, Landroid/graphics/RectF;->top:F

    add-float v4, v1, v16

    sget-object v7, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/4 v8, 0x1

    const/high16 v5, 0x41b80000    # 23.0f

    move-object/from16 v1, p1

    move v6, v15

    .line 534
    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    goto/16 :goto_9

    :cond_a
    move v9, v0

    move-object/from16 v0, p0

    const/high16 v2, 0x41200000    # 10.0f

    if-ne v12, v5, :cond_b

    .line 537
    invoke-virtual {v0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object v3

    sget v4, Lorg/openaok/game/R$string;->deck_age_up:I

    invoke-virtual {v3, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v3

    const/high16 v4, 0x41700000    # 15.0f

    invoke-direct {v0, v4}, Lorg/openaok/game/ThorDeck;->measure(F)Landroid/text/TextPaint;

    move-result-object v4

    .line 538
    invoke-virtual {v13}, Landroid/graphics/RectF;->width()F

    move-result v5

    sub-float/2addr v5, v2

    sget-object v2, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    .line 537
    invoke-static {v3, v4, v5, v2}, Landroid/text/TextUtils;->ellipsize(Ljava/lang/CharSequence;Landroid/text/TextPaint;FLandroid/text/TextUtils$TruncateAt;)Ljava/lang/CharSequence;

    move-result-object v2

    .line 538
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v13}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    iget v4, v13, Landroid/graphics/RectF;->top:F

    add-float/2addr v4, v1

    sget-object v7, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/4 v8, 0x0

    const/high16 v5, 0x41700000    # 15.0f

    const v6, -0x737c8e

    move-object/from16 v1, p1

    .line 537
    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    .line 540
    invoke-direct {v0, v9}, Lorg/openaok/game/ThorDeck;->measure(F)Landroid/text/TextPaint;

    move-result-object v1

    invoke-virtual {v13}, Landroid/graphics/RectF;->width()F

    move-result v2

    sub-float v2, v2, v17

    sget-object v3, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-static {v14, v1, v2, v3}, Landroid/text/TextUtils;->ellipsize(Ljava/lang/CharSequence;Landroid/text/TextPaint;FLandroid/text/TextUtils$TruncateAt;)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    .line 541
    invoke-virtual {v13}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    iget v1, v13, Landroid/graphics/RectF;->top:F

    add-float v4, v1, v16

    sget-object v7, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/4 v8, 0x1

    const/high16 v5, 0x41b80000    # 23.0f

    move-object/from16 v1, p1

    move v6, v15

    .line 540
    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    goto :goto_9

    :cond_b
    move v6, v15

    .line 543
    invoke-direct {v0, v1}, Lorg/openaok/game/ThorDeck;->measure(F)Landroid/text/TextPaint;

    move-result-object v1

    invoke-virtual {v13}, Landroid/graphics/RectF;->width()F

    move-result v3

    const/high16 v4, 0x41800000    # 16.0f

    sub-float/2addr v3, v4

    sget-object v4, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-static {v14, v1, v3, v4}, Landroid/text/TextUtils;->ellipsize(Ljava/lang/CharSequence;Landroid/text/TextPaint;FLandroid/text/TextUtils$TruncateAt;)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    .line 544
    invoke-virtual {v13}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    invoke-virtual {v13}, Landroid/graphics/RectF;->centerY()F

    move-result v4

    add-float/2addr v4, v2

    sget-object v7, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/4 v8, 0x1

    const/high16 v5, 0x41d00000    # 26.0f

    move-object v2, v1

    move-object/from16 v1, p1

    .line 543
    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    :goto_9
    add-int/lit8 v12, v12, 0x1

    move-object/from16 v0, p0

    goto/16 :goto_1

    :cond_c
    return-void
.end method

.method private drawGame(Landroid/graphics/Canvas;)V
    .locals 12

    const/4 v0, 0x0

    :goto_0
    const/16 v1, 0xf

    if-ge v0, v1, :cond_2

    .line 619
    iget-object v1, p0, Lorg/openaok/game/ThorDeck;->tiles:[Landroid/graphics/RectF;

    aget-object v1, v1, v0

    .line 620
    sget-object v2, Lorg/openaok/game/ThorDeck;->GAME_NAMES:[I

    array-length v3, v2

    if-lt v0, v3, :cond_0

    .line 621
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    const/high16 v3, 0x60000000

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 622
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    const/high16 v3, 0x40c00000    # 6.0f

    invoke-virtual {p1, v1, v3, v3, v2}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    move-object v3, p0

    move-object v4, p1

    goto :goto_2

    .line 625
    :cond_0
    iget v3, p0, Lorg/openaok/game/ThorDeck;->pressedTile:I

    if-ne v3, v0, :cond_1

    const v3, -0xd9dde5

    goto :goto_1

    :cond_1
    const v3, -0xe5e7ec

    :goto_1
    invoke-direct {p0, p1, v1, v3}, Lorg/openaok/game/ThorDeck;->panel(Landroid/graphics/Canvas;Landroid/graphics/RectF;I)V

    .line 626
    invoke-virtual {p0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object v3

    aget v2, v2, v0

    invoke-virtual {v3, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/high16 v3, 0x41e00000    # 28.0f

    invoke-direct {p0, v3}, Lorg/openaok/game/ThorDeck;->measure(F)Landroid/text/TextPaint;

    move-result-object v3

    invoke-virtual {v1}, Landroid/graphics/RectF;->width()F

    move-result v4

    const/high16 v5, 0x41800000    # 16.0f

    sub-float/2addr v4, v5

    sget-object v5, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-static {v2, v3, v4, v5}, Landroid/text/TextUtils;->ellipsize(Ljava/lang/CharSequence;Landroid/text/TextPaint;FLandroid/text/TextUtils$TruncateAt;)Ljava/lang/CharSequence;

    move-result-object v2

    .line 627
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    move-result v6

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    move-result v1

    const/high16 v2, 0x41200000    # 10.0f

    add-float v7, v1, v2

    sget-object v10, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/4 v11, 0x1

    const/high16 v8, 0x41e00000    # 28.0f

    const v9, -0x12192a

    move-object v3, p0

    move-object v4, p1

    .line 626
    invoke-direct/range {v3 .. v11}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    :goto_2
    add-int/lit8 v0, v0, 0x1

    move-object p0, v3

    move-object p1, v4

    goto :goto_0

    :cond_2
    return-void
.end method

.method private drawGoTo(Landroid/graphics/Canvas;)V
    .locals 13

    const/4 v2, 0x0

    move v9, v2

    :goto_0
    const/16 v2, 0xf

    if-ge v9, v2, :cond_4

    .line 592
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->tiles:[Landroid/graphics/RectF;

    aget-object v10, v2, v9

    .line 593
    iget v2, p0, Lorg/openaok/game/ThorDeck;->goToCount:I

    if-lt v9, v2, :cond_0

    .line 594
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    const/high16 v3, 0x60000000

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 595
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    const/high16 v3, 0x40c00000    # 6.0f

    invoke-virtual {p1, v10, v3, v3, v2}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    goto/16 :goto_2

    .line 598
    :cond_0
    invoke-direct {p0, v9}, Lorg/openaok/game/ThorDeck;->goToBase(I)I

    move-result v2

    .line 599
    iget v3, p0, Lorg/openaok/game/ThorDeck;->pressedTile:I

    if-ne v3, v9, :cond_1

    const v3, -0xd9dde5

    goto :goto_1

    :cond_1
    const v3, -0xe5e7ec

    :goto_1
    invoke-direct {p0, p1, v10, v3}, Lorg/openaok/game/ThorDeck;->panel(Landroid/graphics/Canvas;Landroid/graphics/RectF;I)V

    .line 600
    iget-object v3, p0, Lorg/openaok/game/ThorDeck;->snap:[I

    add-int/lit8 v4, v2, 0x2

    aget v4, v3, v4

    add-int/lit8 v5, v2, 0x3

    aget v3, v3, v5

    invoke-direct {p0, v4, v3}, Lorg/openaok/game/ThorDeck;->icon(II)Landroid/graphics/Bitmap;

    move-result-object v3

    .line 601
    invoke-virtual {v10}, Landroid/graphics/RectF;->height()F

    move-result v4

    const/high16 v5, 0x42400000    # 48.0f

    sub-float/2addr v4, v5

    invoke-virtual {v10}, Landroid/graphics/RectF;->width()F

    move-result v5

    const/high16 v6, 0x42200000    # 40.0f

    sub-float/2addr v5, v6

    invoke-static {v4, v5}, Ljava/lang/Math;->min(FF)F

    move-result v4

    .line 602
    new-instance v5, Landroid/graphics/RectF;

    invoke-virtual {v10}, Landroid/graphics/RectF;->centerX()F

    move-result v6

    const/high16 v7, 0x40000000    # 2.0f

    div-float v7, v4, v7

    sub-float/2addr v6, v7

    iget v8, v10, Landroid/graphics/RectF;->top:F

    const/high16 v11, 0x41200000    # 10.0f

    add-float/2addr v8, v11

    invoke-virtual {v10}, Landroid/graphics/RectF;->centerX()F

    move-result v12

    add-float/2addr v12, v7

    iget v7, v10, Landroid/graphics/RectF;->top:F

    add-float/2addr v7, v11

    add-float/2addr v7, v4

    invoke-direct {v5, v6, v8, v12, v7}, Landroid/graphics/RectF;-><init>(FFFF)V

    if-eqz v3, :cond_2

    const/4 v4, 0x0

    .line 603
    iget-object v6, p0, Lorg/openaok/game/ThorDeck;->bmp:Landroid/graphics/Paint;

    invoke-virtual {p1, v3, v4, v5, v6}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 604
    :cond_2
    iget-object v3, p0, Lorg/openaok/game/ThorDeck;->snap:[I

    add-int/lit8 v2, v2, 0x1

    aget v3, v3, v2

    const/4 v4, 0x1

    if-le v3, v4, :cond_3

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "\u00d7"

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v4, p0, Lorg/openaok/game/ThorDeck;->snap:[I

    aget v2, v4, v2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    iget v3, v5, Landroid/graphics/RectF;->right:F

    const/high16 v4, 0x41000000    # 8.0f

    add-float/2addr v3, v4

    iget v4, v5, Landroid/graphics/RectF;->top:F

    const/high16 v5, 0x41f00000    # 30.0f

    add-float/2addr v4, v5

    sget-object v7, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    const/4 v8, 0x1

    const/high16 v5, 0x41d00000    # 26.0f

    const v6, -0x174fb6

    move-object v0, p0

    move-object v1, p1

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    .line 605
    :cond_3
    iget-object v1, p0, Lorg/openaok/game/ThorDeck;->goToName:[Ljava/lang/String;

    aget-object v1, v1, v9

    const/high16 v2, 0x41a80000    # 21.0f

    invoke-direct {p0, v2}, Lorg/openaok/game/ThorDeck;->measure(F)Landroid/text/TextPaint;

    move-result-object v2

    invoke-virtual {v10}, Landroid/graphics/RectF;->width()F

    move-result v3

    const/high16 v4, 0x41800000    # 16.0f

    sub-float/2addr v3, v4

    sget-object v4, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-static {v1, v2, v3, v4}, Landroid/text/TextUtils;->ellipsize(Ljava/lang/CharSequence;Landroid/text/TextPaint;FLandroid/text/TextUtils$TruncateAt;)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    .line 606
    invoke-virtual {v10}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    iget v1, v10, Landroid/graphics/RectF;->bottom:F

    const/high16 v4, 0x41400000    # 12.0f

    sub-float v4, v1, v4

    sget-object v7, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/4 v8, 0x0

    const/high16 v5, 0x41a80000    # 21.0f

    const v6, -0x12192a

    move-object v0, p0

    move-object v1, p1

    .line 605
    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    :goto_2
    add-int/lit8 v9, v9, 0x1

    goto/16 :goto_0

    .line 608
    :cond_4
    iget v1, p0, Lorg/openaok/game/ThorDeck;->goToCount:I

    if-nez v1, :cond_5

    .line 609
    invoke-virtual {p0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object v1

    sget v2, Lorg/openaok/game/R$string;->deck_goto_empty:I

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    iget-object v1, p0, Lorg/openaok/game/ThorDeck;->grid:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    iget-object v1, p0, Lorg/openaok/game/ThorDeck;->grid:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    move-result v4

    sget-object v7, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/4 v8, 0x0

    const/high16 v5, 0x41e00000    # 28.0f

    const v6, -0x737c8e

    move-object v0, p0

    move-object v1, p1

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    :cond_5
    return-void
.end method

.method private drawGrid(Landroid/graphics/Canvas;)V
    .locals 21

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const/16 v2, 0x9

    .line 643
    invoke-direct {v0, v2}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v2

    const/4 v9, 0x1

    and-int/2addr v2, v9

    if-eqz v2, :cond_0

    move v11, v9

    goto :goto_0

    :cond_0
    const/4 v11, 0x0

    :goto_0
    const/4 v2, 0x0

    :goto_1
    const/16 v3, 0xf

    const/high16 v4, 0x42200000    # 40.0f

    const/high16 v12, 0x41400000    # 12.0f

    if-ge v2, v3, :cond_d

    .line 645
    iget-object v3, v0, Lorg/openaok/game/ThorDeck;->tiles:[Landroid/graphics/RectF;

    aget-object v13, v3, v2

    add-int/lit8 v14, v2, 0x1

    .line 646
    invoke-direct {v0, v14}, Lorg/openaok/game/ThorDeck;->commandAt(I)I

    move-result v3

    const/high16 v5, 0x40c00000    # 6.0f

    if-gez v3, :cond_2

    .line 648
    iget-object v2, v0, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    iget-object v3, v0, Lorg/openaok/game/ThorDeck;->art:Landroid/graphics/Bitmap;

    if-eqz v3, :cond_1

    const/high16 v3, 0x60000000

    goto :goto_2

    :cond_1
    const v3, -0xeaecf1

    :goto_2
    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 649
    iget-object v2, v0, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    invoke-virtual {v1, v13, v5, v5, v2}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    :goto_3
    move-object v6, v0

    goto/16 :goto_c

    .line 652
    :cond_2
    invoke-direct {v0, v3}, Lorg/openaok/game/ThorDeck;->commandBase(I)I

    move-result v6

    .line 653
    iget-object v7, v0, Lorg/openaok/game/ThorDeck;->snap:[I

    add-int/lit8 v8, v6, 0x1

    aget v8, v7, v8

    add-int/lit8 v15, v6, 0x4

    .line 654
    aget v15, v7, v15

    if-ne v15, v9, :cond_3

    move v15, v9

    goto :goto_4

    :cond_3
    const/4 v15, 0x0

    :goto_4
    add-int/lit8 v16, v6, 0x5

    aget v7, v7, v16

    if-ne v7, v9, :cond_4

    move/from16 v16, v9

    goto :goto_5

    :cond_4
    const/16 v16, 0x0

    .line 655
    :goto_5
    iget v7, v0, Lorg/openaok/game/ThorDeck;->pressedTile:I

    if-ne v7, v2, :cond_5

    const v2, -0xd9dde5

    goto :goto_6

    :cond_5
    const v2, -0xe5e7ec

    :goto_6
    invoke-direct {v0, v1, v13, v2}, Lorg/openaok/game/ThorDeck;->panel(Landroid/graphics/Canvas;Landroid/graphics/RectF;I)V

    .line 656
    iget-object v2, v0, Lorg/openaok/game/ThorDeck;->labels:[Ljava/lang/String;

    array-length v7, v2

    if-ge v3, v7, :cond_6

    aget-object v2, v2, v3

    goto :goto_7

    :cond_6
    const-string v2, ""

    :goto_7
    const/16 v3, 0x1b

    if-ne v8, v3, :cond_7

    .line 658
    invoke-virtual {v13}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    invoke-virtual {v13}, Landroid/graphics/RectF;->centerY()F

    move-result v4

    add-float/2addr v4, v12

    sget-object v7, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/4 v8, 0x1

    const/high16 v5, 0x42000000    # 32.0f

    const v6, -0x737c8e

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    goto :goto_3

    .line 661
    :cond_7
    iget-object v3, v0, Lorg/openaok/game/ThorDeck;->snap:[I

    add-int/lit8 v7, v6, 0x2

    aget v7, v3, v7

    add-int/lit8 v8, v6, 0x3

    aget v3, v3, v8

    invoke-direct {v0, v7, v3}, Lorg/openaok/game/ThorDeck;->icon(II)Landroid/graphics/Bitmap;

    move-result-object v3

    .line 662
    invoke-virtual {v13}, Landroid/graphics/RectF;->height()F

    move-result v7

    const/high16 v8, 0x42400000    # 48.0f

    sub-float/2addr v7, v8

    invoke-virtual {v13}, Landroid/graphics/RectF;->width()F

    move-result v8

    sub-float/2addr v8, v4

    invoke-static {v7, v8}, Ljava/lang/Math;->min(FF)F

    move-result v4

    .line 663
    new-instance v7, Landroid/graphics/RectF;

    invoke-virtual {v13}, Landroid/graphics/RectF;->centerX()F

    move-result v8

    const/high16 v17, 0x40000000    # 2.0f

    div-float v17, v4, v17

    sub-float v8, v8, v17

    move/from16 v18, v5

    iget v5, v13, Landroid/graphics/RectF;->top:F

    const/high16 v19, 0x41200000    # 10.0f

    add-float v5, v5, v19

    invoke-virtual {v13}, Landroid/graphics/RectF;->centerX()F

    move-result v20

    add-float v9, v20, v17

    iget v10, v13, Landroid/graphics/RectF;->top:F

    add-float v10, v10, v19

    add-float/2addr v10, v4

    invoke-direct {v7, v8, v5, v9, v10}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 664
    iget-object v4, v0, Lorg/openaok/game/ThorDeck;->bmp:Landroid/graphics/Paint;

    const/16 v5, 0xff

    if-eqz v15, :cond_8

    move v8, v5

    goto :goto_8

    :cond_8
    const/16 v8, 0x5a

    :goto_8
    invoke-virtual {v4, v8}, Landroid/graphics/Paint;->setAlpha(I)V

    if-eqz v3, :cond_9

    const/4 v4, 0x0

    .line 665
    iget-object v8, v0, Lorg/openaok/game/ThorDeck;->bmp:Landroid/graphics/Paint;

    invoke-virtual {v1, v3, v4, v7, v8}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 666
    :cond_9
    iget-object v3, v0, Lorg/openaok/game/ThorDeck;->bmp:Landroid/graphics/Paint;

    invoke-virtual {v3, v5}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 667
    iget-object v3, v0, Lorg/openaok/game/ThorDeck;->snap:[I

    add-int/lit8 v6, v6, 0x6

    aget v3, v3, v6

    if-ltz v3, :cond_a

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    iget v4, v7, Landroid/graphics/RectF;->left:F

    add-float v4, v4, v18

    iget v5, v7, Landroid/graphics/RectF;->top:F

    const/high16 v6, 0x41e00000    # 28.0f

    add-float/2addr v5, v6

    sget-object v7, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    const/4 v8, 0x1

    move-object v6, v2

    move-object v2, v3

    move v3, v4

    move v4, v5

    const/high16 v5, 0x41d00000    # 26.0f

    move-object v9, v6

    const v6, -0x174fb6

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    goto :goto_9

    :cond_a
    move-object v9, v2

    :goto_9
    if-nez v15, :cond_b

    const v1, -0x737c8e

    :goto_a
    move v6, v1

    goto :goto_b

    :cond_b
    if-eqz v16, :cond_c

    const v1, -0x12192a

    goto :goto_a

    :cond_c
    const v1, -0x26a8c1

    goto :goto_a

    :goto_b
    const/high16 v1, 0x41b00000    # 22.0f

    .line 669
    invoke-direct {v0, v1}, Lorg/openaok/game/ThorDeck;->measure(F)Landroid/text/TextPaint;

    move-result-object v1

    invoke-virtual {v13}, Landroid/graphics/RectF;->width()F

    move-result v2

    const/high16 v3, 0x41800000    # 16.0f

    sub-float/2addr v2, v3

    sget-object v3, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-static {v9, v1, v2, v3}, Landroid/text/TextUtils;->ellipsize(Ljava/lang/CharSequence;Landroid/text/TextPaint;FLandroid/text/TextUtils$TruncateAt;)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    .line 670
    invoke-virtual {v13}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    iget v1, v13, Landroid/graphics/RectF;->bottom:F

    sub-float v4, v1, v12

    sget-object v7, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/4 v8, 0x0

    const/high16 v5, 0x41a80000    # 21.0f

    move-object/from16 v1, p1

    .line 669
    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    goto/16 :goto_3

    :goto_c
    move-object/from16 v1, p1

    move-object v0, v6

    move v2, v14

    const/4 v9, 0x1

    goto/16 :goto_1

    :cond_d
    move-object v6, v0

    if-eqz v11, :cond_e

    .line 673
    iget-object v0, v6, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    const/high16 v1, -0x30000000

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 674
    iget-object v0, v6, Lorg/openaok/game/ThorDeck;->grid:Landroid/graphics/RectF;

    iget v1, v0, Landroid/graphics/RectF;->left:F

    iget-object v0, v6, Lorg/openaok/game/ThorDeck;->grid:Landroid/graphics/RectF;

    iget v0, v0, Landroid/graphics/RectF;->bottom:F

    sub-float v2, v0, v4

    iget-object v0, v6, Lorg/openaok/game/ThorDeck;->grid:Landroid/graphics/RectF;

    iget v3, v0, Landroid/graphics/RectF;->right:F

    iget-object v0, v6, Lorg/openaok/game/ThorDeck;->grid:Landroid/graphics/RectF;

    iget v4, v0, Landroid/graphics/RectF;->bottom:F

    iget-object v5, v6, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    move-object/from16 v0, p1

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 675
    invoke-virtual {v6}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object v0

    sget v1, Lorg/openaok/game/R$string;->deck_placing:I

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    iget-object v0, v6, Lorg/openaok/game/ThorDeck;->grid:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    iget-object v0, v6, Lorg/openaok/game/ThorDeck;->grid:Landroid/graphics/RectF;

    iget v0, v0, Landroid/graphics/RectF;->bottom:F

    sub-float v4, v0, v12

    sget-object v7, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/4 v8, 0x1

    const/high16 v5, 0x41c00000    # 24.0f

    const v6, -0x174fb6

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    :cond_e
    return-void
.end method

.method private drawGroups(Landroid/graphics/Canvas;)V
    .locals 20

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const/4 v9, 0x0

    move v10, v9

    :goto_0
    const v11, -0x174fb6

    const/high16 v12, 0x41400000    # 12.0f

    .line 552
    const-string v13, "\u00d7"

    const v14, -0xd9dde5

    const v15, -0xe5e7ec

    const/high16 v16, 0x42200000    # 40.0f

    const/4 v2, 0x4

    if-ge v10, v2, :cond_4

    .line 553
    iget-object v2, v0, Lorg/openaok/game/ThorDeck;->groups:[Landroid/graphics/RectF;

    aget-object v2, v2, v10

    add-int/lit8 v3, v10, 0x21

    .line 554
    invoke-direct {v0, v3}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v3

    .line 555
    iget v4, v0, Lorg/openaok/game/ThorDeck;->pressedGroup:I

    if-ne v4, v10, :cond_0

    goto :goto_1

    :cond_0
    move v14, v15

    :goto_1
    invoke-direct {v0, v1, v2, v14}, Lorg/openaok/game/ThorDeck;->panel(Landroid/graphics/Canvas;Landroid/graphics/RectF;I)V

    .line 556
    sget-object v4, Lorg/openaok/game/ThorDeck;->ROMAN:[Ljava/lang/String;

    aget-object v4, v4, v10

    if-lez v3, :cond_1

    iget v5, v2, Landroid/graphics/RectF;->left:F

    add-float v5, v5, v16

    goto :goto_2

    :cond_1
    invoke-virtual {v2}, Landroid/graphics/RectF;->centerX()F

    move-result v5

    :goto_2
    invoke-virtual {v2}, Landroid/graphics/RectF;->centerY()F

    move-result v6

    add-float/2addr v6, v12

    if-lez v3, :cond_2

    goto :goto_3

    :cond_2
    const v11, -0x737c8e

    :goto_3
    sget-object v7, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/4 v8, 0x1

    move v12, v3

    move v3, v5

    const/high16 v5, 0x42000000    # 32.0f

    move/from16 v19, v11

    move-object v11, v2

    move-object v2, v4

    move v4, v6

    move/from16 v6, v19

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    if-lez v12, :cond_3

    .line 558
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    iget v0, v11, Landroid/graphics/RectF;->right:F

    const/high16 v1, 0x41600000    # 14.0f

    sub-float v3, v0, v1

    invoke-virtual {v11}, Landroid/graphics/RectF;->centerY()F

    move-result v0

    const/high16 v1, 0x41200000    # 10.0f

    add-float v4, v0, v1

    sget-object v7, Landroid/graphics/Paint$Align;->RIGHT:Landroid/graphics/Paint$Align;

    const/4 v8, 0x1

    const/high16 v5, 0x41e00000    # 28.0f

    const v6, -0x12192a

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    goto :goto_4

    :cond_3
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    :goto_4
    add-int/lit8 v10, v10, 0x1

    goto/16 :goto_0

    .line 560
    :cond_4
    new-array v10, v2, [Ljava/lang/String;

    invoke-virtual {v0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object v3

    sget v4, Lorg/openaok/game/R$string;->deck_to_selection:I

    invoke-virtual {v3, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v10, v9

    invoke-virtual {v0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object v3

    sget v4, Lorg/openaok/game/R$string;->deck_flare:I

    invoke-virtual {v3, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x1

    aput-object v3, v10, v4

    const-string v3, "\u2212"

    const/4 v4, 0x2

    aput-object v3, v10, v4

    const/4 v3, 0x3

    const-string v5, "+"

    aput-object v5, v10, v3

    :goto_5
    const/high16 v3, 0x41b00000    # 22.0f

    if-ge v9, v2, :cond_9

    .line 563
    iget-object v5, v0, Lorg/openaok/game/ThorDeck;->small:[Landroid/graphics/RectF;

    aget-object v5, v5, v9

    iget v6, v0, Lorg/openaok/game/ThorDeck;->pressedSmall:I

    if-ne v6, v9, :cond_5

    move v6, v14

    goto :goto_6

    :cond_5
    move v6, v15

    :goto_6
    invoke-direct {v0, v1, v5, v6}, Lorg/openaok/game/ThorDeck;->panel(Landroid/graphics/Canvas;Landroid/graphics/RectF;I)V

    .line 564
    aget-object v5, v10, v9

    if-ge v9, v4, :cond_6

    move v6, v3

    goto :goto_7

    :cond_6
    move/from16 v6, v16

    :goto_7
    invoke-direct {v0, v6}, Lorg/openaok/game/ThorDeck;->measure(F)Landroid/text/TextPaint;

    move-result-object v6

    iget-object v7, v0, Lorg/openaok/game/ThorDeck;->small:[Landroid/graphics/RectF;

    aget-object v7, v7, v9

    invoke-virtual {v7}, Landroid/graphics/RectF;->width()F

    move-result v7

    sub-float/2addr v7, v12

    sget-object v8, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-static {v5, v6, v7, v8}, Landroid/text/TextUtils;->ellipsize(Ljava/lang/CharSequence;Landroid/text/TextPaint;FLandroid/text/TextUtils$TruncateAt;)Ljava/lang/CharSequence;

    move-result-object v5

    .line 565
    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    iget-object v6, v0, Lorg/openaok/game/ThorDeck;->small:[Landroid/graphics/RectF;

    aget-object v6, v6, v9

    invoke-virtual {v6}, Landroid/graphics/RectF;->centerX()F

    move-result v6

    iget-object v7, v0, Lorg/openaok/game/ThorDeck;->small:[Landroid/graphics/RectF;

    aget-object v7, v7, v9

    invoke-virtual {v7}, Landroid/graphics/RectF;->centerY()F

    move-result v7

    if-ge v9, v4, :cond_7

    const/16 v8, 0x8

    goto :goto_8

    :cond_7
    const/16 v8, 0xd

    :goto_8
    int-to-float v8, v8

    add-float/2addr v7, v8

    if-ge v9, v4, :cond_8

    goto :goto_9

    :cond_8
    move/from16 v3, v16

    :goto_9
    move v8, v4

    move v4, v7

    sget-object v7, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    move/from16 v17, v8

    const/4 v8, 0x1

    move/from16 v18, v2

    move-object v2, v5

    move v5, v3

    move v3, v6

    const v6, -0x12192a

    .line 564
    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    add-int/lit8 v9, v9, 0x1

    move-object/from16 v1, p1

    move/from16 v4, v17

    move/from16 v2, v18

    goto :goto_5

    :cond_9
    const/16 v1, 0x20

    .line 568
    invoke-direct {v0, v1}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v9

    .line 569
    invoke-virtual {v0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object v1

    sget v2, Lorg/openaok/game/R$string;->deck_speed:I

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v2

    iget-object v1, v0, Lorg/openaok/game/ThorDeck;->speedBox:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    move-result v1

    iget-object v4, v0, Lorg/openaok/game/ThorDeck;->speedBox:Landroid/graphics/RectF;

    iget v4, v4, Landroid/graphics/RectF;->top:F

    add-float/2addr v4, v3

    sget-object v7, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/4 v8, 0x0

    const/high16 v5, 0x41700000    # 15.0f

    const v6, -0x737c8e

    move v3, v1

    move-object/from16 v1, p1

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    .line 571
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    rem-int/lit8 v2, v9, 0x64

    if-nez v2, :cond_a

    div-int/lit8 v2, v9, 0x64

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    goto :goto_a

    :cond_a
    int-to-float v2, v9

    const/high16 v3, 0x42c80000    # 100.0f

    div-float/2addr v2, v3

    invoke-static {v2}, Ljava/lang/String;->valueOf(F)Ljava/lang/String;

    move-result-object v2

    :goto_a
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    iget-object v1, v0, Lorg/openaok/game/ThorDeck;->speedBox:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    iget-object v1, v0, Lorg/openaok/game/ThorDeck;->speedBox:Landroid/graphics/RectF;

    iget v1, v1, Landroid/graphics/RectF;->bottom:F

    const/high16 v4, 0x41000000    # 8.0f

    sub-float v4, v1, v4

    const/16 v1, 0x64

    if-le v9, v1, :cond_b

    goto :goto_b

    :cond_b
    const v11, -0x12192a

    :goto_b
    move v6, v11

    .line 572
    sget-object v7, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/4 v8, 0x1

    const/high16 v5, 0x41e00000    # 28.0f

    move-object/from16 v1, p1

    .line 571
    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    return-void
.end method

.method private drawHeader(Landroid/graphics/Canvas;)V
    .locals 23

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const/4 v2, 0x2

    .line 347
    invoke-direct {v0, v2}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v3

    const/4 v4, 0x3

    invoke-direct {v0, v4}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v5

    const/4 v9, 0x4

    invoke-direct {v0, v9}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v6

    const/4 v7, 0x5

    invoke-direct {v0, v7}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v7

    filled-new-array {v3, v5, v6, v7}, [I

    move-result-object v10

    const/4 v3, 0x6

    .line 348
    invoke-direct {v0, v3}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v11

    const/4 v3, 0x7

    invoke-direct {v0, v3}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v12

    .line 349
    iget-object v3, v0, Lorg/openaok/game/ThorDeck;->art:Landroid/graphics/Bitmap;

    const-string v13, "/"

    const/high16 v14, 0x41000000    # 8.0f

    const/4 v5, 0x0

    if-eqz v3, :cond_2

    .line 351
    sget-object v2, Lorg/openaok/game/ThorDeck;->ART_BAR:Landroid/graphics/Rect;

    iget-object v4, v0, Lorg/openaok/game/ThorDeck;->header:Landroid/graphics/RectF;

    iget-object v6, v0, Lorg/openaok/game/ThorDeck;->bmp:Landroid/graphics/Paint;

    invoke-virtual {v1, v3, v2, v4, v6}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 352
    invoke-virtual {v2}, Landroid/graphics/Rect;->width()I

    move-result v2

    int-to-float v2, v2

    const/high16 v15, 0x449b0000    # 1240.0f

    div-float v16, v15, v2

    move v2, v5

    :goto_0
    const/high16 v3, 0x41200000    # 10.0f

    if-ge v2, v9, :cond_0

    .line 354
    aget v4, v10, v2

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    sget-object v5, Lorg/openaok/game/ThorDeck;->ART_SLOT_RIGHT:[I

    aget v5, v5, v2

    int-to-float v5, v5

    mul-float v5, v5, v16

    sub-float v3, v5, v3

    sget-object v7, Landroid/graphics/Paint$Align;->RIGHT:Landroid/graphics/Paint$Align;

    const/4 v8, 0x1

    move v5, v2

    move-object v2, v4

    const/high16 v4, 0x42600000    # 56.0f

    move v6, v5

    const/high16 v5, 0x42100000    # 36.0f

    move/from16 v17, v6

    const/4 v6, -0x1

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    add-int/lit8 v2, v17, 0x1

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    goto :goto_0

    .line 356
    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    sget-object v10, Lorg/openaok/game/ThorDeck;->ART_SLOT_RIGHT:[I

    aget v0, v10, v9

    int-to-float v0, v0

    mul-float v0, v0, v16

    sub-float v3, v0, v3

    if-lt v11, v12, :cond_1

    const v0, -0x95b0

    goto :goto_1

    :cond_1
    const/4 v0, -0x1

    :goto_1
    move v6, v0

    sget-object v7, Landroid/graphics/Paint$Align;->RIGHT:Landroid/graphics/Paint$Align;

    const/4 v8, 0x1

    const/high16 v4, 0x42600000    # 56.0f

    const/high16 v5, 0x42100000    # 36.0f

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    move-object v6, v0

    .line 358
    aget v0, v10, v9

    int-to-float v0, v0

    mul-float v0, v0, v16

    add-float v1, v0, v14

    .line 359
    iget-object v0, v6, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    const/high16 v2, -0x60000000

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v4, 0x428c0000    # 70.0f

    .line 360
    iget-object v5, v6, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    const/high16 v2, 0x41600000    # 14.0f

    const/high16 v3, 0x449a0000    # 1232.0f

    move-object/from16 v0, p1

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 361
    iget-object v0, v6, Lorg/openaok/game/ThorDeck;->ageName:Ljava/lang/String;

    const/high16 v2, 0x42000000    # 32.0f

    invoke-direct {v6, v2}, Lorg/openaok/game/ThorDeck;->measure(F)Landroid/text/TextPaint;

    move-result-object v2

    const/high16 v3, 0x44980000    # 1216.0f

    sub-float/2addr v3, v1

    sget-object v4, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-static {v0, v2, v3, v4}, Landroid/text/TextUtils;->ellipsize(Ljava/lang/CharSequence;Landroid/text/TextPaint;FLandroid/text/TextUtils$TruncateAt;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    add-float/2addr v1, v15

    sub-float/2addr v1, v14

    const/high16 v0, 0x40000000    # 2.0f

    div-float v3, v1, v0

    sget-object v7, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/high16 v4, 0x42580000    # 54.0f

    const/high16 v5, 0x42000000    # 32.0f

    const v6, -0x174fb6

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    return-void

    .line 365
    :cond_2
    iget-object v3, v0, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    new-instance v15, Landroid/graphics/LinearGradient;

    iget-object v6, v0, Lorg/openaok/game/ThorDeck;->header:Landroid/graphics/RectF;

    iget v6, v6, Landroid/graphics/RectF;->bottom:F

    const v21, -0xf1f2f5

    sget-object v22, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const v20, -0xd9dde5

    move/from16 v19, v6

    invoke-direct/range {v15 .. v22}, Landroid/graphics/LinearGradient;-><init>(FFFFIILandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v3, v15}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 366
    iget-object v3, v0, Lorg/openaok/game/ThorDeck;->header:Landroid/graphics/RectF;

    iget-object v6, v0, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    invoke-virtual {v1, v3, v6}, Landroid/graphics/Canvas;->drawRect(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 367
    iget-object v3, v0, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    const/4 v6, 0x0

    invoke-virtual {v3, v6}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 368
    new-array v15, v9, [Ljava/lang/String;

    .line 369
    invoke-virtual {v0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object v3

    sget v6, Lorg/openaok/game/R$string;->deck_wood:I

    invoke-virtual {v3, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v15, v5

    invoke-virtual {v0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object v3

    sget v6, Lorg/openaok/game/R$string;->deck_food:I

    invoke-virtual {v3, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x1

    aput-object v3, v15, v6

    .line 370
    invoke-virtual {v0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object v3

    sget v6, Lorg/openaok/game/R$string;->deck_gold:I

    invoke-virtual {v3, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v15, v2

    invoke-virtual {v0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object v2

    sget v3, Lorg/openaok/game/R$string;->deck_stone:I

    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v15, v4

    const v2, -0x173eb6

    const v3, -0x505058

    const v4, -0x6394c6

    const v6, -0x26a8c1

    .line 371
    filled-new-array {v4, v6, v2, v3}, [I

    move-result-object v16

    const/high16 v2, 0x41c00000    # 24.0f

    move/from16 v17, v2

    move v2, v5

    :goto_2
    if-ge v2, v9, :cond_3

    .line 374
    iget-object v3, v0, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    aget v4, v16, v2

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v3, 0x41600000    # 14.0f

    add-float v3, v17, v3

    const/high16 v4, 0x41400000    # 12.0f

    .line 375
    iget-object v5, v0, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    const/high16 v7, 0x42280000    # 42.0f

    invoke-virtual {v1, v3, v7, v4, v5}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    move v5, v2

    .line 376
    aget-object v2, v15, v5

    const/high16 v3, 0x42100000    # 36.0f

    add-float v3, v17, v3

    sget-object v7, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    const/4 v8, 0x0

    const/high16 v4, 0x41f00000    # 30.0f

    move/from16 v18, v5

    const/high16 v5, 0x41a00000    # 20.0f

    move/from16 v19, v6

    const v6, -0x737c8e

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    .line 377
    aget v0, v10, v18

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    sget-object v7, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    const/4 v8, 0x1

    const/high16 v4, 0x42880000    # 68.0f

    const/high16 v5, 0x42180000    # 38.0f

    const v6, -0x12192a

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    const/high16 v0, 0x43440000    # 196.0f

    add-float v17, v17, v0

    add-int/lit8 v2, v18, 0x1

    move-object/from16 v0, p0

    move/from16 v6, v19

    goto :goto_2

    :cond_3
    move/from16 v19, v6

    .line 380
    invoke-virtual/range {p0 .. p0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object v0

    sget v1, Lorg/openaok/game/R$string;->deck_pop:I

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    add-float v3, v17, v14

    sget-object v7, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    const/4 v8, 0x0

    const/high16 v4, 0x41f00000    # 30.0f

    const/high16 v5, 0x41a00000    # 20.0f

    const v6, -0x737c8e

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    .line 381
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    if-lt v11, v12, :cond_4

    move/from16 v6, v19

    goto :goto_3

    :cond_4
    const v6, -0x12192a

    :goto_3
    sget-object v7, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    const/4 v8, 0x1

    const/high16 v4, 0x42880000    # 68.0f

    const/high16 v5, 0x42180000    # 38.0f

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    .line 382
    iget-object v1, v0, Lorg/openaok/game/ThorDeck;->ageName:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v2

    sget-object v7, Landroid/graphics/Paint$Align;->RIGHT:Landroid/graphics/Paint$Align;

    const/high16 v3, 0x44980000    # 1216.0f

    const/high16 v4, 0x42600000    # 56.0f

    const/high16 v5, 0x42080000    # 34.0f

    const v6, -0x174fb6

    move-object/from16 v1, p1

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    return-void
.end method

.method private drawIdle(Landroid/graphics/Canvas;)V
    .locals 18

    .line 342
    sget-object v7, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/4 v8, 0x1

    const-string v2, "OpenAokHD"

    const/high16 v3, 0x441b0000    # 620.0f

    const/high16 v4, 0x43fa0000    # 500.0f

    const/high16 v5, 0x42c00000    # 96.0f

    const v6, -0x174fb6

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    .line 343
    invoke-virtual/range {p0 .. p0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object v0

    sget v1, Lorg/openaok/game/R$string;->deck_idle:I

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v11

    sget-object v16, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/16 v17, 0x0

    const/high16 v12, 0x441b0000    # 620.0f

    const/high16 v13, 0x44110000    # 580.0f

    const/high16 v14, 0x42100000    # 36.0f

    const v15, -0x737c8e

    move-object/from16 v9, p0

    move-object/from16 v10, p1

    invoke-direct/range {v9 .. v17}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    return-void
.end method

.method private drawMinimap(Landroid/graphics/Canvas;)V
    .locals 13

    .line 386
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->mapPanel:Landroid/graphics/RectF;

    const v9, -0xe5e7ec

    invoke-direct {p0, p1, v2, v9}, Lorg/openaok/game/ThorDeck;->panel(Landroid/graphics/Canvas;Landroid/graphics/RectF;I)V

    .line 387
    sget v2, Lorg/openaok/game/R$string;->deck_map_normal:I

    sget v3, Lorg/openaok/game/R$string;->deck_map_combat:I

    sget v4, Lorg/openaok/game/R$string;->deck_map_economic:I

    sget v5, Lorg/openaok/game/R$string;->deck_alert:I

    filled-new-array {v2, v3, v4, v5}, [I

    move-result-object v10

    const/4 v11, 0x0

    move v12, v11

    :goto_0
    const/4 v2, 0x4

    if-ge v12, v2, :cond_2

    .line 389
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->mapButtons:[Landroid/graphics/RectF;

    aget-object v2, v2, v12

    iget v3, p0, Lorg/openaok/game/ThorDeck;->pressedSmall:I

    add-int/lit8 v4, v12, 0xa

    if-ne v3, v4, :cond_0

    const v3, -0xd9dde5

    goto :goto_1

    :cond_0
    move v3, v9

    :goto_1
    invoke-direct {p0, p1, v2, v3}, Lorg/openaok/game/ThorDeck;->panel(Landroid/graphics/Canvas;Landroid/graphics/RectF;I)V

    .line 390
    invoke-virtual {p0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object v2

    aget v3, v10, v12

    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Lorg/openaok/game/ThorDeck;->mapButtons:[Landroid/graphics/RectF;

    aget-object v3, v3, v12

    invoke-virtual {v3}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    iget-object v4, p0, Lorg/openaok/game/ThorDeck;->mapButtons:[Landroid/graphics/RectF;

    aget-object v4, v4, v12

    invoke-virtual {v4}, Landroid/graphics/RectF;->centerY()F

    move-result v4

    const/high16 v5, 0x40c00000    # 6.0f

    add-float/2addr v4, v5

    const/4 v5, 0x3

    if-ne v12, v5, :cond_1

    const v5, -0x174fb6

    goto :goto_2

    :cond_1
    const v5, -0x12192a

    :goto_2
    move v6, v5

    .line 391
    sget-object v7, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/4 v8, 0x1

    const/high16 v5, 0x41880000    # 17.0f

    move-object v0, p0

    move-object v1, p1

    .line 390
    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    add-int/lit8 v12, v12, 0x1

    goto :goto_0

    .line 393
    :cond_2
    iget-object v3, p0, Lorg/openaok/game/ThorDeck;->mapBitmap:Landroid/graphics/Bitmap;

    if-eqz v3, :cond_5

    .line 394
    iget-object v4, p0, Lorg/openaok/game/ThorDeck;->mapArea:Landroid/graphics/RectF;

    iget-object v5, p0, Lorg/openaok/game/ThorDeck;->bmp:Landroid/graphics/Paint;

    const/4 v6, 0x0

    invoke-virtual {p1, v3, v6, v4, v5}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    const/16 v3, 0x15

    .line 395
    invoke-direct {p0, v3}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v3

    const/16 v4, 0x16

    invoke-direct {p0, v4}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v4

    if-lez v3, :cond_5

    if-lez v4, :cond_5

    .line 397
    iget-object v5, p0, Lorg/openaok/game/ThorDeck;->mapArea:Landroid/graphics/RectF;

    invoke-virtual {v5}, Landroid/graphics/RectF;->width()F

    move-result v5

    int-to-float v3, v3

    div-float/2addr v5, v3

    iget-object v3, p0, Lorg/openaok/game/ThorDeck;->mapArea:Landroid/graphics/RectF;

    invoke-virtual {v3}, Landroid/graphics/RectF;->height()F

    move-result v3

    int-to-float v4, v4

    div-float/2addr v3, v4

    .line 398
    iget-object v4, p0, Lorg/openaok/game/ThorDeck;->path:Landroid/graphics/Path;

    invoke-virtual {v4}, Landroid/graphics/Path;->reset()V

    :goto_3
    if-ge v11, v2, :cond_4

    .line 400
    iget-object v4, p0, Lorg/openaok/game/ThorDeck;->mapArea:Landroid/graphics/RectF;

    iget v4, v4, Landroid/graphics/RectF;->left:F

    mul-int/lit8 v6, v11, 0x2

    add-int/lit8 v7, v6, 0x17

    invoke-direct {p0, v7}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v7

    int-to-float v7, v7

    mul-float/2addr v7, v5

    add-float/2addr v4, v7

    .line 401
    iget-object v7, p0, Lorg/openaok/game/ThorDeck;->mapArea:Landroid/graphics/RectF;

    iget v7, v7, Landroid/graphics/RectF;->top:F

    add-int/lit8 v6, v6, 0x18

    invoke-direct {p0, v6}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v6

    int-to-float v6, v6

    mul-float/2addr v6, v3

    add-float/2addr v7, v6

    if-nez v11, :cond_3

    .line 402
    iget-object v6, p0, Lorg/openaok/game/ThorDeck;->path:Landroid/graphics/Path;

    invoke-virtual {v6, v4, v7}, Landroid/graphics/Path;->moveTo(FF)V

    goto :goto_4

    .line 403
    :cond_3
    iget-object v6, p0, Lorg/openaok/game/ThorDeck;->path:Landroid/graphics/Path;

    invoke-virtual {v6, v4, v7}, Landroid/graphics/Path;->lineTo(FF)V

    :goto_4
    add-int/lit8 v11, v11, 0x1

    goto :goto_3

    .line 405
    :cond_4
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->path:Landroid/graphics/Path;

    invoke-virtual {v2}, Landroid/graphics/Path;->close()V

    .line 406
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 407
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->mapArea:Landroid/graphics/RectF;

    invoke-virtual {p1, v2}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/RectF;)Z

    .line 408
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->stroke:Landroid/graphics/Paint;

    const/4 v3, -0x1

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 409
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->stroke:Landroid/graphics/Paint;

    const/high16 v3, 0x40200000    # 2.5f

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 410
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->path:Landroid/graphics/Path;

    iget-object v0, p0, Lorg/openaok/game/ThorDeck;->stroke:Landroid/graphics/Paint;

    invoke-virtual {p1, v2, v0}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 411
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    :cond_5
    return-void
.end method

.method private drawSelection(Landroid/graphics/Canvas;)V
    .locals 22

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 417
    iget-object v2, v0, Lorg/openaok/game/ThorDeck;->art:Landroid/graphics/Bitmap;

    const/4 v9, 0x0

    const/4 v10, 0x1

    if-eqz v2, :cond_0

    move v3, v10

    goto :goto_0

    :cond_0
    move v3, v9

    :goto_0
    if-eqz v3, :cond_1

    const v4, -0xd5e3f4

    goto :goto_1

    :cond_1
    const v4, -0x12192a

    :goto_1
    move v6, v4

    if-eqz v3, :cond_2

    const v4, -0x94aac6

    goto :goto_2

    :cond_2
    const v4, -0x737c8e

    :goto_2
    if-eqz v3, :cond_3

    .line 420
    sget-object v3, Lorg/openaok/game/ThorDeck;->ART_PARCHMENT:Landroid/graphics/Rect;

    iget-object v5, v0, Lorg/openaok/game/ThorDeck;->selPanel:Landroid/graphics/RectF;

    iget-object v7, v0, Lorg/openaok/game/ThorDeck;->bmp:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v3, v5, v7}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    goto :goto_3

    .line 422
    :cond_3
    iget-object v2, v0, Lorg/openaok/game/ThorDeck;->selPanel:Landroid/graphics/RectF;

    const v3, -0xe5e7ec

    invoke-direct {v0, v1, v2, v3}, Lorg/openaok/game/ThorDeck;->panel(Landroid/graphics/Canvas;Landroid/graphics/RectF;I)V

    .line 424
    :goto_3
    iget-object v2, v0, Lorg/openaok/game/ThorDeck;->selPanel:Landroid/graphics/RectF;

    iget v2, v2, Landroid/graphics/RectF;->left:F

    const/high16 v11, 0x41e00000    # 28.0f

    add-float v3, v2, v11

    iget-object v2, v0, Lorg/openaok/game/ThorDeck;->selPanel:Landroid/graphics/RectF;

    iget v2, v2, Landroid/graphics/RectF;->top:F

    const/high16 v5, 0x41d00000    # 26.0f

    add-float v12, v2, v5

    .line 425
    iget-wide v7, v0, Lorg/openaok/game/ThorDeck;->helpUntil:J

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v13

    cmp-long v2, v7, v13

    if-lez v2, :cond_4

    iget-object v2, v0, Lorg/openaok/game/ThorDeck;->help:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_4

    .line 426
    iget-object v2, v0, Lorg/openaok/game/ThorDeck;->text:Landroid/text/TextPaint;

    invoke-virtual {v2, v5}, Landroid/text/TextPaint;->setTextSize(F)V

    .line 427
    iget-object v2, v0, Lorg/openaok/game/ThorDeck;->help:Ljava/lang/String;

    add-float v4, v12, v5

    iget-object v5, v0, Lorg/openaok/game/ThorDeck;->selPanel:Landroid/graphics/RectF;

    iget v5, v5, Landroid/graphics/RectF;->right:F

    sub-float/2addr v5, v11

    move v8, v6

    const/high16 v6, 0x42000000    # 32.0f

    const/16 v7, 0x8

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->drawWrapped(Landroid/graphics/Canvas;Ljava/lang/String;FFFFII)V

    return-void

    :cond_4
    move v13, v3

    move v8, v6

    const/16 v1, 0xa

    .line 430
    invoke-direct {v0, v1}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v2

    const/16 v14, 0xf

    if-nez v2, :cond_5

    invoke-direct {v0, v14}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v2

    if-gez v2, :cond_5

    .line 431
    invoke-virtual {v0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object v1

    sget v2, Lorg/openaok/game/R$string;->deck_nothing:I

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    iget-object v1, v0, Lorg/openaok/game/ThorDeck;->selPanel:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    iget-object v1, v0, Lorg/openaok/game/ThorDeck;->selPanel:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    move-result v1

    sget-object v7, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/4 v8, 0x0

    const/high16 v5, 0x41e00000    # 28.0f

    move v6, v4

    move v4, v1

    move-object/from16 v1, p1

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    return-void

    :cond_5
    move-object/from16 v2, p1

    move v15, v4

    const/16 v3, 0xd

    .line 435
    invoke-direct {v0, v3}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v3

    const/16 v4, 0xe

    invoke-direct {v0, v4}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v4

    invoke-direct {v0, v3, v4}, Lorg/openaok/game/ThorDeck;->icon(II)Landroid/graphics/Bitmap;

    move-result-object v3

    .line 436
    new-instance v4, Landroid/graphics/RectF;

    const/high16 v5, 0x43000000    # 128.0f

    add-float v6, v13, v5

    add-float/2addr v5, v12

    invoke-direct {v4, v13, v12, v6, v5}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/4 v5, 0x0

    if-eqz v3, :cond_6

    .line 437
    iget-object v6, v0, Lorg/openaok/game/ThorDeck;->bmp:Landroid/graphics/Paint;

    invoke-virtual {v2, v3, v5, v4, v6}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 438
    :cond_6
    iget-object v3, v0, Lorg/openaok/game/ThorDeck;->stroke:Landroid/graphics/Paint;

    const v6, -0xc5ccd8

    invoke-virtual {v3, v6}, Landroid/graphics/Paint;->setColor(I)V

    .line 439
    iget-object v3, v0, Lorg/openaok/game/ThorDeck;->stroke:Landroid/graphics/Paint;

    invoke-virtual {v2, v4, v3}, Landroid/graphics/Canvas;->drawRect(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 440
    invoke-direct {v0, v1}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v1

    if-le v1, v10, :cond_7

    .line 441
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v6, v0, Lorg/openaok/game/ThorDeck;->selName:Ljava/lang/String;

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v6, "  \u00d7"

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_4

    :cond_7
    iget-object v1, v0, Lorg/openaok/game/ThorDeck;->selName:Ljava/lang/String;

    :goto_4
    const/high16 v3, 0x42080000    # 34.0f

    .line 442
    invoke-direct {v0, v3}, Lorg/openaok/game/ThorDeck;->measure(F)Landroid/text/TextPaint;

    move-result-object v3

    iget-object v6, v0, Lorg/openaok/game/ThorDeck;->selPanel:Landroid/graphics/RectF;

    iget v6, v6, Landroid/graphics/RectF;->right:F

    iget v7, v4, Landroid/graphics/RectF;->right:F

    sub-float/2addr v6, v7

    const/high16 v7, 0x42200000    # 40.0f

    sub-float/2addr v6, v7

    sget-object v5, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-static {v1, v3, v6, v5}, Landroid/text/TextUtils;->ellipsize(Ljava/lang/CharSequence;Landroid/text/TextPaint;FLandroid/text/TextUtils$TruncateAt;)Ljava/lang/CharSequence;

    move-result-object v1

    .line 443
    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    iget v3, v4, Landroid/graphics/RectF;->right:F

    const/high16 v17, 0x41a00000    # 20.0f

    add-float v3, v3, v17

    add-float/2addr v7, v12

    move-object v5, v4

    move v4, v7

    sget-object v7, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    move v6, v8

    const/4 v8, 0x1

    move-object/from16 v18, v5

    const/high16 v5, 0x42000000    # 32.0f

    move-object v10, v2

    move-object v2, v1

    move-object v1, v10

    move/from16 v19, v11

    move-object/from16 v11, v18

    const/4 v10, 0x0

    .line 442
    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    move-object v6, v0

    const/16 v0, 0xb

    .line 444
    invoke-direct {v6, v0}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v7

    const/16 v0, 0xc

    invoke-direct {v6, v0}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v8

    const v0, -0x9040b6

    const/high16 v18, 0x42a40000    # 82.0f

    if-lez v8, :cond_8

    .line 446
    new-instance v2, Landroid/graphics/RectF;

    iget v3, v11, Landroid/graphics/RectF;->right:F

    add-float v3, v3, v17

    const/high16 v4, 0x42780000    # 62.0f

    add-float/2addr v4, v12

    iget-object v5, v6, Lorg/openaok/game/ThorDeck;->selPanel:Landroid/graphics/RectF;

    iget v5, v5, Landroid/graphics/RectF;->right:F

    const/high16 v20, 0x42000000    # 32.0f

    sub-float v5, v5, v20

    add-float v10, v12, v18

    invoke-direct {v2, v3, v4, v5, v10}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 447
    iget-object v3, v6, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    const v4, -0xc5e5ec

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 448
    iget-object v3, v6, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v3}, Landroid/graphics/Canvas;->drawRect(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 449
    iget-object v3, v6, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    invoke-virtual {v3, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 450
    iget v1, v2, Landroid/graphics/RectF;->left:F

    iget v3, v2, Landroid/graphics/RectF;->top:F

    iget v4, v2, Landroid/graphics/RectF;->left:F

    invoke-virtual {v2}, Landroid/graphics/RectF;->width()F

    move-result v5

    invoke-static {v7, v8}, Ljava/lang/Math;->min(II)I

    move-result v10

    invoke-static {v9, v10}, Ljava/lang/Math;->max(II)I

    move-result v10

    int-to-float v10, v10

    mul-float/2addr v5, v10

    int-to-float v10, v8

    div-float/2addr v5, v10

    add-float/2addr v4, v5

    iget v2, v2, Landroid/graphics/RectF;->bottom:F

    iget-object v5, v6, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    move v10, v4

    move v4, v2

    move v2, v3

    move v3, v10

    move v10, v0

    move-object/from16 v0, p1

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 451
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " / "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    iget v0, v11, Landroid/graphics/RectF;->right:F

    add-float v3, v0, v17

    const/high16 v0, 0x42e80000    # 116.0f

    add-float v4, v12, v0

    sget-object v7, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    const/4 v8, 0x0

    const/high16 v5, 0x41d00000    # 26.0f

    move-object/from16 v1, p1

    move-object v0, v6

    move v6, v15

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    goto :goto_5

    :cond_8
    move v10, v0

    move-object v0, v6

    :goto_5
    const/16 v2, 0x13

    .line 454
    invoke-direct {v0, v2}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v11

    const/16 v2, 0x12

    .line 455
    invoke-direct {v0, v2}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v2

    mul-int/lit8 v2, v2, 0x8

    add-int/lit8 v15, v2, 0x27

    const/high16 v2, 0x430e0000    # 142.0f

    add-float/2addr v12, v2

    move v2, v9

    :goto_6
    if-ge v2, v14, :cond_9

    .line 457
    iget-object v3, v0, Lorg/openaok/game/ThorDeck;->queueRects:[Landroid/graphics/RectF;

    aget-object v3, v3, v2

    invoke-virtual {v3}, Landroid/graphics/RectF;->setEmpty()V

    add-int/lit8 v2, v2, 0x1

    goto :goto_6

    :cond_9
    move v2, v12

    move v12, v9

    move v9, v13

    :goto_7
    if-ge v12, v11, :cond_e

    if-ge v12, v14, :cond_e

    mul-int/lit8 v3, v12, 0x5

    add-int/2addr v3, v15

    .line 460
    iget-object v4, v0, Lorg/openaok/game/ThorDeck;->queueRects:[Landroid/graphics/RectF;

    aget-object v4, v4, v12

    const/high16 v17, 0x42800000    # 64.0f

    add-float v5, v9, v17

    add-float v6, v2, v17

    .line 461
    invoke-virtual {v4, v9, v2, v5, v6}, Landroid/graphics/RectF;->set(FFFF)V

    .line 462
    iget-object v5, v0, Lorg/openaok/game/ThorDeck;->queueSlot:[I

    iget-object v6, v0, Lorg/openaok/game/ThorDeck;->snap:[I

    aget v6, v6, v3

    aput v6, v5, v12

    const v5, -0xd9dde5

    .line 463
    invoke-direct {v0, v1, v4, v5}, Lorg/openaok/game/ThorDeck;->panel(Landroid/graphics/Canvas;Landroid/graphics/RectF;I)V

    .line 464
    iget-object v5, v0, Lorg/openaok/game/ThorDeck;->snap:[I

    add-int/lit8 v6, v3, 0x3

    aget v6, v5, v6

    add-int/lit8 v7, v3, 0x4

    aget v5, v5, v7

    invoke-direct {v0, v6, v5}, Lorg/openaok/game/ThorDeck;->icon(II)Landroid/graphics/Bitmap;

    move-result-object v5

    const/high16 v21, 0x40800000    # 4.0f

    if-eqz v5, :cond_a

    .line 465
    new-instance v6, Landroid/graphics/RectF;

    iget v7, v4, Landroid/graphics/RectF;->left:F

    add-float v7, v7, v21

    iget v8, v4, Landroid/graphics/RectF;->top:F

    add-float v8, v8, v21

    iget v14, v4, Landroid/graphics/RectF;->right:F

    sub-float v14, v14, v21

    iget v10, v4, Landroid/graphics/RectF;->bottom:F

    sub-float v10, v10, v21

    invoke-direct {v6, v7, v8, v14, v10}, Landroid/graphics/RectF;-><init>(FFFF)V

    iget-object v7, v0, Lorg/openaok/game/ThorDeck;->bmp:Landroid/graphics/Paint;

    const/4 v10, 0x0

    invoke-virtual {v1, v5, v10, v6, v7}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    goto :goto_8

    :cond_a
    const/4 v10, 0x0

    .line 466
    :goto_8
    iget-object v5, v0, Lorg/openaok/game/ThorDeck;->snap:[I

    add-int/lit8 v3, v3, 0x2

    aget v5, v5, v3

    const/4 v14, 0x1

    if-le v5, v14, :cond_b

    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "\u00d7"

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v6, v0, Lorg/openaok/game/ThorDeck;->snap:[I

    aget v3, v6, v3

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    iget v5, v4, Landroid/graphics/RectF;->left:F

    const/high16 v6, 0x41000000    # 8.0f

    add-float/2addr v5, v6

    iget v6, v4, Landroid/graphics/RectF;->top:F

    add-float v6, v6, v19

    sget-object v7, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    const/4 v8, 0x1

    move/from16 v16, v2

    move-object v2, v3

    move v3, v5

    const/high16 v5, 0x41c00000    # 24.0f

    move-object/from16 v20, v4

    move v4, v6

    const v6, -0x174fb6

    move-object/from16 v10, v20

    invoke-direct/range {v0 .. v8}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    goto :goto_9

    :cond_b
    move/from16 v16, v2

    move-object v10, v4

    :goto_9
    move-object v6, v0

    if-nez v12, :cond_c

    const/16 v0, 0x11

    .line 467
    invoke-direct {v6, v0}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v1

    if-lez v1, :cond_c

    const/16 v1, 0x10

    .line 468
    invoke-direct {v6, v1}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v1

    int-to-float v1, v1

    invoke-direct {v6, v0}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v0

    int-to-float v0, v0

    div-float/2addr v1, v0

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    .line 469
    iget-object v1, v6, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    const v7, -0x9040b6

    invoke-virtual {v1, v7}, Landroid/graphics/Paint;->setColor(I)V

    .line 470
    iget v1, v10, Landroid/graphics/RectF;->left:F

    iget v2, v10, Landroid/graphics/RectF;->bottom:F

    add-float v2, v2, v21

    iget v3, v10, Landroid/graphics/RectF;->left:F

    invoke-virtual {v10}, Landroid/graphics/RectF;->width()F

    move-result v4

    mul-float/2addr v4, v0

    add-float/2addr v3, v4

    iget v0, v10, Landroid/graphics/RectF;->bottom:F

    const/high16 v4, 0x41200000    # 10.0f

    add-float/2addr v4, v0

    iget-object v5, v6, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    move-object/from16 v0, p1

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    goto :goto_a

    :cond_c
    const v7, -0x9040b6

    :goto_a
    const/high16 v0, 0x42940000    # 74.0f

    add-float/2addr v9, v0

    add-float v17, v9, v17

    .line 473
    iget-object v0, v6, Lorg/openaok/game/ThorDeck;->selPanel:Landroid/graphics/RectF;

    iget v0, v0, Landroid/graphics/RectF;->right:F

    const/high16 v1, 0x41c00000    # 24.0f

    sub-float/2addr v0, v1

    cmpl-float v0, v17, v0

    if-lez v0, :cond_d

    add-float v2, v16, v18

    move v9, v13

    goto :goto_b

    :cond_d
    move/from16 v2, v16

    :goto_b
    add-int/lit8 v12, v12, 0x1

    move-object/from16 v1, p1

    move-object v0, v6

    move v10, v7

    const/16 v14, 0xf

    goto/16 :goto_7

    :cond_e
    return-void
.end method

.method private drawTabs(Landroid/graphics/Canvas;)V
    .locals 14

    .line 576
    sget v0, Lorg/openaok/game/R$string;->deck_tab_commands:I

    sget v1, Lorg/openaok/game/R$string;->deck_tab_goto:I

    sget v2, Lorg/openaok/game/R$string;->deck_tab_game:I

    filled-new-array {v0, v1, v2}, [I

    move-result-object v0

    const/4 v1, 0x0

    :goto_0
    const/4 v2, 0x3

    if-ge v1, v2, :cond_3

    .line 578
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->tabs:[Landroid/graphics/RectF;

    aget-object v2, v2, v1

    .line 579
    iget v3, p0, Lorg/openaok/game/ThorDeck;->tab:I

    if-ne v1, v3, :cond_0

    const v3, -0xd9dde5

    goto :goto_1

    :cond_0
    const v3, -0xe5e7ec

    :goto_1
    invoke-direct {p0, p1, v2, v3}, Lorg/openaok/game/ThorDeck;->panel(Landroid/graphics/Canvas;Landroid/graphics/RectF;I)V

    .line 580
    invoke-virtual {p0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object v3

    aget v4, v0, v1

    invoke-virtual {v3, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2}, Landroid/graphics/RectF;->centerX()F

    move-result v7

    invoke-virtual {v2}, Landroid/graphics/RectF;->centerY()F

    move-result v3

    const/high16 v4, 0x41100000    # 9.0f

    add-float v8, v3, v4

    iget v3, p0, Lorg/openaok/game/ThorDeck;->tab:I

    const v13, -0x174fb6

    if-ne v1, v3, :cond_1

    move v10, v13

    goto :goto_2

    :cond_1
    const v3, -0x737c8e

    move v10, v3

    :goto_2
    sget-object v11, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    const/4 v12, 0x1

    const/high16 v9, 0x41c00000    # 24.0f

    move-object v4, p0

    move-object v5, p1

    invoke-direct/range {v4 .. v12}, Lorg/openaok/game/ThorDeck;->label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V

    .line 582
    iget p0, v4, Lorg/openaok/game/ThorDeck;->tab:I

    if-ne v1, p0, :cond_2

    .line 583
    iget-object p0, v4, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    invoke-virtual {p0, v13}, Landroid/graphics/Paint;->setColor(I)V

    .line 584
    iget p0, v2, Landroid/graphics/RectF;->left:F

    const/high16 p1, 0x41400000    # 12.0f

    add-float v6, p0, p1

    iget p0, v2, Landroid/graphics/RectF;->bottom:F

    const/high16 v3, 0x40a00000    # 5.0f

    sub-float v7, p0, v3

    iget p0, v2, Landroid/graphics/RectF;->right:F

    sub-float v8, p0, p1

    iget p0, v2, Landroid/graphics/RectF;->bottom:F

    const/high16 p1, 0x40000000    # 2.0f

    sub-float v9, p0, p1

    iget-object v10, v4, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    invoke-virtual/range {v5 .. v10}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    :cond_2
    add-int/lit8 v1, v1, 0x1

    move-object p0, v4

    move-object p1, v5

    goto :goto_0

    :cond_3
    return-void
.end method

.method private drawWrapped(Landroid/graphics/Canvas;Ljava/lang/String;FFFFII)V
    .locals 10

    .line 486
    iget-object v0, p0, Lorg/openaok/game/ThorDeck;->text:Landroid/text/TextPaint;

    move/from16 v1, p8

    invoke-virtual {v0, v1}, Landroid/text/TextPaint;->setColor(I)V

    .line 487
    iget-object v0, p0, Lorg/openaok/game/ThorDeck;->text:Landroid/text/TextPaint;

    sget-object v1, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {v0, v1}, Landroid/text/TextPaint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 488
    iget-object v0, p0, Lorg/openaok/game/ThorDeck;->text:Landroid/text/TextPaint;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/text/TextPaint;->setFakeBoldText(Z)V

    .line 489
    const-string v0, " "

    invoke-virtual {p2, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p2

    .line 490
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 492
    array-length v3, p2

    move v4, v1

    move-object v5, v2

    move v1, p4

    move v2, v4

    :goto_0
    if-ge v2, v3, :cond_3

    aget-object v6, p2, v2

    .line 493
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->length()I

    move-result v7

    if-nez v7, :cond_0

    move-object v7, v6

    goto :goto_1

    :cond_0
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    .line 494
    :goto_1
    iget-object v8, p0, Lorg/openaok/game/ThorDeck;->text:Landroid/text/TextPaint;

    invoke-virtual {v8, v7}, Landroid/text/TextPaint;->measureText(Ljava/lang/String;)F

    move-result v8

    sub-float v9, p5, p3

    cmpl-float v8, v8, v9

    if-lez v8, :cond_2

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->length()I

    move-result v8

    if-lez v8, :cond_2

    .line 495
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    iget-object v7, p0, Lorg/openaok/game/ThorDeck;->text:Landroid/text/TextPaint;

    invoke-virtual {p1, v5, p3, v1, v7}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    add-float v1, v1, p6

    add-int/lit8 v4, v4, 0x1

    move/from16 v8, p7

    if-lt v4, v8, :cond_1

    goto :goto_3

    .line 498
    :cond_1
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    goto :goto_2

    :cond_2
    move/from16 v8, p7

    .line 500
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    :goto_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 503
    :cond_3
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->length()I

    move-result p2

    if-lez p2, :cond_4

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    iget-object p0, p0, Lorg/openaok/game/ThorDeck;->text:Landroid/text/TextPaint;

    invoke-virtual {p1, p2, p3, v1, p0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    :cond_4
    :goto_3
    return-void
.end method

.method private goToBase(I)I
    .locals 2

    const/16 v0, 0x12

    .line 213
    invoke-direct {p0, v0}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v0

    mul-int/lit8 v0, v0, 0x8

    add-int/lit8 v0, v0, 0x27

    const/16 v1, 0x13

    .line 214
    invoke-direct {p0, v1}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result p0

    mul-int/lit8 p0, p0, 0x5

    add-int/2addr v0, p0

    mul-int/lit8 p1, p1, 0x4

    add-int/2addr v0, p1

    return v0
.end method

.method private h(I)I
    .locals 0

    .line 176
    iget-object p0, p0, Lorg/openaok/game/ThorDeck;->snap:[I

    add-int/lit8 p1, p1, 0x1

    aget p0, p0, p1

    return p0
.end method

.method private icon(II)Landroid/graphics/Bitmap;
    .locals 13

    const/4 v0, 0x0

    if-lez p1, :cond_3

    if-gez p2, :cond_0

    goto :goto_0

    :cond_0
    int-to-long v1, p1

    const/16 v3, 0x14

    shl-long/2addr v1, v3

    int-to-long v3, p2

    or-long/2addr v1, v3

    .line 239
    iget-object v3, p0, Lorg/openaok/game/ThorDeck;->icons:Ljava/util/Map;

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    invoke-interface {v3, v4}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    iget-object p0, p0, Lorg/openaok/game/ThorDeck;->icons:Ljava/util/Map;

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/graphics/Bitmap;

    return-object p0

    .line 241
    :cond_1
    iget-object v3, p0, Lorg/openaok/game/ThorDeck;->iconBuf:[I

    iget-object v4, p0, Lorg/openaok/game/ThorDeck;->iconWh:[I

    invoke-static {p1, p2, v3, v4}, Lorg/openaok/game/ThorBridge;->icon(II[I[I)I

    move-result p1

    if-lez p1, :cond_2

    .line 243
    iget-object p1, p0, Lorg/openaok/game/ThorDeck;->iconWh:[I

    const/4 p2, 0x0

    aget v0, p1, p2

    const/4 v3, 0x1

    aget p1, p1, v3

    sget-object v4, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v0, p1, v4}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v5

    .line 244
    iget-object v6, p0, Lorg/openaok/game/ThorDeck;->iconBuf:[I

    iget-object p1, p0, Lorg/openaok/game/ThorDeck;->iconWh:[I

    aget v8, p1, p2

    const/4 v10, 0x0

    aget v12, p1, v3

    const/4 v7, 0x0

    const/4 v9, 0x0

    move v11, v8

    invoke-virtual/range {v5 .. v12}, Landroid/graphics/Bitmap;->setPixels([IIIIIII)V

    move-object v0, v5

    .line 246
    :cond_2
    iget-object p0, p0, Lorg/openaok/game/ThorDeck;->icons:Ljava/util/Map;

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    invoke-interface {p0, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_3
    :goto_0
    return-object v0
.end method

.method private label(Landroid/graphics/Canvas;Ljava/lang/String;FFFILandroid/graphics/Paint$Align;Z)V
    .locals 1

    .line 334
    iget-object v0, p0, Lorg/openaok/game/ThorDeck;->text:Landroid/text/TextPaint;

    invoke-virtual {v0, p5}, Landroid/text/TextPaint;->setTextSize(F)V

    .line 335
    iget-object p5, p0, Lorg/openaok/game/ThorDeck;->text:Landroid/text/TextPaint;

    invoke-virtual {p5, p6}, Landroid/text/TextPaint;->setColor(I)V

    .line 336
    iget-object p5, p0, Lorg/openaok/game/ThorDeck;->text:Landroid/text/TextPaint;

    invoke-virtual {p5, p7}, Landroid/text/TextPaint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 337
    iget-object p5, p0, Lorg/openaok/game/ThorDeck;->text:Landroid/text/TextPaint;

    invoke-virtual {p5, p8}, Landroid/text/TextPaint;->setFakeBoldText(Z)V

    .line 338
    iget-object p0, p0, Lorg/openaok/game/ThorDeck;->text:Landroid/text/TextPaint;

    invoke-virtual {p1, p2, p3, p4, p0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method private loadArt(I)V
    .locals 4

    .line 219
    iget v0, p0, Lorg/openaok/game/ThorDeck;->artCiv:I

    if-ne p1, v0, :cond_0

    goto :goto_0

    .line 220
    :cond_0
    iput p1, p0, Lorg/openaok/game/ThorDeck;->artCiv:I

    const/4 v0, 0x0

    .line 221
    iput-object v0, p0, Lorg/openaok/game/ThorDeck;->art:Landroid/graphics/Bitmap;

    .line 222
    iput-object v0, p0, Lorg/openaok/game/ThorDeck;->stoneShader:Landroid/graphics/BitmapShader;

    const/high16 v0, 0x140000

    .line 223
    new-array v0, v0, [I

    const/16 v1, 0xc

    const/4 v2, 0x1

    sub-int/2addr p1, v2

    .line 224
    invoke-static {v1, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v1, 0x0

    invoke-static {v1, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    const v3, 0xc7c5

    add-int/2addr p1, v3

    iget-object v3, p0, Lorg/openaok/game/ThorDeck;->iconWh:[I

    invoke-static {p1, v1, v0, v3}, Lorg/openaok/game/ThorBridge;->icon(II[I[I)I

    move-result p1

    if-lez p1, :cond_2

    iget-object p1, p0, Lorg/openaok/game/ThorDeck;->iconWh:[I

    aget v1, p1, v1

    const/16 v3, 0x500

    if-ne v1, v3, :cond_2

    aget p1, p1, v2

    const/16 v1, 0x400

    if-eq p1, v1, :cond_1

    goto :goto_0

    .line 228
    :cond_1
    sget-object p1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v0, v3, v1, p1}, Landroid/graphics/Bitmap;->createBitmap([IIILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object p1

    iput-object p1, p0, Lorg/openaok/game/ThorDeck;->art:Landroid/graphics/Bitmap;

    .line 229
    sget-object v0, Lorg/openaok/game/ThorDeck;->ART_STONE:Landroid/graphics/Rect;

    iget v1, v0, Landroid/graphics/Rect;->left:I

    iget v2, v0, Landroid/graphics/Rect;->top:I

    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v3

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v0

    invoke-static {p1, v1, v2, v3, v0}, Landroid/graphics/Bitmap;->createBitmap(Landroid/graphics/Bitmap;IIII)Landroid/graphics/Bitmap;

    move-result-object p1

    iput-object p1, p0, Lorg/openaok/game/ThorDeck;->stone:Landroid/graphics/Bitmap;

    .line 230
    new-instance p1, Landroid/graphics/BitmapShader;

    iget-object v0, p0, Lorg/openaok/game/ThorDeck;->stone:Landroid/graphics/Bitmap;

    sget-object v1, Landroid/graphics/Shader$TileMode;->MIRROR:Landroid/graphics/Shader$TileMode;

    sget-object v2, Landroid/graphics/Shader$TileMode;->MIRROR:Landroid/graphics/Shader$TileMode;

    invoke-direct {p1, v0, v1, v2}, Landroid/graphics/BitmapShader;-><init>(Landroid/graphics/Bitmap;Landroid/graphics/Shader$TileMode;Landroid/graphics/Shader$TileMode;)V

    iput-object p1, p0, Lorg/openaok/game/ThorDeck;->stoneShader:Landroid/graphics/BitmapShader;

    .line 231
    new-instance p1, Landroid/graphics/Matrix;

    invoke-direct {p1}, Landroid/graphics/Matrix;-><init>()V

    const/high16 v0, 0x40200000    # 2.5f

    .line 232
    invoke-virtual {p1, v0, v0}, Landroid/graphics/Matrix;->setScale(FF)V

    .line 233
    iget-object p0, p0, Lorg/openaok/game/ThorDeck;->stoneShader:Landroid/graphics/BitmapShader;

    invoke-virtual {p0, p1}, Landroid/graphics/BitmapShader;->setLocalMatrix(Landroid/graphics/Matrix;)V

    :cond_2
    :goto_0
    return-void
.end method

.method private measure(F)Landroid/text/TextPaint;
    .locals 1

    .line 481
    iget-object v0, p0, Lorg/openaok/game/ThorDeck;->text:Landroid/text/TextPaint;

    invoke-virtual {v0, p1}, Landroid/text/TextPaint;->setTextSize(F)V

    .line 482
    iget-object p0, p0, Lorg/openaok/game/ThorDeck;->text:Landroid/text/TextPaint;

    return-object p0
.end method

.method private panel(Landroid/graphics/Canvas;Landroid/graphics/RectF;I)V
    .locals 9

    .line 315
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 316
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    iget-object v3, p0, Lorg/openaok/game/ThorDeck;->art:Landroid/graphics/Bitmap;

    if-eqz v3, :cond_1

    const v3, -0xd9dde5

    if-ne p3, v3, :cond_0

    const v3, -0x2fb9c5da

    goto :goto_0

    :cond_0
    const/high16 v3, -0x50000000

    goto :goto_0

    :cond_1
    move v3, p3

    :goto_0
    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 317
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    const/high16 v3, 0x40c00000    # 6.0f

    invoke-virtual {p1, p2, v3, v3, v2}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 318
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->stroke:Landroid/graphics/Paint;

    const/high16 v4, 0x40000000    # 2.0f

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 319
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->art:Landroid/graphics/Bitmap;

    if-nez v2, :cond_2

    .line 320
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->stroke:Landroid/graphics/Paint;

    const v4, -0xc5ccd8

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 321
    iget-object v0, p0, Lorg/openaok/game/ThorDeck;->stroke:Landroid/graphics/Paint;

    invoke-virtual {p1, p2, v3, v3, v0}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    return-void

    .line 325
    :cond_2
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->stroke:Landroid/graphics/Paint;

    const v3, -0x4765a6

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 326
    iget v2, p2, Landroid/graphics/RectF;->left:F

    const/high16 v7, 0x40400000    # 3.0f

    add-float/2addr v2, v7

    iget v3, p2, Landroid/graphics/RectF;->top:F

    const/high16 v8, 0x3f800000    # 1.0f

    add-float/2addr v3, v8

    iget v4, p2, Landroid/graphics/RectF;->right:F

    sub-float/2addr v4, v7

    iget v5, p2, Landroid/graphics/RectF;->top:F

    add-float/2addr v5, v8

    iget-object v6, p0, Lorg/openaok/game/ThorDeck;->stroke:Landroid/graphics/Paint;

    move-object v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 327
    iget v1, p2, Landroid/graphics/RectF;->left:F

    add-float v2, v1, v8

    iget v1, p2, Landroid/graphics/RectF;->top:F

    add-float v3, v1, v7

    iget v1, p2, Landroid/graphics/RectF;->left:F

    add-float v4, v1, v8

    iget v1, p2, Landroid/graphics/RectF;->bottom:F

    sub-float v5, v1, v7

    iget-object v6, p0, Lorg/openaok/game/ThorDeck;->stroke:Landroid/graphics/Paint;

    move-object v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 328
    iget-object v1, p0, Lorg/openaok/game/ThorDeck;->stroke:Landroid/graphics/Paint;

    const v2, -0xe5ebf4

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 329
    iget v1, p2, Landroid/graphics/RectF;->left:F

    add-float v2, v1, v7

    iget v1, p2, Landroid/graphics/RectF;->bottom:F

    sub-float v3, v1, v8

    iget v1, p2, Landroid/graphics/RectF;->right:F

    sub-float v4, v1, v7

    iget v1, p2, Landroid/graphics/RectF;->bottom:F

    sub-float v5, v1, v8

    iget-object v6, p0, Lorg/openaok/game/ThorDeck;->stroke:Landroid/graphics/Paint;

    move-object v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 330
    iget v1, p2, Landroid/graphics/RectF;->right:F

    sub-float/2addr v1, v8

    iget v2, p2, Landroid/graphics/RectF;->top:F

    add-float/2addr v2, v7

    iget v3, p2, Landroid/graphics/RectF;->right:F

    sub-float/2addr v3, v8

    iget v4, p2, Landroid/graphics/RectF;->bottom:F

    sub-float/2addr v4, v7

    iget-object v5, p0, Lorg/openaok/game/ThorDeck;->stroke:Landroid/graphics/Paint;

    move-object v0, p1

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    return-void
.end method

.method private pressGame(I)V
    .locals 3

    const/4 p0, 0x0

    if-eqz p1, :cond_4

    const/4 v0, 0x1

    if-eq p1, v0, :cond_3

    const/4 v0, 0x2

    const/16 v1, 0x10

    if-eq p1, v0, :cond_2

    const/4 v0, 0x3

    const/4 v2, 0x7

    if-eq p1, v0, :cond_1

    const/4 v0, 0x4

    if-eq p1, v0, :cond_0

    return-void

    .line 637
    :cond_0
    invoke-static {v2, p0, p0}, Lorg/openaok/game/ThorBridge;->push(III)V

    return-void

    .line 636
    :cond_1
    invoke-static {v1, v2, p0}, Lorg/openaok/game/ThorBridge;->push(III)V

    return-void

    :cond_2
    const/4 p1, 0x6

    .line 635
    invoke-static {v1, p1, p0}, Lorg/openaok/game/ThorBridge;->push(III)V

    return-void

    :cond_3
    const/16 p1, 0xb

    .line 634
    invoke-static {p1, p0, p0}, Lorg/openaok/game/ThorBridge;->push(III)V

    return-void

    :cond_4
    const/16 p1, 0xa

    .line 633
    invoke-static {p1, p0, p0}, Lorg/openaok/game/ThorBridge;->push(III)V

    return-void
.end method

.method private pushMap(FFZ)V
    .locals 6

    .line 796
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    if-nez p3, :cond_0

    .line 797
    iget-wide v2, p0, Lorg/openaok/game/ThorDeck;->lastMapPush:J

    sub-long v2, v0, v2

    const-wide/16 v4, 0x21

    cmp-long p3, v2, v4

    if-gez p3, :cond_0

    return-void

    .line 798
    :cond_0
    iput-wide v0, p0, Lorg/openaok/game/ThorDeck;->lastMapPush:J

    .line 799
    iget-object p3, p0, Lorg/openaok/game/ThorDeck;->mapArea:Landroid/graphics/RectF;

    iget p3, p3, Landroid/graphics/RectF;->left:F

    sub-float/2addr p1, p3

    iget-object p3, p0, Lorg/openaok/game/ThorDeck;->mapArea:Landroid/graphics/RectF;

    invoke-virtual {p3}, Landroid/graphics/RectF;->width()F

    move-result p3

    div-float/2addr p1, p3

    iget-object p3, p0, Lorg/openaok/game/ThorDeck;->mapArea:Landroid/graphics/RectF;

    iget p3, p3, Landroid/graphics/RectF;->top:F

    sub-float/2addr p2, p3

    iget-object p0, p0, Lorg/openaok/game/ThorDeck;->mapArea:Landroid/graphics/RectF;

    invoke-virtual {p0}, Landroid/graphics/RectF;->height()F

    move-result p0

    div-float/2addr p2, p0

    const p0, 0x3f7ff972    # 0.9999f

    .line 800
    invoke-static {p0, p1}, Ljava/lang/Math;->min(FF)F

    move-result p1

    const/4 p3, 0x0

    invoke-static {p3, p1}, Ljava/lang/Math;->max(FF)F

    move-result p1

    .line 801
    invoke-static {p0, p2}, Ljava/lang/Math;->min(FF)F

    move-result p0

    invoke-static {p3, p0}, Ljava/lang/Math;->max(FF)F

    move-result p0

    const/high16 p2, 0x47800000    # 65536.0f

    mul-float/2addr p1, p2

    float-to-int p1, p1

    mul-float/2addr p0, p2

    float-to-int p0, p0

    const/4 p2, 0x2

    .line 802
    invoke-static {p2, p1, p0}, Lorg/openaok/game/ThorBridge;->push(III)V

    return-void
.end method

.method private refresh()V
    .locals 12

    const/4 v0, 0x0

    .line 182
    :try_start_0
    iget-object v1, p0, Lorg/openaok/game/ThorDeck;->snap:[I

    invoke-static {v1}, Lorg/openaok/game/ThorBridge;->snapshot([I)I

    move-result v1
    :try_end_0
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move v1, v0

    .line 186
    :goto_0
    iput v1, p0, Lorg/openaok/game/ThorDeck;->snapLen:I

    const/16 v2, 0x26

    const/4 v3, 0x1

    if-le v1, v2, :cond_0

    .line 187
    iget-object v1, p0, Lorg/openaok/game/ThorDeck;->snap:[I

    aget v1, v1, v0

    const/16 v2, 0x5dc

    if-ge v1, v2, :cond_0

    invoke-direct {p0, v3}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v1

    if-ne v1, v3, :cond_0

    move v1, v3

    goto :goto_1

    :cond_0
    move v1, v0

    :goto_1
    iput-boolean v1, p0, Lorg/openaok/game/ThorDeck;->inGame:Z

    if-nez v1, :cond_1

    return-void

    :cond_1
    const/16 v1, 0x14

    .line 189
    invoke-direct {p0, v1}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v2

    iget v4, p0, Lorg/openaok/game/ThorDeck;->mapSerial:I

    if-eq v2, v4, :cond_4

    .line 190
    invoke-direct {p0, v1}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v1

    iput v1, p0, Lorg/openaok/game/ThorDeck;->mapSerial:I

    const/16 v1, 0x15

    .line 191
    invoke-direct {p0, v1}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v7

    const/16 v1, 0x16

    invoke-direct {p0, v1}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v11

    if-lez v7, :cond_4

    if-lez v11, :cond_4

    mul-int v1, v7, v11

    .line 192
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->mapPx:[I

    array-length v4, v2

    if-gt v1, v4, :cond_4

    invoke-static {v2}, Lorg/openaok/game/ThorBridge;->minimap([I)I

    move-result v2

    if-ne v2, v1, :cond_4

    .line 193
    iget-object v1, p0, Lorg/openaok/game/ThorDeck;->mapBitmap:Landroid/graphics/Bitmap;

    if-eqz v1, :cond_2

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v1

    if-ne v1, v7, :cond_2

    iget-object v1, p0, Lorg/openaok/game/ThorDeck;->mapBitmap:Landroid/graphics/Bitmap;

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v1

    if-eq v1, v11, :cond_3

    .line 194
    :cond_2
    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v7, v11, v1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v1

    iput-object v1, p0, Lorg/openaok/game/ThorDeck;->mapBitmap:Landroid/graphics/Bitmap;

    .line 196
    :cond_3
    iget-object v4, p0, Lorg/openaok/game/ThorDeck;->mapBitmap:Landroid/graphics/Bitmap;

    iget-object v5, p0, Lorg/openaok/game/ThorDeck;->mapPx:[I

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v6, 0x0

    move v10, v7

    invoke-virtual/range {v4 .. v11}, Landroid/graphics/Bitmap;->setPixels([IIIIIII)V

    .line 199
    :cond_4
    invoke-static {v0, v0}, Lorg/openaok/game/ThorBridge;->text(II)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lorg/openaok/game/ThorDeck;->ageName:Ljava/lang/String;

    .line 200
    invoke-static {v3, v0}, Lorg/openaok/game/ThorBridge;->text(II)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lorg/openaok/game/ThorDeck;->nextAge:Ljava/lang/String;

    const/4 v1, 0x2

    .line 201
    invoke-static {v1, v0}, Lorg/openaok/game/ThorBridge;->text(II)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lorg/openaok/game/ThorDeck;->selName:Ljava/lang/String;

    const/16 v1, 0x12

    .line 202
    invoke-direct {p0, v1}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v1

    const/16 v2, 0xf

    invoke-static {v2, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    move v3, v0

    :goto_2
    if-ge v3, v1, :cond_5

    .line 203
    iget-object v4, p0, Lorg/openaok/game/ThorDeck;->labels:[Ljava/lang/String;

    const/4 v5, 0x5

    invoke-static {v5, v3}, Lorg/openaok/game/ThorBridge;->text(II)Ljava/lang/String;

    move-result-object v5

    aput-object v5, v4, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    :cond_5
    const/16 v1, 0x25

    .line 204
    invoke-direct {p0, v1}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v1

    invoke-static {v2, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    iput v1, p0, Lorg/openaok/game/ThorDeck;->goToCount:I

    .line 205
    :goto_3
    iget v1, p0, Lorg/openaok/game/ThorDeck;->goToCount:I

    if-ge v0, v1, :cond_6

    .line 206
    iget-object v1, p0, Lorg/openaok/game/ThorDeck;->goToEntry:[I

    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->snap:[I

    invoke-direct {p0, v0}, Lorg/openaok/game/ThorDeck;->goToBase(I)I

    move-result v3

    aget v2, v2, v3

    aput v2, v1, v0

    .line 207
    iget-object v1, p0, Lorg/openaok/game/ThorDeck;->goToName:[Ljava/lang/String;

    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->goToEntry:[I

    aget v2, v2, v0

    const/4 v3, 0x6

    invoke-static {v3, v2}, Lorg/openaok/game/ThorBridge;->text(II)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_6
    const/16 v0, 0x1f

    .line 209
    invoke-direct {p0, v0}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result v0

    invoke-direct {p0, v0}, Lorg/openaok/game/ThorDeck;->loadArt(I)V

    return-void
.end method

.method private showHelp(I)V
    .locals 4

    add-int/lit8 p1, p1, 0x1

    .line 274
    invoke-direct {p0, p1}, Lorg/openaok/game/ThorDeck;->commandAt(I)I

    move-result p1

    if-gez p1, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x3

    .line 276
    invoke-static {v0, p1}, Lorg/openaok/game/ThorBridge;->text(II)Ljava/lang/String;

    move-result-object p1

    .line 277
    const-string v0, "<b>"

    const-string v1, ""

    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "<i>"

    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "</b>"

    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "</i>"

    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0xa

    const/16 v1, 0x20

    .line 278
    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lorg/openaok/game/ThorDeck;->help:Ljava/lang/String;

    .line 279
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    const-wide/16 v2, 0x1770

    add-long/2addr v0, v2

    iput-wide v0, p0, Lorg/openaok/game/ThorDeck;->helpUntil:J

    return-void
.end method

.method private word(I)Ljava/lang/String;
    .locals 2

    if-gez p1, :cond_0

    .line 251
    const-string p0, ""

    return-object p0

    .line 252
    :cond_0
    iget-object v0, p0, Lorg/openaok/game/ThorDeck;->words:Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_1

    const/4 v0, 0x4

    .line 254
    invoke-static {v0, p1}, Lorg/openaok/game/ThorBridge;->text(II)Ljava/lang/String;

    move-result-object v0

    .line 255
    iget-object p0, p0, Lorg/openaok/game/ThorDeck;->words:Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {p0, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    return-object v0
.end method


# virtual methods
.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 7

    .line 291
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 292
    iget v0, p0, Lorg/openaok/game/ThorDeck;->s:F

    invoke-virtual {p1, v0, v0}, Landroid/graphics/Canvas;->scale(FF)V

    .line 293
    iget-boolean v0, p0, Lorg/openaok/game/ThorDeck;->inGame:Z

    if-nez v0, :cond_0

    .line 294
    invoke-direct {p0, p1}, Lorg/openaok/game/ThorDeck;->drawIdle(Landroid/graphics/Canvas;)V

    move-object v1, p1

    goto :goto_1

    .line 296
    :cond_0
    iget-object v0, p0, Lorg/openaok/game/ThorDeck;->stoneShader:Landroid/graphics/BitmapShader;

    if-eqz v0, :cond_1

    .line 297
    iget-object v1, p0, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 298
    iget-object v0, p0, Lorg/openaok/game/ThorDeck;->header:Landroid/graphics/RectF;

    iget v3, v0, Landroid/graphics/RectF;->bottom:F

    const/high16 v5, 0x44870000    # 1080.0f

    iget-object v6, p0, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    const/4 v2, 0x0

    const/high16 v4, 0x449b0000    # 1240.0f

    move-object v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 299
    iget-object p1, p0, Lorg/openaok/game/ThorDeck;->fill:Landroid/graphics/Paint;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    goto :goto_0

    :cond_1
    move-object v1, p1

    .line 301
    :goto_0
    invoke-direct {p0, v1}, Lorg/openaok/game/ThorDeck;->drawHeader(Landroid/graphics/Canvas;)V

    .line 302
    invoke-direct {p0, v1}, Lorg/openaok/game/ThorDeck;->drawMinimap(Landroid/graphics/Canvas;)V

    .line 303
    invoke-direct {p0, v1}, Lorg/openaok/game/ThorDeck;->drawSelection(Landroid/graphics/Canvas;)V

    .line 304
    invoke-direct {p0, v1}, Lorg/openaok/game/ThorDeck;->drawButtons(Landroid/graphics/Canvas;)V

    .line 305
    invoke-direct {p0, v1}, Lorg/openaok/game/ThorDeck;->drawGroups(Landroid/graphics/Canvas;)V

    .line 306
    invoke-direct {p0, v1}, Lorg/openaok/game/ThorDeck;->drawTabs(Landroid/graphics/Canvas;)V

    .line 307
    iget p1, p0, Lorg/openaok/game/ThorDeck;->tab:I

    if-nez p1, :cond_2

    invoke-direct {p0, v1}, Lorg/openaok/game/ThorDeck;->drawGrid(Landroid/graphics/Canvas;)V

    goto :goto_1

    :cond_2
    const/4 v0, 0x1

    if-ne p1, v0, :cond_3

    .line 308
    invoke-direct {p0, v1}, Lorg/openaok/game/ThorDeck;->drawGoTo(Landroid/graphics/Canvas;)V

    goto :goto_1

    .line 309
    :cond_3
    invoke-direct {p0, v1}, Lorg/openaok/game/ThorDeck;->drawGame(Landroid/graphics/Canvas;)V

    .line 311
    :goto_1
    invoke-virtual {v1}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method

.method protected onSizeChanged(IIII)V
    .locals 0

    int-to-float p1, p1

    const/high16 p3, 0x449b0000    # 1240.0f

    div-float/2addr p1, p3

    int-to-float p2, p2

    const/high16 p3, 0x44870000    # 1080.0f

    div-float/2addr p2, p3

    .line 286
    invoke-static {p1, p2}, Ljava/lang/Math;->min(FF)F

    move-result p1

    iput p1, p0, Lorg/openaok/game/ThorDeck;->s:F

    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 13

    .line 684
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    iget v1, p0, Lorg/openaok/game/ThorDeck;->s:F

    div-float/2addr v0, v1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    iget v2, p0, Lorg/openaok/game/ThorDeck;->s:F

    div-float/2addr v1, v2

    .line 685
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result p1

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v4, -0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eqz p1, :cond_14

    const/4 v7, 0x2

    if-eq p1, v6, :cond_3

    if-eq p1, v7, :cond_1

    if-eq p1, v2, :cond_0

    return v6

    .line 783
    :cond_0
    iput v4, p0, Lorg/openaok/game/ThorDeck;->pressedTile:I

    .line 784
    iput v4, p0, Lorg/openaok/game/ThorDeck;->pressedButton:I

    .line 785
    iput v4, p0, Lorg/openaok/game/ThorDeck;->pressedGroup:I

    .line 786
    iput v4, p0, Lorg/openaok/game/ThorDeck;->pressedSmall:I

    .line 787
    iput v4, p0, Lorg/openaok/game/ThorDeck;->pressedTab:I

    .line 788
    iput-boolean v5, p0, Lorg/openaok/game/ThorDeck;->mapDrag:Z

    return v6

    .line 722
    :cond_1
    iget-boolean p1, p0, Lorg/openaok/game/ThorDeck;->mapDrag:Z

    if-eqz p1, :cond_2

    invoke-direct {p0, v0, v1, v5}, Lorg/openaok/game/ThorDeck;->pushMap(FFZ)V

    :cond_2
    return v6

    .line 725
    :cond_3
    iget-boolean p1, p0, Lorg/openaok/game/ThorDeck;->mapDrag:Z

    if-eqz p1, :cond_4

    .line 726
    invoke-direct {p0, v0, v1, v6}, Lorg/openaok/game/ThorDeck;->pushMap(FFZ)V

    goto/16 :goto_3

    .line 727
    :cond_4
    iget p1, p0, Lorg/openaok/game/ThorDeck;->pressedTile:I

    const-wide/16 v8, 0x0

    if-ltz p1, :cond_7

    iget-object v10, p0, Lorg/openaok/game/ThorDeck;->tiles:[Landroid/graphics/RectF;

    aget-object p1, v10, p1

    invoke-virtual {p1, v0, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result p1

    if-eqz p1, :cond_7

    iget-boolean p1, p0, Lorg/openaok/game/ThorDeck;->held:Z

    if-nez p1, :cond_7

    .line 728
    invoke-virtual {p0, v6}, Lorg/openaok/game/ThorDeck;->performHapticFeedback(I)Z

    .line 729
    iget p1, p0, Lorg/openaok/game/ThorDeck;->tab:I

    if-nez p1, :cond_5

    iget p1, p0, Lorg/openaok/game/ThorDeck;->pressedTile:I

    add-int/2addr p1, v6

    invoke-static {v6, p1, v5}, Lorg/openaok/game/ThorBridge;->push(III)V

    goto :goto_0

    :cond_5
    if-ne p1, v6, :cond_6

    .line 730
    iget-object p1, p0, Lorg/openaok/game/ThorDeck;->goToEntry:[I

    iget v0, p0, Lorg/openaok/game/ThorDeck;->pressedTile:I

    aget p1, p1, v0

    const/16 v0, 0xc

    invoke-static {v0, p1, v5}, Lorg/openaok/game/ThorBridge;->push(III)V

    goto :goto_0

    .line 731
    :cond_6
    iget p1, p0, Lorg/openaok/game/ThorDeck;->pressedTile:I

    invoke-direct {p0, p1}, Lorg/openaok/game/ThorDeck;->pressGame(I)V

    .line 732
    :goto_0
    iput-wide v8, p0, Lorg/openaok/game/ThorDeck;->helpUntil:J

    goto/16 :goto_3

    .line 733
    :cond_7
    iget p1, p0, Lorg/openaok/game/ThorDeck;->pressedGroup:I

    if-ltz p1, :cond_8

    iget-object v10, p0, Lorg/openaok/game/ThorDeck;->groups:[Landroid/graphics/RectF;

    aget-object p1, v10, p1

    invoke-virtual {p1, v0, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result p1

    if-eqz p1, :cond_8

    .line 734
    iget-boolean p1, p0, Lorg/openaok/game/ThorDeck;->held:Z

    if-nez p1, :cond_13

    .line 735
    invoke-virtual {p0, v6}, Lorg/openaok/game/ThorDeck;->performHapticFeedback(I)Z

    .line 736
    iget p1, p0, Lorg/openaok/game/ThorDeck;->pressedGroup:I

    add-int/2addr p1, v6

    const/16 v0, 0xd

    invoke-static {v0, p1, v5}, Lorg/openaok/game/ThorBridge;->push(III)V

    .line 737
    iget p1, p0, Lorg/openaok/game/ThorDeck;->pressedGroup:I

    add-int/lit8 p1, p1, 0x21

    invoke-direct {p0, p1}, Lorg/openaok/game/ThorDeck;->h(I)I

    move-result p1

    if-nez p1, :cond_13

    .line 738
    invoke-virtual {p0}, Lorg/openaok/game/ThorDeck;->getContext()Landroid/content/Context;

    move-result-object p1

    sget v0, Lorg/openaok/game/R$string;->deck_group_hint:I

    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lorg/openaok/game/ThorDeck;->help:Ljava/lang/String;

    .line 739
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    const-wide/16 v2, 0xfa0

    add-long/2addr v0, v2

    iput-wide v0, p0, Lorg/openaok/game/ThorDeck;->helpUntil:J

    goto/16 :goto_3

    .line 742
    :cond_8
    iget p1, p0, Lorg/openaok/game/ThorDeck;->pressedTab:I

    if-ltz p1, :cond_9

    iget-object v10, p0, Lorg/openaok/game/ThorDeck;->tabs:[Landroid/graphics/RectF;

    aget-object p1, v10, p1

    invoke-virtual {p1, v0, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result p1

    if-eqz p1, :cond_9

    .line 743
    iget p1, p0, Lorg/openaok/game/ThorDeck;->pressedTab:I

    iput p1, p0, Lorg/openaok/game/ThorDeck;->tab:I

    goto/16 :goto_3

    .line 744
    :cond_9
    iget p1, p0, Lorg/openaok/game/ThorDeck;->pressedSmall:I

    const/16 v10, 0x10

    const/16 v11, 0xa

    if-lt p1, v11, :cond_a

    iget-object v12, p0, Lorg/openaok/game/ThorDeck;->mapButtons:[Landroid/graphics/RectF;

    sub-int/2addr p1, v11

    aget-object p1, v12, p1

    invoke-virtual {p1, v0, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result p1

    if-eqz p1, :cond_a

    .line 745
    invoke-virtual {p0, v6}, Lorg/openaok/game/ThorDeck;->performHapticFeedback(I)Z

    const/4 p1, 0x5

    .line 746
    filled-new-array {v2, v3, p1, v5}, [I

    move-result-object p1

    .line 748
    iget v0, p0, Lorg/openaok/game/ThorDeck;->pressedSmall:I

    sub-int/2addr v0, v11

    aget p1, p1, v0

    invoke-static {v10, p1, v5}, Lorg/openaok/game/ThorBridge;->push(III)V

    goto/16 :goto_3

    .line 749
    :cond_a
    iget p1, p0, Lorg/openaok/game/ThorDeck;->pressedSmall:I

    const/16 v11, 0xf

    if-ltz p1, :cond_e

    if-ge p1, v3, :cond_e

    iget-object v12, p0, Lorg/openaok/game/ThorDeck;->small:[Landroid/graphics/RectF;

    aget-object p1, v12, p1

    invoke-virtual {p1, v0, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result p1

    if-eqz p1, :cond_e

    .line 750
    invoke-virtual {p0, v6}, Lorg/openaok/game/ThorDeck;->performHapticFeedback(I)Z

    .line 751
    iget p1, p0, Lorg/openaok/game/ThorDeck;->pressedSmall:I

    if-nez p1, :cond_b

    invoke-static {v10, v6, v5}, Lorg/openaok/game/ThorBridge;->push(III)V

    goto/16 :goto_3

    :cond_b
    if-ne p1, v6, :cond_c

    .line 752
    invoke-static {v10, v7, v5}, Lorg/openaok/game/ThorBridge;->push(III)V

    goto/16 :goto_3

    :cond_c
    if-ne p1, v2, :cond_d

    move p1, v6

    goto :goto_1

    :cond_d
    move p1, v4

    .line 753
    :goto_1
    invoke-static {v11, p1, v5}, Lorg/openaok/game/ThorBridge;->push(III)V

    goto :goto_3

    .line 754
    :cond_e
    iget p1, p0, Lorg/openaok/game/ThorDeck;->pressedButton:I

    if-ltz p1, :cond_11

    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->buttons:[Landroid/graphics/RectF;

    aget-object p1, v2, p1

    invoke-virtual {p1, v0, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result p1

    if-eqz p1, :cond_11

    .line 755
    invoke-virtual {p0, v6}, Lorg/openaok/game/ThorDeck;->performHapticFeedback(I)Z

    const/4 p1, 0x6

    .line 756
    new-array p1, p1, [I

    fill-array-data p1, :array_0

    .line 758
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    .line 759
    iget v2, p0, Lorg/openaok/game/ThorDeck;->pressedButton:I

    if-ne v2, v3, :cond_f

    iget-wide v10, p0, Lorg/openaok/game/ThorDeck;->deleteArmedUntil:J

    cmp-long v7, v0, v10

    if-ltz v7, :cond_f

    const-wide/16 v2, 0xbb8

    add-long/2addr v0, v2

    .line 760
    iput-wide v0, p0, Lorg/openaok/game/ThorDeck;->deleteArmedUntil:J

    goto :goto_3

    :cond_f
    if-ne v2, v3, :cond_10

    .line 762
    iput-wide v8, p0, Lorg/openaok/game/ThorDeck;->deleteArmedUntil:J

    .line 763
    :cond_10
    aget p1, p1, v2

    invoke-static {p1, v5, v5}, Lorg/openaok/game/ThorBridge;->push(III)V

    goto :goto_3

    :cond_11
    move p1, v5

    :goto_2
    if-ge p1, v11, :cond_13

    .line 767
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->queueRects:[Landroid/graphics/RectF;

    aget-object v2, v2, p1

    invoke-virtual {v2}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_12

    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->queueRects:[Landroid/graphics/RectF;

    aget-object v2, v2, p1

    invoke-virtual {v2, v0, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v2

    if-eqz v2, :cond_12

    .line 768
    invoke-virtual {p0, v6}, Lorg/openaok/game/ThorDeck;->performHapticFeedback(I)Z

    .line 769
    iget-object v0, p0, Lorg/openaok/game/ThorDeck;->queueSlot:[I

    aget p1, v0, p1

    const/16 v0, 0x8

    invoke-static {v0, p1, v5}, Lorg/openaok/game/ThorBridge;->push(III)V

    goto :goto_3

    :cond_12
    add-int/lit8 p1, p1, 0x1

    goto :goto_2

    .line 774
    :cond_13
    :goto_3
    iput v4, p0, Lorg/openaok/game/ThorDeck;->pressedTile:I

    .line 775
    iput v4, p0, Lorg/openaok/game/ThorDeck;->pressedButton:I

    .line 776
    iput v4, p0, Lorg/openaok/game/ThorDeck;->pressedGroup:I

    .line 777
    iput v4, p0, Lorg/openaok/game/ThorDeck;->pressedSmall:I

    .line 778
    iput v4, p0, Lorg/openaok/game/ThorDeck;->pressedTab:I

    .line 779
    iput-boolean v5, p0, Lorg/openaok/game/ThorDeck;->mapDrag:Z

    .line 780
    invoke-virtual {p0}, Lorg/openaok/game/ThorDeck;->invalidate()V

    return v6

    .line 687
    :cond_14
    iput v4, p0, Lorg/openaok/game/ThorDeck;->pressedTile:I

    .line 688
    iput v4, p0, Lorg/openaok/game/ThorDeck;->pressedButton:I

    .line 689
    iput v4, p0, Lorg/openaok/game/ThorDeck;->pressedGroup:I

    .line 690
    iput v4, p0, Lorg/openaok/game/ThorDeck;->pressedSmall:I

    .line 691
    iput v4, p0, Lorg/openaok/game/ThorDeck;->pressedTab:I

    .line 692
    iput-boolean v5, p0, Lorg/openaok/game/ThorDeck;->held:Z

    .line 693
    iput-boolean v5, p0, Lorg/openaok/game/ThorDeck;->mapDrag:Z

    .line 694
    iget-boolean p1, p0, Lorg/openaok/game/ThorDeck;->inGame:Z

    if-nez p1, :cond_15

    return v6

    .line 695
    :cond_15
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v7

    iput-wide v7, p0, Lorg/openaok/game/ThorDeck;->pressedAt:J

    move p1, v5

    :goto_4
    if-ge p1, v3, :cond_19

    .line 697
    iget-object v4, p0, Lorg/openaok/game/ThorDeck;->groups:[Landroid/graphics/RectF;

    aget-object v4, v4, p1

    invoke-virtual {v4, v0, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v4

    if-eqz v4, :cond_16

    iput p1, p0, Lorg/openaok/game/ThorDeck;->pressedGroup:I

    .line 698
    :cond_16
    iget-object v4, p0, Lorg/openaok/game/ThorDeck;->small:[Landroid/graphics/RectF;

    aget-object v4, v4, p1

    invoke-virtual {v4, v0, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v4

    if-eqz v4, :cond_17

    iput p1, p0, Lorg/openaok/game/ThorDeck;->pressedSmall:I

    .line 699
    :cond_17
    iget-object v4, p0, Lorg/openaok/game/ThorDeck;->mapButtons:[Landroid/graphics/RectF;

    aget-object v4, v4, p1

    invoke-virtual {v4, v0, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v4

    if-eqz v4, :cond_18

    add-int/lit8 v4, p1, 0xa

    iput v4, p0, Lorg/openaok/game/ThorDeck;->pressedSmall:I

    :cond_18
    add-int/lit8 p1, p1, 0x1

    goto :goto_4

    :cond_19
    move p1, v5

    :goto_5
    if-ge p1, v2, :cond_1b

    .line 702
    iget-object v3, p0, Lorg/openaok/game/ThorDeck;->tabs:[Landroid/graphics/RectF;

    aget-object v3, v3, p1

    invoke-virtual {v3, v0, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v3

    if-eqz v3, :cond_1a

    iput p1, p0, Lorg/openaok/game/ThorDeck;->pressedTab:I

    :cond_1a
    add-int/lit8 p1, p1, 0x1

    goto :goto_5

    .line 704
    :cond_1b
    iget-object p1, p0, Lorg/openaok/game/ThorDeck;->mapArea:Landroid/graphics/RectF;

    invoke-virtual {p1, v0, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result p1

    if-eqz p1, :cond_1c

    .line 705
    iput-boolean v6, p0, Lorg/openaok/game/ThorDeck;->mapDrag:Z

    .line 706
    invoke-direct {p0, v0, v1, v6}, Lorg/openaok/game/ThorDeck;->pushMap(FFZ)V

    return v6

    :cond_1c
    move p1, v5

    .line 709
    :goto_6
    iget-object v2, p0, Lorg/openaok/game/ThorDeck;->tiles:[Landroid/graphics/RectF;

    array-length v2, v2

    if-ge p1, v2, :cond_21

    .line 710
    iget v2, p0, Lorg/openaok/game/ThorDeck;->tab:I

    if-nez v2, :cond_1e

    add-int/lit8 v2, p1, 0x1

    invoke-direct {p0, v2}, Lorg/openaok/game/ThorDeck;->commandAt(I)I

    move-result v2

    if-ltz v2, :cond_1d

    :goto_7
    move v2, v6

    goto :goto_8

    :cond_1d
    move v2, v5

    goto :goto_8

    :cond_1e
    if-ne v2, v6, :cond_1f

    iget v2, p0, Lorg/openaok/game/ThorDeck;->goToCount:I

    if-ge p1, v2, :cond_1d

    goto :goto_7

    :cond_1f
    sget-object v2, Lorg/openaok/game/ThorDeck;->GAME_NAMES:[I

    array-length v2, v2

    if-ge p1, v2, :cond_1d

    goto :goto_7

    .line 711
    :goto_8
    iget-object v3, p0, Lorg/openaok/game/ThorDeck;->tiles:[Landroid/graphics/RectF;

    aget-object v3, v3, p1

    invoke-virtual {v3, v0, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v3

    if-eqz v3, :cond_20

    if-eqz v2, :cond_20

    .line 712
    iput p1, p0, Lorg/openaok/game/ThorDeck;->pressedTile:I

    .line 713
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    iput-wide v2, p0, Lorg/openaok/game/ThorDeck;->pressedAt:J

    :cond_20
    add-int/lit8 p1, p1, 0x1

    goto :goto_6

    .line 716
    :cond_21
    :goto_9
    iget-object p1, p0, Lorg/openaok/game/ThorDeck;->buttons:[Landroid/graphics/RectF;

    array-length v2, p1

    if-ge v5, v2, :cond_23

    .line 717
    aget-object p1, p1, v5

    invoke-virtual {p1, v0, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result p1

    if-eqz p1, :cond_22

    iput v5, p0, Lorg/openaok/game/ThorDeck;->pressedButton:I

    :cond_22
    add-int/lit8 v5, v5, 0x1

    goto :goto_9

    .line 719
    :cond_23
    invoke-virtual {p0}, Lorg/openaok/game/ThorDeck;->invalidate()V

    return v6

    :array_0
    .array-data 4
        0x3
        0x4
        0x5
        0x6
        0x9
        0x7
    .end array-data
.end method

.method start()V
    .locals 1

    .line 163
    iget-boolean v0, p0, Lorg/openaok/game/ThorDeck;->running:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    .line 164
    iput-boolean v0, p0, Lorg/openaok/game/ThorDeck;->running:Z

    .line 165
    iget-object v0, p0, Lorg/openaok/game/ThorDeck;->handler:Landroid/os/Handler;

    iget-object p0, p0, Lorg/openaok/game/ThorDeck;->poll:Ljava/lang/Runnable;

    invoke-virtual {v0, p0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method stop()V
    .locals 1

    const/4 v0, 0x0

    .line 169
    iput-boolean v0, p0, Lorg/openaok/game/ThorDeck;->running:Z

    .line 170
    iget-object v0, p0, Lorg/openaok/game/ThorDeck;->handler:Landroid/os/Handler;

    iget-object p0, p0, Lorg/openaok/game/ThorDeck;->poll:Ljava/lang/Runnable;

    invoke-virtual {v0, p0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    return-void
.end method
