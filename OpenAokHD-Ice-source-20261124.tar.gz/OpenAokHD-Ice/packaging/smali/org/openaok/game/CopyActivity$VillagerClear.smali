.class public final Lorg/openaok/game/CopyActivity$VillagerClear;
.super Ljava/lang/Object;
.implements Ljava/lang/Runnable;

.field private final activity:Lorg/openaok/game/CopyActivity;

.method public constructor <init>(Lorg/openaok/game/CopyActivity;)V
    .registers 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    iput-object p1, p0, Lorg/openaok/game/CopyActivity$VillagerClear;->activity:Lorg/openaok/game/CopyActivity;
    return-void
.end method

.method public run()V
    .registers 3
    iget-object v0, p0, Lorg/openaok/game/CopyActivity$VillagerClear;->activity:Lorg/openaok/game/CopyActivity;
    iget-object v1, v0, Lorg/openaok/game/CopyActivity;->bubble:Landroid/widget/TextView;
    const-string v2, ""
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    const/16 v2, 0x8
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setVisibility(I)V
    iget-object v1, v0, Lorg/openaok/game/CopyActivity;->tail:Landroid/view/View;
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V
    return-void
.end method
