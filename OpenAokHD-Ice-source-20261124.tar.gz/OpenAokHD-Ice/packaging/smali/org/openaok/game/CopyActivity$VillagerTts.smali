.class public final Lorg/openaok/game/CopyActivity$VillagerTts;
.super Ljava/lang/Object;
.implements Landroid/speech/tts/TextToSpeech$OnInitListener;

.field private final activity:Lorg/openaok/game/CopyActivity;

.method public constructor <init>(Lorg/openaok/game/CopyActivity;)V
    .registers 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    iput-object p1, p0, Lorg/openaok/game/CopyActivity$VillagerTts;->activity:Lorg/openaok/game/CopyActivity;
    new-instance v0, Landroid/speech/tts/TextToSpeech;
    invoke-direct {v0, p1, p0}, Landroid/speech/tts/TextToSpeech;-><init>(Landroid/content/Context;Landroid/speech/tts/TextToSpeech$OnInitListener;)V
    iput-object v0, p1, Lorg/openaok/game/CopyActivity;->tts:Landroid/speech/tts/TextToSpeech;
    return-void
.end method

.method public onInit(I)V
    .registers 6
    if-eqz p1, :done
    :try_start
    iget-object v0, p0, Lorg/openaok/game/CopyActivity$VillagerTts;->activity:Lorg/openaok/game/CopyActivity;
    iget-object v0, v0, Lorg/openaok/game/CopyActivity;->tts:Landroid/speech/tts/TextToSpeech;
    sget-object v1, Ljava/util/Locale;->CHINA:Ljava/util/Locale;
    invoke-virtual {v0, v1}, Landroid/speech/tts/TextToSpeech;->setLanguage(Ljava/util/Locale;)I
    const-string v1, "伐木工"
    const/4 v2, 0x0
    const/4 v3, 0x0
    invoke-virtual {v0, v1, v2, v3}, Landroid/speech/tts/TextToSpeech;->speak(Ljava/lang/CharSequence;ILjava/util/HashMap;)I
    :try_end
    .catch Ljava/lang/Exception; {:try_start .. :try_end} :catch
    :done
    return-void
    :catch
    move-exception v0
    return-void
.end method
