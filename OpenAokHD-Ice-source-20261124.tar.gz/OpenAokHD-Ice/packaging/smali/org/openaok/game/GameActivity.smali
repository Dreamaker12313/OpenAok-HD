.class public Lorg/openaok/game/GameActivity;
.super Lorg/libsdl/app/SDLActivity;
.source "GameActivity.java"

# interfaces
.implements Landroid/hardware/input/InputManager$InputDeviceListener;


# static fields
.field public static final EXTRA_SINGLE:Ljava/lang/String; = "single"


# instance fields
.field private screens:Lorg/openaok/game/ThorScreens;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 25
    invoke-direct {p0}, Lorg/libsdl/app/SDLActivity;-><init>()V

    return-void
.end method

.method private inputs()Landroid/hardware/input/InputManager;
    .locals 1

    .line 90
    const-string v0, "input"

    invoke-virtual {p0, v0}, Lorg/openaok/game/GameActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/hardware/input/InputManager;

    return-object p0
.end method

.method static synthetic lambda$onCreate$0()V
    .locals 1

    const/4 v0, 0x4

    .line 54
    invoke-static {v0}, Lorg/openaok/game/GameActivity;->onNativeKeyDown(I)V

    .line 55
    invoke-static {v0}, Lorg/openaok/game/GameActivity;->onNativeKeyUp(I)V

    return-void
.end method

.method private static native nativeMouseAttached(Z)V
.end method

.method private reportMouse()V
    .locals 5

    .line 95
    invoke-static {}, Landroid/view/InputDevice;->getDeviceIds()[I

    move-result-object p0

    array-length v0, p0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v1, v0, :cond_1

    aget v3, p0, v1

    .line 96
    invoke-static {v3}, Landroid/view/InputDevice;->getDevice(I)Landroid/view/InputDevice;

    move-result-object v3

    if-eqz v3, :cond_0

    .line 97
    invoke-virtual {v3}, Landroid/view/InputDevice;->isVirtual()Z

    move-result v4

    if-nez v4, :cond_0

    const/16 v4, 0x2002

    invoke-virtual {v3, v4}, Landroid/view/InputDevice;->supportsSource(I)Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 v2, 0x1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 102
    :cond_1
    :try_start_0
    invoke-static {v2}, Lorg/openaok/game/GameActivity;->nativeMouseAttached(Z)V
    :try_end_0
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method


# virtual methods
.method protected getLibraries()[Ljava/lang/String;
    .locals 2

    const/4 p0, 0x2

    .line 33
    new-array p0, p0, [Ljava/lang/String;

    const/4 v0, 0x0

    const-string v1, "SDL2"

    aput-object v1, p0, v0

    const/4 v0, 0x1

    const-string v1, "main"

    aput-object v1, p0, v0

    return-object p0
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2

    .line 38
    invoke-super {p0, p1}, Lorg/libsdl/app/SDLActivity;->onCreate(Landroid/os/Bundle;)V

    .line 41
    invoke-virtual {p0}, Lorg/openaok/game/GameActivity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const-string v0, "single"

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result p1

    if-nez p1, :cond_0

    invoke-static {p0}, Lorg/openaok/game/ThorScreens;->hasSecondScreen(Landroid/app/Activity;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    move p1, v1

    .line 43
    :goto_0
    :try_start_0
    invoke-static {p1}, Lorg/openaok/game/ThorBridge;->setDualScreen(Z)V
    :try_end_0
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move p1, v1

    :goto_1
    if-eqz p1, :cond_1

    .line 48
    new-instance p1, Lorg/openaok/game/ThorScreens;

    invoke-direct {p1, p0}, Lorg/openaok/game/ThorScreens;-><init>(Landroid/app/Activity;)V

    iput-object p1, p0, Lorg/openaok/game/GameActivity;->screens:Lorg/openaok/game/ThorScreens;

    .line 49
    invoke-virtual {p1}, Lorg/openaok/game/ThorScreens;->start()V

    .line 51
    :cond_1
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x21

    if-lt p1, v0, :cond_2

    .line 52
    invoke-virtual {p0}, Lorg/openaok/game/GameActivity;->getOnBackInvokedDispatcher()Landroid/window/OnBackInvokedDispatcher;

    move-result-object p0

    new-instance p1, Lorg/openaok/game/GameActivity$$ExternalSyntheticLambda0;

    invoke-direct {p1}, Lorg/openaok/game/GameActivity$$ExternalSyntheticLambda0;-><init>()V

    invoke-interface {p0, v1, p1}, Landroid/window/OnBackInvokedDispatcher;->registerOnBackInvokedCallback(ILandroid/window/OnBackInvokedCallback;)V

    :cond_2
    return-void
.end method

.method protected onDestroy()V
    .locals 1

    .line 62
    iget-object v0, p0, Lorg/openaok/game/GameActivity;->screens:Lorg/openaok/game/ThorScreens;

    if-eqz v0, :cond_0

    .line 63
    invoke-virtual {v0}, Lorg/openaok/game/ThorScreens;->stop()V

    const/4 v0, 0x0

    .line 64
    iput-object v0, p0, Lorg/openaok/game/GameActivity;->screens:Lorg/openaok/game/ThorScreens;

    .line 66
    :cond_0
    invoke-super {p0}, Lorg/libsdl/app/SDLActivity;->onDestroy()V

    return-void
.end method

.method public onInputDeviceAdded(I)V
    .locals 0

    .line 85
    invoke-direct {p0}, Lorg/openaok/game/GameActivity;->reportMouse()V

    return-void
.end method

.method public onInputDeviceChanged(I)V
    .locals 0

    .line 87
    invoke-direct {p0}, Lorg/openaok/game/GameActivity;->reportMouse()V

    return-void
.end method

.method public onInputDeviceRemoved(I)V
    .locals 0

    .line 86
    invoke-direct {p0}, Lorg/openaok/game/GameActivity;->reportMouse()V

    return-void
.end method

.method protected onPause()V
    .locals 1

    .line 80
    invoke-direct {p0}, Lorg/openaok/game/GameActivity;->inputs()Landroid/hardware/input/InputManager;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/hardware/input/InputManager;->unregisterInputDeviceListener(Landroid/hardware/input/InputManager$InputDeviceListener;)V

    .line 81
    iget-object v0, p0, Lorg/openaok/game/GameActivity;->screens:Lorg/openaok/game/ThorScreens;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lorg/openaok/game/ThorScreens;->pause()V

    .line 82
    :cond_0
    invoke-super {p0}, Lorg/libsdl/app/SDLActivity;->onPause()V

    return-void
.end method

.method protected onResume()V
    .locals 2

    .line 72
    invoke-super {p0}, Lorg/libsdl/app/SDLActivity;->onResume()V

    .line 73
    iget-object v0, p0, Lorg/openaok/game/GameActivity;->screens:Lorg/openaok/game/ThorScreens;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lorg/openaok/game/ThorScreens;->resume()V

    .line 74
    :cond_0
    invoke-direct {p0}, Lorg/openaok/game/GameActivity;->inputs()Landroid/hardware/input/InputManager;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, p0, v1}, Landroid/hardware/input/InputManager;->registerInputDeviceListener(Landroid/hardware/input/InputManager$InputDeviceListener;Landroid/os/Handler;)V

    .line 75
    invoke-direct {p0}, Lorg/openaok/game/GameActivity;->reportMouse()V

    return-void
.end method
