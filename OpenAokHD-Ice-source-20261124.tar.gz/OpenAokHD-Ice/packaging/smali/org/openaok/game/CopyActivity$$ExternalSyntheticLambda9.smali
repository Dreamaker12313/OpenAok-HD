.class public final synthetic Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda9;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lorg/openaok/game/CopyActivity;

.field public final synthetic f$1:Ljava/io/IOException;

.field public final synthetic f$2:Z


# direct methods
.method public synthetic constructor <init>(Lorg/openaok/game/CopyActivity;Ljava/io/IOException;Z)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda9;->f$0:Lorg/openaok/game/CopyActivity;

    iput-object p2, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda9;->f$1:Ljava/io/IOException;

    iput-boolean p3, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda9;->f$2:Z

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    iget-object v0, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda9;->f$0:Lorg/openaok/game/CopyActivity;

    iget-object v1, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda9;->f$1:Ljava/io/IOException;

    iget-boolean v2, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda9;->f$2:Z

    invoke-virtual {v0, v1, v2}, Lorg/openaok/game/CopyActivity;->lambda$onActivityResult$6$org-openaok-game-CopyActivity(Ljava/io/IOException;Z)V

    return-void
.end method
