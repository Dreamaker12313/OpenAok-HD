.class final Lorg/openaok/game/CopyActivity$Entry;
.super Ljava/lang/Object;
.source "CopyActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/openaok/game/CopyActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Entry"
.end annotation


# instance fields
.field final folder:Z

.field final id:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;Z)V
    .registers 3

    .line 247
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 248
    iput-object p1, p0, Lorg/openaok/game/CopyActivity$Entry;->id:Ljava/lang/String;

    .line 249
    iput-boolean p2, p0, Lorg/openaok/game/CopyActivity$Entry;->folder:Z

    .line 250
    return-void
.end method
