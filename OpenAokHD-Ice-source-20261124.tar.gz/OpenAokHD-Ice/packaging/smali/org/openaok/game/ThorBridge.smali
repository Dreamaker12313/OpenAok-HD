.class final Lorg/openaok/game/ThorBridge;
.super Ljava/lang/Object;
.source "ThorBridge.java"


# static fields
.field static final CMD_AGE_UP:I = 0x6

.field static final CMD_CANCEL_QUEUE:I = 0x8

.field static final CMD_COMMAND:I = 0x1

.field static final CMD_DELETE:I = 0x9

.field static final CMD_GAME:I = 0x10

.field static final CMD_GO_TO:I = 0xc

.field static final CMD_GROUP_ASSIGN:I = 0xe

.field static final CMD_GROUP_SELECT:I = 0xd

.field static final CMD_IDLE_MILITARY:I = 0x4

.field static final CMD_IDLE_VILLAGER:I = 0x3

.field static final CMD_MENU:I = 0x7

.field static final CMD_MINIMAP:I = 0x2

.field static final CMD_OBJECTIVES:I = 0xa

.field static final CMD_SPEED:I = 0xf

.field static final CMD_TECH_TREE:I = 0xb

.field static final CMD_TOWN_CENTER:I = 0x5

.field static final COMMAND:I = 0x8

.field static final F_AGE_RESEARCHING:I = 0x2

.field static final F_PLACING:I = 0x1

.field static final GAME_CLOCK:I = 0x7

.field static final GAME_FLARE:I = 0x2

.field static final GAME_MAP_COMBAT:I = 0x4

.field static final GAME_MAP_ECONOMIC:I = 0x5

.field static final GAME_MAP_NORMAL:I = 0x3

.field static final GAME_NOTIFICATION:I = 0x0

.field static final GAME_STATISTICS:I = 0x6

.field static final GAME_TO_SELECTED:I = 0x1

.field static final GO_TO:I = 0x4

.field static final HEADER:I = 0x26

.field static final H_AGE:I = 0x8

.field static final H_CIV:I = 0x1f

.field static final H_COMMANDS:I = 0x12

.field static final H_FLAGS:I = 0x9

.field static final H_FOOD:I = 0x3

.field static final H_GOLD:I = 0x4

.field static final H_GO_TOS:I = 0x25

.field static final H_GROUPS:I = 0x21

.field static final H_HP:I = 0xb

.field static final H_IN_GAME:I = 0x1

.field static final H_MAP_H:I = 0x16

.field static final H_MAP_SERIAL:I = 0x14

.field static final H_MAP_W:I = 0x15

.field static final H_MAX_HP:I = 0xc

.field static final H_POP:I = 0x6

.field static final H_POP_CAP:I = 0x7

.field static final H_QUEUE:I = 0x13

.field static final H_QUEUE_DONE:I = 0x10

.field static final H_QUEUE_TOTAL:I = 0x11

.field static final H_SELECTED:I = 0xa

.field static final H_SEL_FRAME:I = 0xe

.field static final H_SEL_SLP:I = 0xd

.field static final H_SEL_UNIT:I = 0xf

.field static final H_SPEED:I = 0x20

.field static final H_STONE:I = 0x5

.field static final H_VERSION:I = 0x0

.field static final H_VIEW:I = 0x17

.field static final H_WOOD:I = 0x2

.field static final KIND_CAPTION:I = 0x1b

.field static final QUEUE:I = 0x5

.field static final TEXT_AGE:I = 0x0

.field static final TEXT_GO_TO:I = 0x6

.field static final TEXT_HELP:I = 0x3

.field static final TEXT_LABEL:I = 0x5

.field static final TEXT_NAME:I = 0x2

.field static final TEXT_NEXT_AGE:I = 0x1

.field static final TEXT_STRING:I = 0x4


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static native icon(II[I[I)I
.end method

.method static native minimap([I)I
.end method

.method static push(III)V
    .locals 0

    .line 53
    :try_start_0
    invoke-static {p0, p1, p2}, Lorg/openaok/game/ThorBridge;->pushCommand(III)V
    :try_end_0
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method

.method static native pushCommand(III)V
.end method

.method static native setDualScreen(Z)V
.end method

.method static native snapshot([I)I
.end method

.method static native text(II)Ljava/lang/String;
.end method
