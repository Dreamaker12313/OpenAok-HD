.class public final synthetic Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lorg/openaok/game/CopyActivity;


# direct methods
.method public synthetic constructor <init>(Lorg/openaok/game/CopyActivity;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda3;->f$0:Lorg/openaok/game/CopyActivity;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    iget-object v0, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda3;->f$0:Lorg/openaok/game/CopyActivity;

    invoke-virtual {v0, p1}, Lorg/openaok/game/CopyActivity;->lambda$build$2$org-openaok-game-CopyActivity(Landroid/view/View;)V

    return-void
.end method
