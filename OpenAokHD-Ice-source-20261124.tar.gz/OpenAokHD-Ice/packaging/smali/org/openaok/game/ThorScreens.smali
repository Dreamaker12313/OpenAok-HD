.class final Lorg/openaok/game/ThorScreens;
.super Ljava/lang/Object;
.source "ThorScreens.java"

# interfaces
.implements Landroid/hardware/display/DisplayManager$DisplayListener;


# static fields
.field private static final TAG:Ljava/lang/String; = "ThorAoK"


# instance fields
.field private final activity:Landroid/app/Activity;

.field private deck:Lorg/openaok/game/ThorDeck;

.field private final displays:Landroid/hardware/display/DisplayManager;

.field private final handler:Landroid/os/Handler;

.field private presentation:Landroid/app/Presentation;


# direct methods
.method constructor <init>(Landroid/app/Activity;)V
    .locals 2

    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 22
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lorg/openaok/game/ThorScreens;->handler:Landroid/os/Handler;

    .line 27
    iput-object p1, p0, Lorg/openaok/game/ThorScreens;->activity:Landroid/app/Activity;

    .line 28
    const-string v0, "display"

    invoke-virtual {p1, v0}, Landroid/app/Activity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/hardware/display/DisplayManager;

    iput-object p1, p0, Lorg/openaok/game/ThorScreens;->displays:Landroid/hardware/display/DisplayManager;

    return-void
.end method

.method private attach()V
    .locals 6

    .line 88
    const-string v0, "ThorAoK"

    .line 0
    const-string v1, "command deck on display "

    .line 88
    iget-object v2, p0, Lorg/openaok/game/ThorScreens;->activity:Landroid/app/Activity;

    iget-object v3, p0, Lorg/openaok/game/ThorScreens;->displays:Landroid/hardware/display/DisplayManager;

    invoke-static {v2, v3}, Lorg/openaok/game/ThorScreens;->findSecondary(Landroid/app/Activity;Landroid/hardware/display/DisplayManager;)Landroid/view/Display;

    move-result-object v2

    .line 89
    iget-object v3, p0, Lorg/openaok/game/ThorScreens;->presentation:Landroid/app/Presentation;

    const/4 v4, 0x0

    if-eqz v3, :cond_1

    if-eqz v2, :cond_0

    invoke-virtual {v3}, Landroid/app/Presentation;->getDisplay()Landroid/view/Display;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/Display;->getDisplayId()I

    move-result v3

    invoke-virtual {v2}, Landroid/view/Display;->getDisplayId()I

    move-result v5

    if-eq v3, v5, :cond_1

    .line 90
    :cond_0
    iget-object v3, p0, Lorg/openaok/game/ThorScreens;->deck:Lorg/openaok/game/ThorDeck;

    invoke-virtual {v3}, Lorg/openaok/game/ThorDeck;->stop()V

    .line 91
    iget-object v3, p0, Lorg/openaok/game/ThorScreens;->presentation:Landroid/app/Presentation;

    invoke-virtual {v3}, Landroid/app/Presentation;->dismiss()V

    .line 92
    iput-object v4, p0, Lorg/openaok/game/ThorScreens;->presentation:Landroid/app/Presentation;

    .line 93
    iput-object v4, p0, Lorg/openaok/game/ThorScreens;->deck:Lorg/openaok/game/ThorDeck;

    :cond_1
    if-eqz v2, :cond_3

    .line 95
    iget-object v3, p0, Lorg/openaok/game/ThorScreens;->presentation:Landroid/app/Presentation;

    if-eqz v3, :cond_2

    goto/16 :goto_0

    .line 98
    :cond_2
    new-instance v3, Landroid/app/Presentation;

    iget-object v5, p0, Lorg/openaok/game/ThorScreens;->activity:Landroid/app/Activity;

    invoke-direct {v3, v5, v2}, Landroid/app/Presentation;-><init>(Landroid/content/Context;Landroid/view/Display;)V

    iput-object v3, p0, Lorg/openaok/game/ThorScreens;->presentation:Landroid/app/Presentation;

    .line 100
    new-instance v3, Landroid/content/res/Configuration;

    iget-object v5, p0, Lorg/openaok/game/ThorScreens;->presentation:Landroid/app/Presentation;

    .line 101
    invoke-virtual {v5}, Landroid/app/Presentation;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v5

    invoke-direct {v3, v5}, Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V

    .line 102
    iget-object v5, p0, Lorg/openaok/game/ThorScreens;->activity:Landroid/app/Activity;

    invoke-virtual {v5}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/res/Configuration;->getLocales()Landroid/os/LocaleList;

    move-result-object v5

    invoke-virtual {v3, v5}, Landroid/content/res/Configuration;->setLocales(Landroid/os/LocaleList;)V

    .line 103
    iget-object v5, p0, Lorg/openaok/game/ThorScreens;->presentation:Landroid/app/Presentation;

    invoke-virtual {v5}, Landroid/app/Presentation;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-virtual {v5, v3}, Landroid/content/Context;->createConfigurationContext(Landroid/content/res/Configuration;)Landroid/content/Context;

    move-result-object v3

    .line 104
    new-instance v5, Lorg/openaok/game/ThorDeck;

    invoke-direct {v5, v3}, Lorg/openaok/game/ThorDeck;-><init>(Landroid/content/Context;)V

    iput-object v5, p0, Lorg/openaok/game/ThorScreens;->deck:Lorg/openaok/game/ThorDeck;

    .line 105
    iget-object v3, p0, Lorg/openaok/game/ThorScreens;->presentation:Landroid/app/Presentation;

    invoke-virtual {v3, v5}, Landroid/app/Presentation;->setContentView(Landroid/view/View;)V

    .line 106
    iget-object v3, p0, Lorg/openaok/game/ThorScreens;->presentation:Landroid/app/Presentation;

    invoke-virtual {v3}, Landroid/app/Presentation;->getWindow()Landroid/view/Window;

    move-result-object v3

    const/16 v5, 0x88

    invoke-virtual {v3, v5}, Landroid/view/Window;->addFlags(I)V

    .line 108
    iget-object v3, p0, Lorg/openaok/game/ThorScreens;->presentation:Landroid/app/Presentation;

    invoke-virtual {v3}, Landroid/app/Presentation;->getWindow()Landroid/view/Window;

    move-result-object v3

    const/16 v5, 0x400

    invoke-virtual {v3, v5, v5}, Landroid/view/Window;->setFlags(II)V

    .line 111
    :try_start_0
    iget-object v3, p0, Lorg/openaok/game/ThorScreens;->presentation:Landroid/app/Presentation;

    invoke-virtual {v3}, Landroid/app/Presentation;->show()V

    .line 112
    iget-object v3, p0, Lorg/openaok/game/ThorScreens;->deck:Lorg/openaok/game/ThorDeck;

    invoke-virtual {v3}, Lorg/openaok/game/ThorDeck;->start()V

    .line 113
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2}, Landroid/view/Display;->getDisplayId()I

    move-result v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Landroid/view/WindowManager$InvalidDisplayException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception v1

    .line 115
    const-string v2, "presentation failed"

    invoke-static {v0, v2, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 116
    iput-object v4, p0, Lorg/openaok/game/ThorScreens;->presentation:Landroid/app/Presentation;

    .line 117
    iput-object v4, p0, Lorg/openaok/game/ThorScreens;->deck:Lorg/openaok/game/ThorDeck;

    :cond_3
    :goto_0
    return-void
.end method

.method private static findSecondary(Landroid/app/Activity;Landroid/hardware/display/DisplayManager;)Landroid/view/Display;
    .locals 6

    const/4 v0, 0x0

    .line 38
    :try_start_0
    invoke-virtual {p0}, Landroid/app/Activity;->getDisplay()Landroid/view/Display;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/Display;->getDisplayId()I

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move p0, v0

    .line 41
    :goto_0
    const-string v1, "android.hardware.display.category.PRESENTATION"

    invoke-virtual {p1, v1}, Landroid/hardware/display/DisplayManager;->getDisplays(Ljava/lang/String;)[Landroid/view/Display;

    move-result-object v1

    array-length v2, v1

    move v3, v0

    :goto_1
    if-ge v3, v2, :cond_1

    aget-object v4, v1, v3

    .line 42
    invoke-virtual {v4}, Landroid/view/Display;->getDisplayId()I

    move-result v5

    if-eq v5, p0, :cond_0

    return-object v4

    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    .line 46
    :cond_1
    invoke-virtual {p1}, Landroid/hardware/display/DisplayManager;->getDisplays()[Landroid/view/Display;

    move-result-object p1

    array-length v1, p1

    :goto_2
    if-ge v0, v1, :cond_3

    aget-object v2, p1, v0

    .line 47
    invoke-virtual {v2}, Landroid/view/Display;->getDisplayId()I

    move-result v3

    if-eq v3, p0, :cond_2

    return-object v2

    :cond_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_3
    const/4 p0, 0x0

    return-object p0
.end method

.method static hasSecondScreen(Landroid/app/Activity;)Z
    .locals 1

    .line 32
    const-string v0, "display"

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/hardware/display/DisplayManager;

    invoke-static {p0, v0}, Lorg/openaok/game/ThorScreens;->findSecondary(Landroid/app/Activity;Landroid/hardware/display/DisplayManager;)Landroid/view/Display;

    move-result-object p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    const/4 p0, 0x0

    return p0
.end method


# virtual methods
.method deck()Lorg/openaok/game/ThorDeck;
    .locals 0

    .line 72
    iget-object p0, p0, Lorg/openaok/game/ThorScreens;->deck:Lorg/openaok/game/ThorDeck;

    return-object p0
.end method

.method public onDisplayAdded(I)V
    .locals 0

    .line 123
    invoke-direct {p0}, Lorg/openaok/game/ThorScreens;->attach()V

    return-void
.end method

.method public onDisplayChanged(I)V
    .locals 0

    return-void
.end method

.method public onDisplayRemoved(I)V
    .locals 0

    .line 128
    invoke-direct {p0}, Lorg/openaok/game/ThorScreens;->attach()V

    return-void
.end method

.method pause()V
    .locals 0

    .line 76
    iget-object p0, p0, Lorg/openaok/game/ThorScreens;->deck:Lorg/openaok/game/ThorDeck;

    if-eqz p0, :cond_0

    .line 77
    invoke-virtual {p0}, Lorg/openaok/game/ThorDeck;->stop()V

    :cond_0
    return-void
.end method

.method resume()V
    .locals 0

    .line 82
    iget-object p0, p0, Lorg/openaok/game/ThorScreens;->deck:Lorg/openaok/game/ThorDeck;

    if-eqz p0, :cond_0

    .line 83
    invoke-virtual {p0}, Lorg/openaok/game/ThorDeck;->start()V

    :cond_0
    return-void
.end method

.method start()V
    .locals 2

    .line 55
    iget-object v0, p0, Lorg/openaok/game/ThorScreens;->displays:Landroid/hardware/display/DisplayManager;

    iget-object v1, p0, Lorg/openaok/game/ThorScreens;->handler:Landroid/os/Handler;

    invoke-virtual {v0, p0, v1}, Landroid/hardware/display/DisplayManager;->registerDisplayListener(Landroid/hardware/display/DisplayManager$DisplayListener;Landroid/os/Handler;)V

    .line 56
    invoke-direct {p0}, Lorg/openaok/game/ThorScreens;->attach()V

    return-void
.end method

.method stop()V
    .locals 1

    .line 60
    iget-object v0, p0, Lorg/openaok/game/ThorScreens;->displays:Landroid/hardware/display/DisplayManager;

    invoke-virtual {v0, p0}, Landroid/hardware/display/DisplayManager;->unregisterDisplayListener(Landroid/hardware/display/DisplayManager$DisplayListener;)V

    .line 61
    iget-object v0, p0, Lorg/openaok/game/ThorScreens;->deck:Lorg/openaok/game/ThorDeck;

    if-eqz v0, :cond_0

    .line 62
    invoke-virtual {v0}, Lorg/openaok/game/ThorDeck;->stop()V

    .line 64
    :cond_0
    iget-object v0, p0, Lorg/openaok/game/ThorScreens;->presentation:Landroid/app/Presentation;

    if-eqz v0, :cond_1

    .line 65
    invoke-virtual {v0}, Landroid/app/Presentation;->dismiss()V

    :cond_1
    const/4 v0, 0x0

    .line 67
    iput-object v0, p0, Lorg/openaok/game/ThorScreens;->presentation:Landroid/app/Presentation;

    .line 68
    iput-object v0, p0, Lorg/openaok/game/ThorScreens;->deck:Lorg/openaok/game/ThorDeck;

    return-void
.end method
