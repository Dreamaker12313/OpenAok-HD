.class public final synthetic Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lorg/openaok/game/CopyActivity;


# direct methods
.method public synthetic constructor <init>(Lorg/openaok/game/CopyActivity;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda8;->f$0:Lorg/openaok/game/CopyActivity;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget-object v0, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda8;->f$0:Lorg/openaok/game/CopyActivity;

    invoke-static {v0}, Lorg/openaok/game/CopyActivity;->$r8$lambda$a_lWojOxQHQh8RsVQZJN3CVGsK0(Lorg/openaok/game/CopyActivity;)V

    return-void
.end method
