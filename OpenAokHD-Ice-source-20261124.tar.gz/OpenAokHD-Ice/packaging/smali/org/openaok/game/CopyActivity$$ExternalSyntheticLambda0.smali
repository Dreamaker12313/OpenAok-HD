.class public final synthetic Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lorg/openaok/game/CopyActivity;

.field public final synthetic f$1:I

.field public final synthetic f$2:J

.field public final synthetic f$3:J


# direct methods
.method public synthetic constructor <init>(Lorg/openaok/game/CopyActivity;IJJ)V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda0;->f$0:Lorg/openaok/game/CopyActivity;

    iput p2, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda0;->f$1:I

    iput-wide p3, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda0;->f$2:J

    iput-wide p5, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda0;->f$3:J

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 7

    iget-object v0, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda0;->f$0:Lorg/openaok/game/CopyActivity;

    iget v1, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda0;->f$1:I

    iget-wide v2, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda0;->f$2:J

    iget-wide v4, p0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda0;->f$3:J

    invoke-virtual/range {v0 .. v5}, Lorg/openaok/game/CopyActivity;->lambda$install$8$org-openaok-game-CopyActivity(IJJ)V

    return-void
.end method
