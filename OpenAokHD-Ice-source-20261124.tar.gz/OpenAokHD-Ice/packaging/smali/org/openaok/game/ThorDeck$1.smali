.class Lorg/openaok/game/ThorDeck$1;
.super Ljava/lang/Object;
.source "ThorDeck.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/openaok/game/ThorDeck;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lorg/openaok/game/ThorDeck;


# direct methods
.method constructor <init>(Lorg/openaok/game/ThorDeck;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 114
    iput-object p1, p0, Lorg/openaok/game/ThorDeck$1;->this$0:Lorg/openaok/game/ThorDeck;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 9

    .line 117
    iget-object v0, p0, Lorg/openaok/game/ThorDeck$1;->this$0:Lorg/openaok/game/ThorDeck;

    invoke-static {v0}, Lorg/openaok/game/ThorDeck;->-$$Nest$fgetrunning(Lorg/openaok/game/ThorDeck;)Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 118
    :cond_0
    iget-object v0, p0, Lorg/openaok/game/ThorDeck$1;->this$0:Lorg/openaok/game/ThorDeck;

    invoke-static {v0}, Lorg/openaok/game/ThorDeck;->-$$Nest$mrefresh(Lorg/openaok/game/ThorDeck;)V

    .line 120
    iget-object v0, p0, Lorg/openaok/game/ThorDeck$1;->this$0:Lorg/openaok/game/ThorDeck;

    invoke-static {v0}, Lorg/openaok/game/ThorDeck;->-$$Nest$fgetpressedTile(Lorg/openaok/game/ThorDeck;)I

    move-result v0

    const-wide/16 v1, 0x1a4

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-ltz v0, :cond_1

    iget-object v0, p0, Lorg/openaok/game/ThorDeck$1;->this$0:Lorg/openaok/game/ThorDeck;

    invoke-static {v0}, Lorg/openaok/game/ThorDeck;->-$$Nest$fgetheld(Lorg/openaok/game/ThorDeck;)Z

    move-result v0

    if-nez v0, :cond_1

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v5

    iget-object v0, p0, Lorg/openaok/game/ThorDeck$1;->this$0:Lorg/openaok/game/ThorDeck;

    invoke-static {v0}, Lorg/openaok/game/ThorDeck;->-$$Nest$fgetpressedAt(Lorg/openaok/game/ThorDeck;)J

    move-result-wide v7

    sub-long/2addr v5, v7

    cmp-long v0, v5, v1

    if-lez v0, :cond_1

    .line 121
    iget-object v0, p0, Lorg/openaok/game/ThorDeck$1;->this$0:Lorg/openaok/game/ThorDeck;

    invoke-static {v0, v4}, Lorg/openaok/game/ThorDeck;->-$$Nest$fputheld(Lorg/openaok/game/ThorDeck;Z)V

    .line 122
    iget-object v0, p0, Lorg/openaok/game/ThorDeck$1;->this$0:Lorg/openaok/game/ThorDeck;

    invoke-virtual {v0, v3}, Lorg/openaok/game/ThorDeck;->performHapticFeedback(I)Z

    .line 123
    iget-object v0, p0, Lorg/openaok/game/ThorDeck$1;->this$0:Lorg/openaok/game/ThorDeck;

    invoke-static {v0}, Lorg/openaok/game/ThorDeck;->-$$Nest$fgettab(Lorg/openaok/game/ThorDeck;)I

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lorg/openaok/game/ThorDeck$1;->this$0:Lorg/openaok/game/ThorDeck;

    invoke-static {v0}, Lorg/openaok/game/ThorDeck;->-$$Nest$fgetpressedTile(Lorg/openaok/game/ThorDeck;)I

    move-result v5

    invoke-static {v0, v5}, Lorg/openaok/game/ThorDeck;->-$$Nest$mshowHelp(Lorg/openaok/game/ThorDeck;I)V

    .line 125
    :cond_1
    iget-object v0, p0, Lorg/openaok/game/ThorDeck$1;->this$0:Lorg/openaok/game/ThorDeck;

    invoke-static {v0}, Lorg/openaok/game/ThorDeck;->-$$Nest$fgetpressedGroup(Lorg/openaok/game/ThorDeck;)I

    move-result v0

    if-ltz v0, :cond_2

    iget-object v0, p0, Lorg/openaok/game/ThorDeck$1;->this$0:Lorg/openaok/game/ThorDeck;

    invoke-static {v0}, Lorg/openaok/game/ThorDeck;->-$$Nest$fgetheld(Lorg/openaok/game/ThorDeck;)Z

    move-result v0

    if-nez v0, :cond_2

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v5

    iget-object v0, p0, Lorg/openaok/game/ThorDeck$1;->this$0:Lorg/openaok/game/ThorDeck;

    invoke-static {v0}, Lorg/openaok/game/ThorDeck;->-$$Nest$fgetpressedAt(Lorg/openaok/game/ThorDeck;)J

    move-result-wide v7

    sub-long/2addr v5, v7

    cmp-long v0, v5, v1

    if-lez v0, :cond_2

    .line 126
    iget-object v0, p0, Lorg/openaok/game/ThorDeck$1;->this$0:Lorg/openaok/game/ThorDeck;

    invoke-static {v0, v4}, Lorg/openaok/game/ThorDeck;->-$$Nest$fputheld(Lorg/openaok/game/ThorDeck;Z)V

    .line 127
    iget-object v0, p0, Lorg/openaok/game/ThorDeck$1;->this$0:Lorg/openaok/game/ThorDeck;

    invoke-virtual {v0, v3}, Lorg/openaok/game/ThorDeck;->performHapticFeedback(I)Z

    .line 128
    iget-object v0, p0, Lorg/openaok/game/ThorDeck$1;->this$0:Lorg/openaok/game/ThorDeck;

    invoke-static {v0}, Lorg/openaok/game/ThorDeck;->-$$Nest$fgetpressedGroup(Lorg/openaok/game/ThorDeck;)I

    move-result v0

    add-int/2addr v0, v4

    const/16 v1, 0xe

    invoke-static {v1, v0, v3}, Lorg/openaok/game/ThorBridge;->push(III)V

    .line 130
    :cond_2
    iget-object v0, p0, Lorg/openaok/game/ThorDeck$1;->this$0:Lorg/openaok/game/ThorDeck;

    invoke-virtual {v0}, Lorg/openaok/game/ThorDeck;->invalidate()V

    .line 131
    iget-object v0, p0, Lorg/openaok/game/ThorDeck$1;->this$0:Lorg/openaok/game/ThorDeck;

    invoke-static {v0}, Lorg/openaok/game/ThorDeck;->-$$Nest$fgethandler(Lorg/openaok/game/ThorDeck;)Landroid/os/Handler;

    move-result-object v0

    const-wide/16 v1, 0x32

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
