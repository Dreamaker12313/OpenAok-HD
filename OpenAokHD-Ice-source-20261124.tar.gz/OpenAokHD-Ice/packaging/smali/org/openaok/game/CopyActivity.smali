.class public Lorg/openaok/game/CopyActivity;
.super Landroid/app/Activity;
.source "CopyActivity.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/openaok/game/CopyActivity$Entry;
    }
.end annotation


# static fields
.field private static final kChooseFolder:I = 0x1

.field private static final kFolderName:Ljava/lang/String; = "OpenAoK-data"


# instance fields
.field private bar:Landroid/widget/ProgressBar;

.field private choose:Landroid/widget/Button;

.field private layout:Landroid/widget/LinearLayout;

.field private mods:Landroid/widget/Button;

.field private play:Landroid/widget/Button;

.field private status:Landroid/widget/TextView;

.field private tts:Landroid/speech/tts/TextToSpeech;

.field private media:Landroid/media/MediaPlayer;

.field public bubble:Landroid/widget/TextView;

.field public tail:Landroid/view/View;

.field public clear:Lorg/openaok/game/CopyActivity$VillagerClear;

.field public sound:Landroid/widget/ImageView;

.field public muted:Z

.field public video:Landroid/widget/VideoView;

.field public videoUri:Landroid/net/Uri;

.field private handler:Landroid/os/Handler;


# direct methods
.method public static synthetic $r8$lambda$a_lWojOxQHQh8RsVQZJN3CVGsK0(Lorg/openaok/game/CopyActivity;)V
    .registers 1

    invoke-direct {p0}, Lorg/openaok/game/CopyActivity;->play()V

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 45
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private build()V
    .registers 10

    .line 93
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lorg/openaok/game/CopyActivity;->layout:Landroid/widget/LinearLayout;

    .line 94
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 95
    iget-object v0, p0, Lorg/openaok/game/CopyActivity;->layout:Landroid/widget/LinearLayout;

    const v1, 0x800013

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 96
    iget-object v0, p0, Lorg/openaok/game/CopyActivity;->layout:Landroid/widget/LinearLayout;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 97
    iget-object v0, p0, Lorg/openaok/game/CopyActivity;->layout:Landroid/widget/LinearLayout;

    const/16 v2, 0x78

    invoke-virtual {v0, v2, v1, v2, v1}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 98
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 99
    const-string v3, "OpenAokHD"

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 100
    const/16 v3, 0xb0

    const/16 v4, 0x4a

    const/16 v5, 0xe8

    invoke-static {v5, v3, v4}, Landroid/graphics/Color;->rgb(III)I

    move-result v3

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 101
    const/high16 v3, 0x42100000    # 36.0f

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setTextSize(F)V

    .line 102
    sget-object v3, Landroid/graphics/Typeface;->SERIF:Landroid/graphics/Typeface;

    const/4 v4, 0x1

    invoke-static {v3, v4}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 103
    const v3, 0x800003

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setGravity(I)V

    .line 104
    const/16 v4, 0x1c

    invoke-virtual {v0, v1, v1, v1, v4}, Landroid/widget/TextView;->setPadding(IIII)V

    const/high16 v4, 0x41000000

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/high16 v7, -0x1000000

    invoke-virtual {v0, v4, v5, v6, v7}, Landroid/widget/TextView;->setShadowLayer(FFFI)V

    .line 105
    new-instance v1, Landroid/widget/TextView;

    invoke-direct {v1, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lorg/openaok/game/CopyActivity;->status:Landroid/widget/TextView;

    .line 106
    const/16 v4, 0xe6

    const/16 v5, 0xc8

    invoke-static {v4, v5, v2}, Landroid/graphics/Color;->rgb(III)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 107
    iget-object v1, p0, Lorg/openaok/game/CopyActivity;->status:Landroid/widget/TextView;

    const/high16 v2, 0x41900000    # 18.0f

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextSize(F)V

    .line 108
    iget-object v1, p0, Lorg/openaok/game/CopyActivity;->status:Landroid/widget/TextView;

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setGravity(I)V

    .line 109
    iget-object v1, p0, Lorg/openaok/game/CopyActivity;->status:Landroid/widget/TextView;

    const/16 v2, 0x384

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setMaxWidth(I)V

    .line 110
    new-instance v1, Landroid/widget/ProgressBar;

    const/4 v2, 0x0

    const v3, 0x1010078

    invoke-direct {v1, p0, v2, v3}, Landroid/widget/ProgressBar;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    iput-object v1, p0, Lorg/openaok/game/CopyActivity;->bar:Landroid/widget/ProgressBar;

    .line 111
    const/16 v2, 0x3e8

    invoke-virtual {v1, v2}, Landroid/widget/ProgressBar;->setMax(I)V

    .line 112
    iget-object v1, p0, Lorg/openaok/game/CopyActivity;->bar:Landroid/widget/ProgressBar;

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/widget/ProgressBar;->setVisibility(I)V

    .line 113
    sget v1, Lorg/openaok/game/R$string;->play:I

    invoke-virtual {p0, v1}, Lorg/openaok/game/CopyActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lorg/openaok/game/CopyActivity;->menuButton(Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v1

    iput-object v1, p0, Lorg/openaok/game/CopyActivity;->play:Landroid/widget/Button;

    .line 114
    new-instance v2, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda1;

    invoke-direct {v2, p0}, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda1;-><init>(Lorg/openaok/game/CopyActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 115
    const-string v1, "MOD\u7ba1\u7406\u5668"

    invoke-direct {p0, v1}, Lorg/openaok/game/CopyActivity;->menuButton(Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v1

    iput-object v1, p0, Lorg/openaok/game/CopyActivity;->mods:Landroid/widget/Button;

    .line 116
    new-instance v2, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda2;

    invoke-direct {v2, p0}, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda2;-><init>(Lorg/openaok/game/CopyActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 117
    sget v1, Lorg/openaok/game/R$string;->choose_folder:I

    invoke-virtual {p0, v1}, Lorg/openaok/game/CopyActivity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1}, Lorg/openaok/game/CopyActivity;->menuButton(Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v1

    iput-object v1, p0, Lorg/openaok/game/CopyActivity;->choose:Landroid/widget/Button;

    .line 118
    new-instance v2, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda3;

    invoke-direct {v2, p0}, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda3;-><init>(Lorg/openaok/game/CopyActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 122
    iget-object v1, p0, Lorg/openaok/game/CopyActivity;->layout:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 123
    iget-object v0, p0, Lorg/openaok/game/CopyActivity;->layout:Landroid/widget/LinearLayout;

    iget-object v1, p0, Lorg/openaok/game/CopyActivity;->status:Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 124
    iget-object v0, p0, Lorg/openaok/game/CopyActivity;->layout:Landroid/widget/LinearLayout;

    iget-object v1, p0, Lorg/openaok/game/CopyActivity;->bar:Landroid/widget/ProgressBar;

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, -0x1

    const/4 v4, -0x2

    invoke-direct {v2, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 126
    iget-object v0, p0, Lorg/openaok/game/CopyActivity;->layout:Landroid/widget/LinearLayout;

    iget-object v1, p0, Lorg/openaok/game/CopyActivity;->play:Landroid/widget/Button;

    invoke-direct {p0}, Lorg/openaok/game/CopyActivity;->menuParams()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 127
    iget-object v0, p0, Lorg/openaok/game/CopyActivity;->layout:Landroid/widget/LinearLayout;

    iget-object v1, p0, Lorg/openaok/game/CopyActivity;->mods:Landroid/widget/Button;

    invoke-direct {p0}, Lorg/openaok/game/CopyActivity;->menuParams()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 128
    iget-object v0, p0, Lorg/openaok/game/CopyActivity;->layout:Landroid/widget/LinearLayout;

    iget-object v1, p0, Lorg/openaok/game/CopyActivity;->choose:Landroid/widget/Button;

    invoke-direct {p0}, Lorg/openaok/game/CopyActivity;->menuParams()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 129
    new-instance v0, Landroid/widget/FrameLayout;

    invoke-direct {v0, p0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    new-instance v1, Landroid/widget/VideoView;

    invoke-direct {v1, p0}, Landroid/widget/VideoView;-><init>(Landroid/content/Context;)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "android.resource://"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lorg/openaok/game/CopyActivity;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "/2131034112"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    iput-object v2, p0, Lorg/openaok/game/CopyActivity;->videoUri:Landroid/net/Uri;

    invoke-virtual {v1, v2}, Landroid/widget/VideoView;->setVideoURI(Landroid/net/Uri;)V

    new-instance v2, Lorg/openaok/game/CopyActivity$VideoLoop;

    invoke-direct {v2, p0}, Lorg/openaok/game/CopyActivity$VideoLoop;-><init>(Lorg/openaok/game/CopyActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/VideoView;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    iput-object v1, p0, Lorg/openaok/game/CopyActivity;->video:Landroid/widget/VideoView;

    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v3, -0x1

    const/4 v4, -0x1

    invoke-direct {v2, v3, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v1}, Landroid/widget/VideoView;->start()V

    new-instance v1, Landroid/view/View;

    invoke-direct {v1, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v2, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    sget-object v3, Landroid/graphics/drawable/GradientDrawable$Orientation;->LEFT_RIGHT:Landroid/graphics/drawable/GradientDrawable$Orientation;

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setOrientation(Landroid/graphics/drawable/GradientDrawable$Orientation;)V

    const/4 v3, 0x3

    new-array v3, v3, [I

    const/4 v4, 0x0

    const v5, -0x40000000

    aput v5, v3, v4

    const/4 v4, 0x1

    const/high16 v5, 0x40000000

    aput v5, v3, v4

    const/4 v4, 0x2

    const/4 v5, 0x0

    aput v5, v3, v4

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setColors([I)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v3, -0x1

    const/4 v4, -0x1

    invoke-direct {v2, v3, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Landroid/view/View;

    invoke-direct {v1, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v2, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setGradientType(I)V

    const/high16 v3, 0x3f000000

    invoke-virtual {v2, v3, v3}, Landroid/graphics/drawable/GradientDrawable;->setGradientCenter(FF)V

    const/high16 v3, 0x451c0000

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setGradientRadius(F)V

    const/4 v3, 0x2

    new-array v3, v3, [I

    const/4 v4, 0x0

    const/4 v5, 0x0

    aput v5, v3, v4

    const/4 v4, 0x1

    const v5, -0x66000000

    aput v5, v3, v4

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setColors([I)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v3, -0x1

    const/4 v4, -0x1

    invoke-direct {v2, v3, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v1, p0, Lorg/openaok/game/CopyActivity;->layout:Landroid/widget/LinearLayout;

    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v3, -0x1

    const/4 v4, -0x1

    invoke-direct {v2, v3, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Landroid/widget/ImageView;

    invoke-direct {v1, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    new-instance v2, Landroid/graphics/drawable/AnimationDrawable;

    invoke-direct {v2}, Landroid/graphics/drawable/AnimationDrawable;-><init>()V

    invoke-virtual {p0}, Lorg/openaok/game/CopyActivity;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v3

    const-string v4, "villager_0.png"

    invoke-virtual {v3, v4}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object v4

    new-instance v5, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p0}, Lorg/openaok/game/CopyActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-direct {v5, v3, v4}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V

    const/16 v3, 0xb4

    invoke-virtual {v2, v5, v3}, Landroid/graphics/drawable/AnimationDrawable;->addFrame(Landroid/graphics/drawable/Drawable;I)V

    invoke-virtual {p0}, Lorg/openaok/game/CopyActivity;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v3

    const-string v4, "villager_1.png"

    invoke-virtual {v3, v4}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object v4

    new-instance v5, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p0}, Lorg/openaok/game/CopyActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-direct {v5, v3, v4}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V

    const/16 v3, 0xb4

    invoke-virtual {v2, v5, v3}, Landroid/graphics/drawable/AnimationDrawable;->addFrame(Landroid/graphics/drawable/Drawable;I)V

    invoke-virtual {p0}, Lorg/openaok/game/CopyActivity;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v3

    const-string v4, "villager_2.png"

    invoke-virtual {v3, v4}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object v4

    new-instance v5, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p0}, Lorg/openaok/game/CopyActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-direct {v5, v3, v4}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V

    const/16 v3, 0xb4

    invoke-virtual {v2, v5, v3}, Landroid/graphics/drawable/AnimationDrawable;->addFrame(Landroid/graphics/drawable/Drawable;I)V

    invoke-virtual {p0}, Lorg/openaok/game/CopyActivity;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v3

    const-string v4, "villager_3.png"

    invoke-virtual {v3, v4}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object v4

    new-instance v5, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p0}, Lorg/openaok/game/CopyActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-direct {v5, v3, v4}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V

    const/16 v3, 0xb4

    invoke-virtual {v2, v5, v3}, Landroid/graphics/drawable/AnimationDrawable;->addFrame(Landroid/graphics/drawable/Drawable;I)V

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v2}, Landroid/graphics/drawable/AnimationDrawable;->start()V

    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v3, 0x154

    const/16 v4, 0x1cc

    const v5, 0x800055

    invoke-direct {v2, v3, v4, v5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Lorg/openaok/game/CopyActivity$VillagerClick;

    invoke-direct {v3, p0}, Lorg/openaok/game/CopyActivity$VillagerClick;-><init>(Lorg/openaok/game/CopyActivity;)V

    invoke-virtual {v1, v3}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const/high16 v3, 0x41b00000

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextSize(F)V

    const/16 v3, 0xdc

    const/16 v4, 0xbe

    const/16 v5, 0xeb

    invoke-static {v5, v3, v4}, Landroid/graphics/Color;->rgb(III)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextColor(I)V

    sget-object v3, Landroid/graphics/Typeface;->SERIF:Landroid/graphics/Typeface;

    const/4 v4, 0x1

    invoke-static {v3, v4}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    const/high16 v3, 0x40200000

    const/4 v4, 0x0

    const/4 v5, 0x0

    const v6, 0xcc000000

    invoke-virtual {v2, v3, v4, v5, v6}, Landroid/widget/TextView;->setShadowLayer(FFFI)V

    const/16 v3, 0x18

    invoke-virtual {v2, v3, v3, v3, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    const/16 v3, 0x8

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setVisibility(I)V

    new-instance v3, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v3}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v4, 0x0

    invoke-virtual {v3, v4}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/4 v4, 0x1

    const v5, 0xcc8c6b2e

    invoke-virtual {v3, v4, v5}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    const/high16 v4, 0x41900000

    invoke-virtual {v3, v4}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 v3, 0x258

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setMaxWidth(I)V

    iput-object v2, p0, Lorg/openaok/game/CopyActivity;->bubble:Landroid/widget/TextView;

    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v4, -0x2

    const/4 v5, -0x2

    const v6, 0x800055

    invoke-direct {v3, v4, v5, v6}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    const/16 v4, 0xbe

    const/16 v5, 0x1cc

    invoke-virtual {v3, v4, v4, v4, v5}, Landroid/widget/FrameLayout$LayoutParams;->setMargins(IIII)V

    invoke-virtual {v0, v2, v3}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v4, Landroid/view/View;

    invoke-direct {v4, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v5, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v5}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/4 v6, 0x1

    const v7, 0xcc8c6b2e

    invoke-virtual {v5, v6, v7}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    invoke-virtual {v4, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/high16 v5, 0x42340000

    invoke-virtual {v4, v5}, Landroid/view/View;->setRotation(F)V

    const/16 v5, 0x8

    invoke-virtual {v4, v5}, Landroid/view/View;->setVisibility(I)V

    iput-object v4, p0, Lorg/openaok/game/CopyActivity;->tail:Landroid/view/View;

    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v6, 0x2a

    const/16 v7, 0x2a

    const v8, 0x800055

    invoke-direct {v5, v6, v7, v8}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    const/16 v6, 0xb4

    const/16 v7, 0x1b8

    invoke-virtual {v5, v6, v6, v6, v7}, Landroid/widget/FrameLayout$LayoutParams;->setMargins(IIII)V

    invoke-virtual {v0, v4, v5}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v4, Lorg/openaok/game/CopyActivity$VillagerClear;

    invoke-direct {v4, p0}, Lorg/openaok/game/CopyActivity$VillagerClear;-><init>(Lorg/openaok/game/CopyActivity;)V

    iput-object v4, p0, Lorg/openaok/game/CopyActivity;->clear:Lorg/openaok/game/CopyActivity$VillagerClear;

    new-instance v4, Landroid/widget/ImageView;

    invoke-direct {v4, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    invoke-virtual {p0}, Lorg/openaok/game/CopyActivity;->getAssets()Landroid/content/res/AssetManager;

    move-result-object v5

    const-string v6, "sound_on.png"

    invoke-virtual {v5, v6}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v5

    invoke-static {v5}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    iput-object v4, p0, Lorg/openaok/game/CopyActivity;->sound:Landroid/widget/ImageView;

    new-instance v5, Lorg/openaok/game/CopyActivity$SoundToggle;

    invoke-direct {v5, p0}, Lorg/openaok/game/CopyActivity$SoundToggle;-><init>(Lorg/openaok/game/CopyActivity;)V

    invoke-virtual {v4, v5}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v6, 0x50

    const/16 v7, 0x50

    const v8, 0x800035

    invoke-direct {v5, v6, v7, v8}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    const/16 v6, 0x14

    invoke-virtual {v5, v6, v6, v6, v6}, Landroid/widget/FrameLayout$LayoutParams;->setMargins(IIII)V

    invoke-virtual {v0, v4, v5}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v8, 0x0

    iput-boolean v8, p0, Lorg/openaok/game/CopyActivity;->muted:Z

    invoke-virtual {p0, v0}, Lorg/openaok/game/CopyActivity;->setContentView(Landroid/view/View;)V

    .line 130
    iget-object v0, p0, Lorg/openaok/game/CopyActivity;->layout:Landroid/widget/LinearLayout;

    const/16 v1, 0x1006

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setSystemUiVisibility(I)V

    .line 132
    return-void
.end method

.method private children(Landroid/net/Uri;Ljava/lang/String;)Ljava/util/Map;
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/net/Uri;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lorg/openaok/game/CopyActivity$Entry;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 254
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 255
    invoke-static {p1, p2}, Landroid/provider/DocumentsContract;->buildChildDocumentsUriUsingTree(Landroid/net/Uri;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    .line 256
    const-string p1, "_display_name"

    const-string p2, "mime_type"

    const-string v1, "document_id"

    filled-new-array {v1, p1, p2}, [Ljava/lang/String;

    move-result-object v3

    .line 259
    invoke-virtual {p0}, Lorg/openaok/game/CopyActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual/range {v1 .. v6}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p1

    .line 260
    if-eqz p1, :cond_4c

    .line 261
    :goto_20
    :try_start_20
    invoke-interface {p1}, Landroid/database/Cursor;->moveToNext()Z

    move-result p2

    if-eqz p2, :cond_44

    .line 262
    const/4 p2, 0x1

    invoke-interface {p1, p2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object p2

    new-instance v1, Lorg/openaok/game/CopyActivity$Entry;

    const/4 v2, 0x0

    invoke-interface {p1, v2}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v2

    const-string v3, "vnd.android.document/directory"

    .line 263
    const/4 v4, 0x2

    invoke-interface {p1, v4}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    invoke-direct {v1, v2, v3}, Lorg/openaok/game/CopyActivity$Entry;-><init>(Ljava/lang/String;Z)V

    .line 262
    invoke-interface {v0, p2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_43
    .catchall {:try_start_20 .. :try_end_43} :catchall_4a

    goto :goto_20

    .line 265
    :cond_44
    if-eqz p1, :cond_49

    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    .line 266
    :cond_49
    return-object v0

    .line 259
    :catchall_4a
    move-exception p2

    goto :goto_54

    .line 260
    :cond_4c
    :try_start_4c
    new-instance p2, Ljava/io/IOException;

    const-string v0, "Could not read the folder."

    invoke-direct {p2, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p2
    :try_end_54
    .catchall {:try_start_4c .. :try_end_54} :catchall_4a

    .line 259
    :goto_54
    if-eqz p1, :cond_5e

    :try_start_56
    invoke-interface {p1}, Landroid/database/Cursor;->close()V
    :try_end_59
    .catchall {:try_start_56 .. :try_end_59} :catchall_5a

    goto :goto_5e

    :catchall_5a
    move-exception p1

    invoke-virtual {p2, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_5e
    :goto_5e
    throw p2
.end method

.method private copyFiles(Landroid/net/Uri;Ljava/util/Map;Ljava/io/File;)V
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/net/Uri;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/io/File;",
            ")V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 194
    const/high16 v0, 0x100000

    new-array v0, v0, [B

    .line 195
    invoke-interface {p2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p2

    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_c
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_65

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    .line 196
    new-instance v2, Ljava/io/File;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-direct {v2, p3, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 197
    invoke-virtual {v2}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v3

    .line 198
    if-eqz v3, :cond_2c

    invoke-virtual {v3}, Ljava/io/File;->mkdirs()Z

    .line 199
    :cond_2c
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-direct {p0, p1, v1}, Lorg/openaok/game/CopyActivity;->open(Landroid/net/Uri;Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v1

    .line 200
    :try_start_36
    new-instance v3, Ljava/io/FileOutputStream;

    invoke-direct {v3, v2}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_3b
    .catchall {:try_start_36 .. :try_end_3b} :catchall_59

    .line 202
    :goto_3b
    :try_start_3b
    invoke-virtual {v1, v0}, Ljava/io/InputStream;->read([B)I

    move-result v2

    if-lez v2, :cond_46

    const/4 v4, 0x0

    invoke-virtual {v3, v0, v4, v2}, Ljava/io/OutputStream;->write([BII)V
    :try_end_45
    .catchall {:try_start_3b .. :try_end_45} :catchall_4f

    goto :goto_3b

    .line 203
    :cond_46
    :try_start_46
    invoke-virtual {v3}, Ljava/io/OutputStream;->close()V
    :try_end_49
    .catchall {:try_start_46 .. :try_end_49} :catchall_59

    if-eqz v1, :cond_4e

    invoke-virtual {v1}, Ljava/io/InputStream;->close()V

    .line 204
    :cond_4e
    goto :goto_c

    .line 199
    :catchall_4f
    move-exception p1

    :try_start_50
    invoke-virtual {v3}, Ljava/io/OutputStream;->close()V
    :try_end_53
    .catchall {:try_start_50 .. :try_end_53} :catchall_54

    goto :goto_58

    :catchall_54
    move-exception p2

    :try_start_55
    invoke-virtual {p1, p2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_58
    throw p1
    :try_end_59
    .catchall {:try_start_55 .. :try_end_59} :catchall_59

    :catchall_59
    move-exception p1

    if-eqz v1, :cond_64

    :try_start_5c
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_5f
    .catchall {:try_start_5c .. :try_end_5f} :catchall_60

    goto :goto_64

    :catchall_60
    move-exception p2

    invoke-virtual {p1, p2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_64
    :goto_64
    throw p1

    .line 205
    :cond_65
    return-void
.end method

.method private game()Ljava/io/File;
    .registers 4

    .line 76
    new-instance v0, Ljava/io/File;

    invoke-virtual {p0}, Lorg/openaok/game/CopyActivity;->getFilesDir()Ljava/io/File;

    move-result-object v1

    const-string v2, "game"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method private importMods(Landroid/net/Uri;)V
    .registers 4

    .line 158
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda7;

    invoke-direct {v1, p0, p1}, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda7;-><init>(Lorg/openaok/game/CopyActivity;Landroid/net/Uri;)V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 190
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 191
    return-void
.end method

.method private install(Landroid/net/Uri;)V
    .registers 33
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 298
    move-object/from16 v8, p0

    move-object/from16 v9, p1

    invoke-static/range {p1 .. p1}, Landroid/provider/DocumentsContract;->getTreeDocumentId(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object v0

    .line 299
    invoke-direct {v8, v9, v0}, Lorg/openaok/game/CopyActivity;->children(Landroid/net/Uri;Ljava/lang/String;)Ljava/util/Map;

    move-result-object v1

    .line 300
    const-string v2, "manifest.txt"

    invoke-interface {v1, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2e

    const-string v3, "OpenAoK-data"

    invoke-interface {v1, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2e

    invoke-interface {v1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lorg/openaok/game/CopyActivity$Entry;

    iget-boolean v4, v4, Lorg/openaok/game/CopyActivity$Entry;->folder:Z

    if-eqz v4, :cond_2e

    .line 301
    invoke-interface {v1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/openaok/game/CopyActivity$Entry;

    iget-object v0, v0, Lorg/openaok/game/CopyActivity$Entry;->id:Ljava/lang/String;

    .line 303
    :cond_2e
    new-instance v10, Ljava/util/HashMap;

    invoke-direct {v10}, Ljava/util/HashMap;-><init>()V

    .line 304
    const-string v1, ""

    invoke-direct {v8, v9, v0, v1, v10}, Lorg/openaok/game/CopyActivity;->walk(Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    .line 305
    invoke-interface {v10, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_240

    const-string v0, "version.txt"

    invoke-interface {v10, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_240

    .line 311
    const/4 v11, 0x0

    :try_start_47
    invoke-interface {v10, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-direct {v8, v9, v0}, Lorg/openaok/game/CopyActivity;->lines(Landroid/net/Uri;Ljava/lang/String;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0
    :try_end_5f
    .catch Ljava/lang/RuntimeException; {:try_start_47 .. :try_end_5f} :catch_60

    .line 314
    goto :goto_62

    .line 312
    :catch_60
    move-exception v0

    .line 313
    move v0, v11

    .line 315
    :goto_62
    sget v1, Lorg/openaok/game/BuildConfig;->DATA_VERSION:I

    if-ne v0, v1, :cond_215

    .line 322
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 323
    nop

    .line 324
    invoke-interface {v10, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-direct {v8, v9, v1}, Lorg/openaok/game/CopyActivity;->lines(Landroid/net/Uri;Ljava/lang/String;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const-wide/16 v14, 0x0

    :goto_7c
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/16 v16, 0x1

    if-eqz v2, :cond_a0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 325
    const-string v3, " "

    const/4 v4, 0x3

    invoke-virtual {v2, v3, v4}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v2

    .line 326
    array-length v3, v2

    if-eq v3, v4, :cond_95

    goto :goto_7c

    .line 327
    :cond_95
    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 328
    aget-object v2, v2, v16

    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v2

    add-long/2addr v14, v2

    .line 329
    goto :goto_7c

    .line 331
    :cond_a0
    invoke-direct/range {p0 .. p0}, Lorg/openaok/game/CopyActivity;->game()Ljava/io/File;

    move-result-object v6

    .line 332
    invoke-direct/range {p0 .. p0}, Lorg/openaok/game/CopyActivity;->marker()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    .line 333
    new-instance v1, Ljava/io/File;

    const-string v2, "build"

    invoke-direct {v1, v6, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/io/File;->mkdirs()Z

    .line 334
    const/high16 v1, 0x100000

    new-array v7, v1, [B

    .line 335
    nop

    .line 336
    nop

    .line 337
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v1, -0x1

    const-wide/16 v2, 0x0

    :goto_c2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1f3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v17, v4

    check-cast v17, [Ljava/lang/String;

    .line 338
    const/16 v18, 0x2

    aget-object v4, v17, v18

    invoke-interface {v10, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .line 339
    if-eqz v4, :cond_1d2

    .line 340
    new-instance v5, Ljava/io/File;

    aget-object v12, v17, v18

    invoke-direct {v5, v6, v12}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 341
    invoke-virtual {v5}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v12

    .line 342
    if-eqz v12, :cond_ec

    invoke-virtual {v12}, Ljava/io/File;->mkdirs()Z

    .line 343
    :cond_ec
    new-instance v12, Ljava/util/zip/CRC32;

    invoke-direct {v12}, Ljava/util/zip/CRC32;-><init>()V

    .line 344
    nop

    .line 345
    invoke-direct {v8, v9, v4}, Lorg/openaok/game/CopyActivity;->open(Landroid/net/Uri;Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v13

    :try_start_f6
    new-instance v4, Ljava/io/FileOutputStream;

    invoke-direct {v4, v5}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_fb
    .catchall {:try_start_f6 .. :try_end_fb} :catchall_1c4

    const-wide/16 v21, 0x0

    .line 347
    :goto_fd
    :try_start_fd
    invoke-virtual {v13, v7}, Ljava/io/InputStream;->read([B)I

    move-result v5

    if-lez v5, :cond_163

    .line 348
    invoke-virtual {v4, v7, v11, v5}, Ljava/io/OutputStream;->write([BII)V

    .line 349
    invoke-virtual {v12, v7, v11, v5}, Ljava/util/zip/CRC32;->update([BII)V
    :try_end_109
    .catchall {:try_start_fd .. :try_end_109} :catchall_1b6

    .line 350
    move-object/from16 v23, v12

    int-to-long v11, v5

    add-long v21, v21, v11

    .line 351
    add-long/2addr v11, v2

    .line 352
    const-wide/16 v19, 0x0

    cmp-long v2, v14, v19

    if-lez v2, :cond_121

    const-wide/16 v2, 0x3e8

    mul-long/2addr v2, v11

    :try_start_118
    div-long/2addr v2, v14
    :try_end_119
    .catchall {:try_start_118 .. :try_end_119} :catchall_11b

    long-to-int v2, v2

    goto :goto_123

    .line 345
    :catchall_11b
    move-exception v0

    move-object v1, v0

    move-object/from16 v29, v4

    goto/16 :goto_1ba

    .line 352
    :cond_121
    const/16 v2, 0x3e8

    :goto_123
    move v5, v2

    .line 353
    if-eq v5, v1, :cond_14e

    .line 354
    nop

    .line 355
    const/16 v1, 0x14

    shr-long v24, v11, v1

    shr-long v26, v14, v1

    .line 356
    :try_start_12d
    new-instance v3, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda0;
    :try_end_12f
    .catchall {:try_start_12d .. :try_end_12f} :catchall_1b6

    move-object v1, v3

    move-object/from16 v2, p0

    move-object/from16 v28, v0

    move-object v0, v3

    move v3, v5

    move-object/from16 v29, v4

    move/from16 v30, v5

    move-wide/from16 v4, v24

    move-object/from16 v24, v6

    move-object/from16 v25, v7

    move-wide/from16 v6, v26

    :try_start_142
    invoke-direct/range {v1 .. v7}, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda0;-><init>(Lorg/openaok/game/CopyActivity;IJJ)V

    invoke-virtual {v8, v0}, Lorg/openaok/game/CopyActivity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_148
    .catchall {:try_start_142 .. :try_end_148} :catchall_14b

    move/from16 v1, v30

    goto :goto_156

    .line 345
    :catchall_14b
    move-exception v0

    goto/16 :goto_1b9

    .line 353
    :cond_14e
    move-object/from16 v28, v0

    move-object/from16 v29, v4

    move-object/from16 v24, v6

    move-object/from16 v25, v7

    .line 361
    :goto_156
    move-wide v2, v11

    move-object/from16 v12, v23

    move-object/from16 v6, v24

    move-object/from16 v7, v25

    move-object/from16 v0, v28

    move-object/from16 v4, v29

    const/4 v11, 0x0

    goto :goto_fd

    .line 362
    :cond_163
    move-object/from16 v28, v0

    move-object/from16 v29, v4

    move-object/from16 v24, v6

    move-object/from16 v25, v7

    move-object/from16 v23, v12

    const-wide/16 v19, 0x0

    :try_start_16f
    invoke-virtual/range {v29 .. v29}, Ljava/io/OutputStream;->close()V
    :try_end_172
    .catchall {:try_start_16f .. :try_end_172} :catchall_1c4

    if-eqz v13, :cond_177

    invoke-virtual {v13}, Ljava/io/InputStream;->close()V

    .line 363
    :cond_177
    aget-object v0, v17, v16

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4

    cmp-long v0, v21, v4

    if-nez v0, :cond_19b

    invoke-virtual/range {v23 .. v23}, Ljava/util/zip/CRC32;->getValue()J

    move-result-wide v4

    const/4 v6, 0x0

    aget-object v0, v17, v6

    const/16 v7, 0x10

    invoke-static {v0, v7}, Ljava/lang/Long;->parseLong(Ljava/lang/String;I)J

    move-result-wide v11

    cmp-long v0, v4, v11

    if-nez v0, :cond_19b

    .line 366
    move v11, v6

    move-object/from16 v6, v24

    move-object/from16 v7, v25

    move-object/from16 v0, v28

    goto/16 :goto_c2

    .line 364
    :cond_19b
    new-instance v0, Ljava/io/IOException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v2, v17, v18

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " in the folder is damaged: copy the folder to the phone again."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 345
    :catchall_1b6
    move-exception v0

    move-object/from16 v29, v4

    :goto_1b9
    move-object v1, v0

    :goto_1ba
    :try_start_1ba
    invoke-virtual/range {v29 .. v29}, Ljava/io/OutputStream;->close()V
    :try_end_1bd
    .catchall {:try_start_1ba .. :try_end_1bd} :catchall_1be

    goto :goto_1c3

    :catchall_1be
    move-exception v0

    move-object v2, v0

    :try_start_1c0
    invoke-virtual {v1, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_1c3
    throw v1
    :try_end_1c4
    .catchall {:try_start_1c0 .. :try_end_1c4} :catchall_1c4

    :catchall_1c4
    move-exception v0

    move-object v1, v0

    if-eqz v13, :cond_1d1

    :try_start_1c8
    invoke-virtual {v13}, Ljava/io/InputStream;->close()V
    :try_end_1cb
    .catchall {:try_start_1c8 .. :try_end_1cb} :catchall_1cc

    goto :goto_1d1

    :catchall_1cc
    move-exception v0

    move-object v2, v0

    invoke-virtual {v1, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_1d1
    :goto_1d1
    throw v1

    .line 339
    :cond_1d2
    new-instance v0, Ljava/io/IOException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "The folder is missing "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    aget-object v2, v17, v18

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ": copy it to the phone again."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 367
    :cond_1f3
    new-instance v1, Ljava/io/FileWriter;

    invoke-direct/range {p0 .. p0}, Lorg/openaok/game/CopyActivity;->marker()Ljava/io/File;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/io/FileWriter;-><init>(Ljava/io/File;)V

    .line 368
    :try_start_1fc
    sget v0, Lorg/openaok/game/BuildConfig;->DATA_VERSION:I

    invoke-static {v0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/io/FileWriter;->write(Ljava/lang/String;)V
    :try_end_205
    .catchall {:try_start_1fc .. :try_end_205} :catchall_209

    .line 369
    invoke-virtual {v1}, Ljava/io/FileWriter;->close()V

    .line 370
    return-void

    .line 367
    :catchall_209
    move-exception v0

    move-object v2, v0

    :try_start_20b
    invoke-virtual {v1}, Ljava/io/FileWriter;->close()V
    :try_end_20e
    .catchall {:try_start_20b .. :try_end_20e} :catchall_20f

    goto :goto_214

    :catchall_20f
    move-exception v0

    move-object v1, v0

    invoke-virtual {v2, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_214
    throw v2

    .line 316
    :cond_215
    new-instance v1, Ljava/io/IOException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "That folder holds game data of version "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, "; this OpenAoK plays from version "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    sget v2, Lorg/openaok/game/BuildConfig;->DATA_VERSION:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, ". Make it again with this release\'s source code."

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 306
    :cond_240
    new-instance v0, Ljava/io/IOException;

    const-string v1, "That folder is not the game\'s data: choose the OpenAoK-data folder made by android/package.py."

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method private installedVersion()I
    .registers 4

    .line 86
    :try_start_0
    new-instance v0, Ljava/lang/String;

    invoke-direct {p0}, Lorg/openaok/game/CopyActivity;->marker()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/File;->toPath()Ljava/nio/file/Path;

    move-result-object v1

    invoke-static {v1}, Ljava/nio/file/Files;->readAllBytes(Ljava/nio/file/Path;)[B

    move-result-object v1

    sget-object v2, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v0, v1, v2}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0
    :try_end_1b
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_1b} :catch_1c
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_1b} :catch_1c

    return v0

    .line 87
    :catch_1c
    move-exception v0

    .line 88
    const/4 v0, 0x0

    return v0
.end method

.method private lines(Landroid/net/Uri;Ljava/lang/String;)Ljava/util/List;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/net/Uri;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 288
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 289
    new-instance v1, Ljava/io/BufferedReader;

    new-instance v2, Ljava/io/InputStreamReader;

    invoke-direct {p0, p1, p2}, Lorg/openaok/game/CopyActivity;->open(Landroid/net/Uri;Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object p1

    sget-object p2, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v2, p1, p2}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    invoke-direct {v1, v2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 291
    :goto_15
    :try_start_15
    invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_1f

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_1e
    .catchall {:try_start_15 .. :try_end_1e} :catchall_23

    goto :goto_15

    .line 292
    :cond_1f
    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V

    .line 293
    return-object v0

    .line 289
    :catchall_23
    move-exception p1

    :try_start_24
    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V
    :try_end_27
    .catchall {:try_start_24 .. :try_end_27} :catchall_28

    goto :goto_2c

    :catchall_28
    move-exception p2

    invoke-virtual {p1, p2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_2c
    throw p1
.end method

.method private marker()Ljava/io/File;
    .registers 4

    .line 80
    new-instance v0, Ljava/io/File;

    invoke-direct {p0}, Lorg/openaok/game/CopyActivity;->game()Ljava/io/File;

    move-result-object v1

    const-string v2, ".installed"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method private menuButton(Ljava/lang/String;)Landroid/widget/Button;
    .registers 7

    .line 135
    new-instance v0, Landroid/widget/Button;

    invoke-direct {v0, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 136
    invoke-virtual {v0, p1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    sget-object v1, Landroid/graphics/Typeface;->SERIF:Landroid/graphics/Typeface;

    const/4 v2, 0x1

    invoke-static {v1, v2}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setTypeface(Landroid/graphics/Typeface;)V

    .line 137
    const/4 p1, 0x0

    invoke-virtual {v0, p1}, Landroid/widget/Button;->setAllCaps(Z)V

    .line 138
    const/high16 v1, 0x41b00000    # 22.0f

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setTextSize(F)V

    .line 139
    const/16 v1, 0xdc

    const/16 v2, 0xbe

    const/16 v3, 0xeb

    invoke-static {v3, v1, v2}, Landroid/graphics/Color;->rgb(III)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setTextColor(I)V

    .line 140
    const/16 v1, 0x14

    const/16 v2, 0xf

    const/16 v3, 0xb4

    const/16 v4, 0x19

    invoke-static {v3, v4, v1, v2}, Landroid/graphics/Color;->argb(IIII)I

    move-result v1

    new-instance v2, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const v1, 0x1a8c6b2e

    invoke-virtual {v2, v1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/4 v1, 0x1

    const v3, 0xcc8c6b2e

    invoke-virtual {v2, v1, v3}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    const/high16 v1, 0x40c00000

    invoke-virtual {v2, v1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/high16 v1, 0x40200000

    const/4 v2, 0x0

    const v3, 0xcc000000

    invoke-virtual {v0, v1, v2, v2, v3}, Landroid/widget/Button;->setShadowLayer(FFFI)V

    .line 141
    const v1, 0x800013

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setGravity(I)V

    .line 142
    const/16 v1, 0x30

    invoke-virtual {v0, v1, p1, v1, p1}, Landroid/widget/Button;->setPadding(IIII)V

    .line 143
    return-object v0
.end method

.method private menuParams()Landroid/widget/LinearLayout$LayoutParams;
    .registers 4

    .line 147
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v1, 0x230

    const/16 v2, 0x6e

    invoke-direct {v0, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 148
    const/4 v1, 0x0

    const/16 v2, 0xa

    invoke-virtual {v0, v1, v2, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 149
    return-object v0
.end method

.method private open(Landroid/net/Uri;Ljava/lang/String;)Ljava/io/InputStream;
    .registers 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 282
    invoke-virtual {p0}, Lorg/openaok/game/CopyActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    invoke-static {p1, p2}, Landroid/provider/DocumentsContract;->buildDocumentUriUsingTree(Landroid/net/Uri;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object p1

    .line 283
    if-eqz p1, :cond_f

    .line 284
    return-object p1

    .line 283
    :cond_f
    new-instance p1, Ljava/io/IOException;

    const-string p2, "Could not open a file in the folder."

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method private pickMods()V
    .registers 3

    .line 153
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.OPEN_DOCUMENT_TREE"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 154
    const/4 v1, 0x2

    invoke-virtual {p0, v0, v1}, Lorg/openaok/game/CopyActivity;->startActivityForResult(Landroid/content/Intent;I)V

    .line 155
    return-void
.end method

.method private play()V
    .registers 3

    .line 373
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lorg/openaok/game/GameActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lorg/openaok/game/CopyActivity;->startActivity(Landroid/content/Intent;)V

    .line 375
    return-void
.end method

.method private show(Ljava/lang/String;Z)V
    .registers 5

    .line 210
    iget-object v0, p0, Lorg/openaok/game/CopyActivity;->status:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 211
    iget-object p1, p0, Lorg/openaok/game/CopyActivity;->bar:Landroid/widget/ProgressBar;

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Landroid/widget/ProgressBar;->setVisibility(I)V

    .line 212
    iget-object p1, p0, Lorg/openaok/game/CopyActivity;->choose:Landroid/widget/Button;

    const/4 v1, 0x0

    invoke-virtual {p1, v1}, Landroid/widget/Button;->setVisibility(I)V

    .line 213
    iget-object p1, p0, Lorg/openaok/game/CopyActivity;->play:Landroid/widget/Button;

    if-eqz p2, :cond_17

    move v0, v1

    :cond_17
    invoke-virtual {p1, v0}, Landroid/widget/Button;->setVisibility(I)V

    .line 214
    iget-object p1, p0, Lorg/openaok/game/CopyActivity;->mods:Landroid/widget/Button;

    invoke-direct {p0}, Lorg/openaok/game/CopyActivity;->installedVersion()I

    move-result p2

    if-lez p2, :cond_23

    const/4 v1, 0x1

    :cond_23
    invoke-virtual {p1, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 215
    return-void
.end method

.method private walk(Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/net/Uri;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 271
    invoke-direct {p0, p1, p2}, Lorg/openaok/game/CopyActivity;->children(Landroid/net/Uri;Ljava/lang/String;)Ljava/util/Map;

    move-result-object p2

    invoke-interface {p2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p2

    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_c
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_64

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    .line 272
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 273
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lorg/openaok/game/CopyActivity$Entry;

    iget-boolean v2, v2, Lorg/openaok/game/CopyActivity$Entry;->folder:Z

    if-eqz v2, :cond_58

    .line 274
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/openaok/game/CopyActivity$Entry;

    iget-object v0, v0, Lorg/openaok/game/CopyActivity$Entry;->id:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, p1, v0, v1, p4}, Lorg/openaok/game/CopyActivity;->walk(Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    goto :goto_63

    .line 276
    :cond_58
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lorg/openaok/game/CopyActivity$Entry;

    iget-object v0, v0, Lorg/openaok/game/CopyActivity$Entry;->id:Ljava/lang/String;

    invoke-interface {p4, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 278
    :goto_63
    goto :goto_c

    .line 279
    :cond_64
    return-void
.end method


# virtual methods
.method synthetic lambda$build$0$org-openaok-game-CopyActivity(Landroid/view/View;)V
    .registers 2

    .line 114
    invoke-direct {p0}, Lorg/openaok/game/CopyActivity;->play()V

    return-void
.end method

.method synthetic lambda$build$1$org-openaok-game-CopyActivity(Landroid/view/View;)V
    .registers 2

    .line 116
    invoke-direct {p0}, Lorg/openaok/game/CopyActivity;->pickMods()V

    return-void
.end method

.method synthetic lambda$build$2$org-openaok-game-CopyActivity(Landroid/view/View;)V
    .registers 3

    .line 119
    new-instance p1, Landroid/content/Intent;

    const-string v0, "android.intent.action.OPEN_DOCUMENT_TREE"

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 120
    const/4 v0, 0x1

    invoke-virtual {p0, p1, v0}, Lorg/openaok/game/CopyActivity;->startActivityForResult(Landroid/content/Intent;I)V

    .line 121
    return-void
.end method

.method synthetic lambda$importMods$3$org-openaok-game-CopyActivity(Ljava/util/List;)V
    .registers 4

    .line 184
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "\u5df2\u5bfc\u5165 MOD\uff1a"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    .line 185
    const-string v1, ", "

    invoke-static {v1, p1}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 184
    const/4 v0, 0x1

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    .line 185
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 184
    return-void
.end method

.method synthetic lambda$importMods$4$org-openaok-game-CopyActivity(Ljava/lang/Exception;)V
    .registers 4

    .line 187
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "\u5bfc\u5165 MOD \u5931\u8d25\uff1a"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x1

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    .line 188
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 187
    return-void
.end method

.method synthetic lambda$importMods$5$org-openaok-game-CopyActivity(Landroid/net/Uri;)V
    .registers 10

    .line 160
    :try_start_0
    new-instance v0, Ljava/io/File;

    invoke-direct {p0}, Lorg/openaok/game/CopyActivity;->game()Ljava/io/File;

    move-result-object v1

    const-string v2, "mods"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 161
    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    .line 162
    invoke-static {p1}, Landroid/provider/DocumentsContract;->getTreeDocumentId(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object v1

    .line 163
    invoke-direct {p0, p1, v1}, Lorg/openaok/game/CopyActivity;->children(Landroid/net/Uri;Ljava/lang/String;)Ljava/util/Map;

    move-result-object v2

    .line 164
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 165
    const-string v4, "mod.json"

    invoke-interface {v2, v4}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v4
    :try_end_21
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_21} :catch_a6

    const-string v5, ""

    if-eqz v4, :cond_53

    .line 166
    :try_start_25
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "imported_"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    invoke-virtual {v2, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 167
    new-instance v4, Ljava/io/File;

    invoke-direct {v4, v0, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 168
    invoke-virtual {v4}, Ljava/io/File;->mkdirs()Z

    .line 169
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 170
    invoke-direct {p0, p1, v1, v5, v0}, Lorg/openaok/game/CopyActivity;->walk(Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    .line 171
    invoke-direct {p0, p1, v0, v4}, Lorg/openaok/game/CopyActivity;->copyFiles(Landroid/net/Uri;Ljava/util/Map;Ljava/io/File;)V

    .line 172
    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 173
    goto :goto_9d

    .line 174
    :cond_53
    invoke-interface {v2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_5b
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_9d

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    .line 175
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lorg/openaok/game/CopyActivity$Entry;

    iget-boolean v4, v4, Lorg/openaok/game/CopyActivity$Entry;->folder:Z

    if-nez v4, :cond_72

    goto :goto_5b

    .line 176
    :cond_72
    new-instance v4, Ljava/io/File;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-direct {v4, v0, v6}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 177
    invoke-virtual {v4}, Ljava/io/File;->mkdirs()Z

    .line 178
    new-instance v6, Ljava/util/HashMap;

    invoke-direct {v6}, Ljava/util/HashMap;-><init>()V

    .line 179
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lorg/openaok/game/CopyActivity$Entry;

    iget-object v7, v7, Lorg/openaok/game/CopyActivity$Entry;->id:Ljava/lang/String;

    invoke-direct {p0, p1, v7, v5, v6}, Lorg/openaok/game/CopyActivity;->walk(Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V

    .line 180
    invoke-direct {p0, p1, v6, v4}, Lorg/openaok/game/CopyActivity;->copyFiles(Landroid/net/Uri;Ljava/util/Map;Ljava/io/File;)V

    .line 181
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 182
    goto :goto_5b

    .line 184
    :cond_9d
    :goto_9d
    new-instance p1, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda5;

    invoke-direct {p1, p0, v3}, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda5;-><init>(Lorg/openaok/game/CopyActivity;Ljava/util/List;)V

    invoke-virtual {p0, p1}, Lorg/openaok/game/CopyActivity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_a5
    .catch Ljava/lang/Exception; {:try_start_25 .. :try_end_a5} :catch_a6

    .line 189
    goto :goto_af

    .line 186
    :catch_a6
    move-exception p1

    .line 187
    new-instance v0, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda6;

    invoke-direct {v0, p0, p1}, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda6;-><init>(Lorg/openaok/game/CopyActivity;Ljava/lang/Exception;)V

    invoke-virtual {p0, v0}, Lorg/openaok/game/CopyActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 190
    :goto_af
    return-void
.end method

.method synthetic lambda$install$8$org-openaok-game-CopyActivity(IJJ)V
    .registers 10

    .line 357
    iget-object v0, p0, Lorg/openaok/game/CopyActivity;->bar:Landroid/widget/ProgressBar;
    invoke-virtual {v0, p1}, Landroid/widget/ProgressBar;->setProgress(I)V

    const/16 v0, 0xc
    new-array v0, v0, [Ljava/lang/String;
    const/4 v1, 0
    const-string v2, "正在伐木"
    aput-object v2, v0, v1
    const/4 v1, 1
    const-string v2, "正在采石"
    aput-object v2, v0, v1
    const/4 v1, 2
    const-string v2, "正在采金"
    aput-object v2, v0, v1
    const/4 v1, 3
    const-string v2, "正在种田"
    aput-object v2, v0, v1
    const/4 v1, 4
    const-string v2, "正在狩猎"
    aput-object v2, v0, v1
    const/4 v1, 5
    const-string v2, "正在捕鱼"
    aput-object v2, v0, v1
    const/4 v1, 6
    const-string v2, "正在建造"
    aput-object v2, v0, v1
    const/4 v1, 7
    const-string v2, "正在研究"
    aput-object v2, v0, v1
    const/16 v1, 8
    const-string v2, "正在训练"
    aput-object v2, v0, v1
    const/16 v1, 9
    const-string v2, "正在探索地图"
    aput-object v2, v0, v1
    const/16 v1, 10
    const-string v2, "正在赶羊"
    aput-object v2, v0, v1
    const/16 v1, 11
    const-string v2, "正在收集食物"
    aput-object v2, v0, v1
    rem-int/lit8 v1, p1, 0xc
    aget-object v1, v0, v1

    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1, "  "
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-static {p2, p3}, Ljava/lang/Long;->toString(J)Ljava/lang/String;
    move-result-object v1
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1, " / "
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-static {p4, p5}, Ljava/lang/Long;->toString(J)Ljava/lang/String;
    move-result-object v1
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v1, " MB"
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lorg/openaok/game/CopyActivity;->status:Landroid/widget/TextView;
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v1
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method synthetic lambda$onActivityResult$6$org-openaok-game-CopyActivity(Ljava/io/IOException;Z)V
    .registers 3

    .line 237
    invoke-virtual {p1}, Ljava/io/IOException;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1, p2}, Lorg/openaok/game/CopyActivity;->show(Ljava/lang/String;Z)V

    return-void
.end method

.method synthetic lambda$onActivityResult$7$org-openaok-game-CopyActivity(Landroid/net/Uri;)V
    .registers 4

    .line 233
    :try_start_0
    invoke-direct {p0, p1}, Lorg/openaok/game/CopyActivity;->install(Landroid/net/Uri;)V

    .line 234
    new-instance p1, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda8;

    invoke-direct {p1, p0}, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda8;-><init>(Lorg/openaok/game/CopyActivity;)V

    invoke-virtual {p0, p1}, Lorg/openaok/game/CopyActivity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_b
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_b} :catch_c

    .line 238
    goto :goto_1e

    .line 235
    :catch_c
    move-exception p1

    .line 236
    invoke-direct {p0}, Lorg/openaok/game/CopyActivity;->installedVersion()I

    move-result v0

    if-lez v0, :cond_15

    const/4 v0, 0x1

    goto :goto_16

    :cond_15
    const/4 v0, 0x0

    .line 237
    :goto_16
    new-instance v1, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda9;

    invoke-direct {v1, p0, p1, v0}, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda9;-><init>(Lorg/openaok/game/CopyActivity;Ljava/io/IOException;Z)V

    invoke-virtual {p0, v1}, Lorg/openaok/game/CopyActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 239
    :goto_1e
    return-void
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .registers 6

    .line 219
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    .line 220
    const/4 v0, 0x2

    const/4 v1, -0x1

    if-ne p1, v0, :cond_19

    .line 221
    if-ne p2, v1, :cond_18

    if-eqz p3, :cond_18

    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    if-eqz p1, :cond_18

    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    invoke-direct {p0, p1}, Lorg/openaok/game/CopyActivity;->importMods(Landroid/net/Uri;)V

    .line 222
    :cond_18
    return-void

    .line 224
    :cond_19
    const/4 v0, 0x1

    if-ne p1, v0, :cond_5b

    if-ne p2, v1, :cond_5b

    if-eqz p3, :cond_5b

    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    if-nez p1, :cond_27

    goto :goto_5b

    .line 225
    :cond_27
    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    .line 226
    iget-object p2, p0, Lorg/openaok/game/CopyActivity;->choose:Landroid/widget/Button;

    const/16 p3, 0x8

    invoke-virtual {p2, p3}, Landroid/widget/Button;->setVisibility(I)V

    .line 227
    iget-object p2, p0, Lorg/openaok/game/CopyActivity;->play:Landroid/widget/Button;

    invoke-virtual {p2, p3}, Landroid/widget/Button;->setVisibility(I)V

    .line 228
    iget-object p2, p0, Lorg/openaok/game/CopyActivity;->bar:Landroid/widget/ProgressBar;

    const/4 p3, 0x0

    invoke-virtual {p2, p3}, Landroid/widget/ProgressBar;->setVisibility(I)V

    .line 229
    iget-object p2, p0, Lorg/openaok/game/CopyActivity;->bar:Landroid/widget/ProgressBar;

    invoke-virtual {p2, p3}, Landroid/widget/ProgressBar;->setProgress(I)V

    .line 230
    iget-object p2, p0, Lorg/openaok/game/CopyActivity;->status:Landroid/widget/TextView;

    sget p3, Lorg/openaok/game/R$string;->reading:I

    invoke-virtual {p0, p3}, Lorg/openaok/game/CopyActivity;->getString(I)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 231
    new-instance p2, Ljava/lang/Thread;

    new-instance p3, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda4;

    invoke-direct {p3, p0, p1}, Lorg/openaok/game/CopyActivity$$ExternalSyntheticLambda4;-><init>(Lorg/openaok/game/CopyActivity;Landroid/net/Uri;)V

    invoke-direct {p2, p3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 239
    invoke-virtual {p2}, Ljava/lang/Thread;->start()V

    .line 240
    return-void

    .line 224
    :cond_5b
    :goto_5b
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 4

    .line 60
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 61
    invoke-virtual {p0}, Lorg/openaok/game/CopyActivity;->getWindow()Landroid/view/Window;

    move-result-object p1

    const/16 v0, 0x80

    invoke-virtual {p1, v0}, Landroid/view/Window;->addFlags(I)V

    .line 62
    invoke-direct {p0}, Lorg/openaok/game/CopyActivity;->installedVersion()I

    move-result p1

    .line 63
    invoke-direct {p0}, Lorg/openaok/game/CopyActivity;->build()V

    .line 64
    sget v0, Lorg/openaok/game/BuildConfig;->DATA_VERSION:I

    const/4 v1, 0x1

    if-ne p1, v0, :cond_2d

    .line 66
    iget-object p1, p0, Lorg/openaok/game/CopyActivity;->play:Landroid/widget/Button;

    sget v0, Lorg/openaok/game/R$string;->play:I

    invoke-virtual {p0, v0}, Lorg/openaok/game/CopyActivity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 67
    const-string p1, ""

    invoke-direct {p0, p1, v1}, Lorg/openaok/game/CopyActivity;->show(Ljava/lang/String;Z)V

    goto :goto_43

    .line 68
    :cond_2d
    if-lez p1, :cond_39

    .line 69
    sget p1, Lorg/openaok/game/R$string;->launch_newer:I

    invoke-virtual {p0, p1}, Lorg/openaok/game/CopyActivity;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1, v1}, Lorg/openaok/game/CopyActivity;->show(Ljava/lang/String;Z)V

    goto :goto_43

    .line 71
    :cond_39
    sget p1, Lorg/openaok/game/R$string;->launch_need:I

    invoke-virtual {p0, p1}, Lorg/openaok/game/CopyActivity;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lorg/openaok/game/CopyActivity;->show(Ljava/lang/String;Z)V

    .line 73
    :goto_43
    return-void
.end method

.method protected onResume()V
    .registers 3
    invoke-super {p0}, Landroid/app/Activity;->onResume()V
    iget-object v0, p0, Lorg/openaok/game/CopyActivity;->video:Landroid/widget/VideoView;
    if-eqz v0, :done
    iget-object v1, p0, Lorg/openaok/game/CopyActivity;->videoUri:Landroid/net/Uri;
    if-eqz v1, :play
    invoke-virtual {v0, v1}, Landroid/widget/VideoView;->setVideoURI(Landroid/net/Uri;)V
    :play
    const/4 v1, 0x0
    invoke-virtual {v0, v1}, Landroid/widget/VideoView;->seekTo(I)V
    invoke-virtual {v0}, Landroid/widget/VideoView;->start()V
    :done
    return-void
.end method

.method protected onPause()V
    .registers 2
    iget-object v0, p0, Lorg/openaok/game/CopyActivity;->video:Landroid/widget/VideoView;
    if-eqz v0, :done
    invoke-virtual {v0}, Landroid/widget/VideoView;->pause()V
    :done
    invoke-super {p0}, Landroid/app/Activity;->onPause()V
    return-void
.end method
