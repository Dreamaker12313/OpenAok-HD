.class public final Lorg/openaok/game/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/openaok/game/R$drawable;,
        Lorg/openaok/game/R$mipmap;,
        Lorg/openaok/game/R$string;,
        Lorg/openaok/game/R$style;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
