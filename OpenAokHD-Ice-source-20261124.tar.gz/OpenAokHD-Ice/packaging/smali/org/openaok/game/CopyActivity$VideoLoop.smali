.class public final Lorg/openaok/game/CopyActivity$VideoLoop;
.super Ljava/lang/Object;
.implements Landroid/media/MediaPlayer$OnCompletionListener;

.field private final activity:Lorg/openaok/game/CopyActivity;

.method public constructor <init>(Lorg/openaok/game/CopyActivity;)V
    .registers 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    iput-object p1, p0, Lorg/openaok/game/CopyActivity$VideoLoop;->activity:Lorg/openaok/game/CopyActivity;
    return-void
.end method

.method public onCompletion(Landroid/media/MediaPlayer;)V
    .registers 2
    iget-object v0, p0, Lorg/openaok/game/CopyActivity$VideoLoop;->activity:Lorg/openaok/game/CopyActivity;
    iget-object v0, v0, Lorg/openaok/game/CopyActivity;->video:Landroid/widget/VideoView;
    invoke-virtual {v0}, Landroid/widget/VideoView;->start()V
    return-void
.end method
