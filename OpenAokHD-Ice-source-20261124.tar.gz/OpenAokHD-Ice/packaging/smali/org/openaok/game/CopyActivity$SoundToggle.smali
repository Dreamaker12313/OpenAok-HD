.class public final Lorg/openaok/game/CopyActivity$SoundToggle;
.super Ljava/lang/Object;
.implements Landroid/view/View$OnClickListener;

.field private final activity:Lorg/openaok/game/CopyActivity;

.method public constructor <init>(Lorg/openaok/game/CopyActivity;)V
    .registers 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    iput-object p1, p0, Lorg/openaok/game/CopyActivity$SoundToggle;->activity:Lorg/openaok/game/CopyActivity;
    return-void
.end method

.method public onClick(Landroid/view/View;)V
    .registers 6
    iget-object v0, p0, Lorg/openaok/game/CopyActivity$SoundToggle;->activity:Lorg/openaok/game/CopyActivity;
    iget-boolean v1, v0, Lorg/openaok/game/CopyActivity;->muted:Z
    xor-int/lit8 v1, v1, 0x1
    iput-boolean v1, v0, Lorg/openaok/game/CopyActivity;->muted:Z
    :try_start
    invoke-virtual {v0}, Lorg/openaok/game/CopyActivity;->getAssets()Landroid/content/res/AssetManager;
    move-result-object v2
    if-eqz v1, :on
    const-string v3, "sound_off.png"
    goto :name
    :on
    const-string v3, "sound_on.png"
    :name
    invoke-virtual {v2, v3}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;
    move-result-object v2
    invoke-static {v2}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;
    move-result-object v2
    iget-object v3, v0, Lorg/openaok/game/CopyActivity;->sound:Landroid/widget/ImageView;
    invoke-virtual {v3, v2}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V
    :try_end
    .catch Ljava/lang/Exception; {:try_start .. :try_end} :catch
    return-void
    :catch
    return-void
.end method
