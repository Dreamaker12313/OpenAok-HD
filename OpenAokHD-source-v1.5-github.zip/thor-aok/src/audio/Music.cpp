#include "audio/Music.h"

#include <algorithm>
#include <filesystem>
#include <string>
#include <vector>

#include "hal/Audio.h"

namespace Audio::Music {

namespace {

const char* kStream = "../original_game_1999/GAME/SOUND/STREAM/";

// The civilisations' themes by dat civ id.
const char* kCivThemes[] = {
    "RANDOM.MP3",                                   // 0: random
    "BRITISH.MP3", "FRENCH.MP3", "GOTH.MP3", "TEUTON.MP3", "JAPANESE.MP3",
    "CHINESE.MP3", "BYZANTIN.MP3", "PERSIAN.MP3", "SARACEN.MP3", "TURK.MP3",
    "VIKING.MP3", "MONGOL.MP3", "CELT.MP3",
    "SPANISH.MP3", "AZTECS.MP3", "MAYANS.MP3", "HUNS.MP3", "KOREANS.MP3",
    "ITALIANS.MP3", "INDIANS.MP3", "SLAVS.MP3", "MAGYARS.MP3", "INCAS.MP3",
    "PORTUGUESE.MP3", "ETHIOPIANS.MP3", "MALIANS.MP3", "BERBERS.MP3",
    "KHMER.MP3", "MALAY.MP3", "BURMESE.MP3", "VIETNAMESE.MP3",
};

enum class Mode { None, Menus, Game, Once };

struct State {
    Mode mode = Mode::None;
    int next_track = 1;   // the playlist's next stream\music%d.mp3
    int civ = 0;
    int expansion = 0;
    size_t shared_index = 0;
    bool shared_started = false;
    std::vector<std::string> shared;
    bool jingle = false;  // the civ theme is playing, playlist follows
};

State& S() {
    static State state;
    return state;
}

bool Play(const std::string& name, bool loop) {
    return HAL::Audio::PlayMusic(std::string(kStream) + name, loop);
}

// The shared in-game tracks of the civilisation's expansion. HD keeps three
// sets: Age of Kings, The Conquerors, and the three DLCs (which share the
// Rise of the Rajas set). The converter does not carry these yet; loose files
// placed under these folders are picked up.
void LoadShared(State& s) {
    s.shared.clear();
    s.shared_index = 0;
    s.shared_started = false;
    // HD stores one flat numbered playlist: xmusic1.mp3 .. xmusic23.mp3.
    const char* dir = "../assets/original/Sound/music";
    std::error_code ec;
    for (const auto& e : std::filesystem::directory_iterator(dir, ec)) {
        if (e.is_regular_file() && e.path().extension() == ".mp3") {
            s.shared.push_back(e.path().string());
        }
    }
    std::sort(s.shared.begin(), s.shared.end(), [](const std::string& a, const std::string& b) {
        auto number = [](const std::string& path) {
            const std::string name = std::filesystem::path(path).stem().string();
            int n = 0;
            for (char c : name) if (c >= '0' && c <= '9') n = n * 10 + (c - '0');
            return n;
        };
        return number(a) < number(b);
    });
}

bool NextShared(State& s) {
    if (s.shared.empty()) return false;
    s.shared_started = true;
    const std::string& track = s.shared[s.shared_index % s.shared.size()];
    if (HAL::Audio::PlayMusic(track, false)) {
        ++s.shared_index;
        return true;
    }
    return false;
}

// The playlist's next track that exists, round from the first again.
bool NextInPlaylist() {
    State& s = S();
    for (int tries = 0; tries < 2; ++tries) {
        const std::string name = "MUSIC" + std::to_string(s.next_track) + ".MP3";
        if (std::filesystem::exists(std::string(kStream) + name) && Play(name, false)) {
            ++s.next_track;
            return true;
        }
        if (s.next_track == 1) return false;   // none at all
        s.next_track = 1;
    }
    return false;
}

} // namespace

void Menus() {
    State& s = S();
    if (s.mode == Mode::Menus && HAL::Audio::MusicPlaying()) return;
    s.mode = Mode::Menus;
    Play("OPEN.MP3", true);
}

void Credits() {
    S().mode = Mode::Once;
    Play("CREDITS.MP3", false);
}

void Game(int civ, int campaign, int scenario) {
    (void)civ;
    (void)campaign;
    (void)scenario;
    State& s = S();
    s.mode = Mode::Game;
    s.jingle = false;
    HAL::Audio::StopMusic();
    s.next_track = 1;
    LoadShared(s);
    // The in-game soundtrack is the shared xmusic list, from the first track
    // in order; campaign-specific tracks are not used.
    if (!NextShared(s)) NextInPlaylist();
}

void Ended(bool won) {
    S().mode = Mode::Once;
    Play(won ? "WON1.MP3" : "LOST.MP3", false);
}

void Civ(int civ) {
    if (civ < 0 || civ >= static_cast<int>(std::size(kCivThemes))) return;
    S().mode = Mode::Once;
    Play(kCivThemes[civ], false);
}

void SetVolume(int volume) {
    HAL::Audio::SetMusicVolume(static_cast<float>(volume) / 10.0f);
}

void Update() {
    HAL::Audio::PumpMusic();
    State& s = S();
    if (HAL::Audio::MusicPlaying()) return;
    // A track has ended: the menus go back to their own, a game to the next
    // of its playlist. The first track is the civ jingle, then the expansion
    // playlist; with no shared files, the civ theme repeats to keep music on.
    if (s.mode == Mode::Game) {
        if (s.jingle) s.jingle = false;
        if (!NextShared(s)) NextInPlaylist();
    }
}

} // namespace Audio::Music
