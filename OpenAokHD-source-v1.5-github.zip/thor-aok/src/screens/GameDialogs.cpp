#include "GameDialogs.h"

#include "Achievements.h"
#include "Screens.h"
#include "Sin.h"
#include "TechTree.h"
#include "Widgets.h"
#include "audio/InterfaceSounds.h"
#include "audio/Music.h"
#include "core/CommandQueue.h"
#include "core/Hotkeys.h"
#include "core/GameSetup.h"
#include "core/Profile.h"
#include "core/Strings.h"
#include "core/ConfigManager.h"
#include "core/Types.h"
#include "ecs/Chat.h"
#include "ecs/Cheats.h"
#include "ecs/Diplomacy.h"
#include "ecs/Players.h"
#include "ecs/Triggers.h"
#include "ecs/Tribute.h"
#include "ecs/Victory.h"
#include "ecs/Vision.h"
#include "hal/Audio.h"
#include "hal/GraphicCache.h"
#include "hal/TextInput.h"
#include "hal/stb/stb_image.h"
#include "hal/Touch.h"
#include "hal/Window.h"
#include "rendering/Messages.h"
#include "rendering/UIRenderer.h"
#include "rendering/Text.h"

#include <algorithm>
#include <filesystem>
#include <cstdio>
#include <string>
#include <vector>

namespace GameDialogs {

namespace Text = Rendering::Text;
using Core::Strings::Get;
using namespace Screens;

namespace {

struct Shared {
    Dialog dialog = Dialog::None;
    Outcome outcome = Outcome::None;
    bool paused = false;
    // The question a Confirm dialog asks, and what yes does.
    int question = -1;
    Outcome on_yes = Outcome::None;
    // The end of the game: the message shown, when it began.
    int over_message = -1;
    bool ended = false;          // Outcome::Ended handed out
    uint32_t over_at = 0;
    // The Achievements screen: its page, its buttons, why it opened; and
    // whether this is a game against the computer, which offers Play Again.
    Achievements::State achievements;
    bool single_player = true;
    // The Objectives dialog's tab -- 0 the objectives, 1 the hints -- and
    // the first line shown of its text.
    int objectives_tab = 0;
    int objectives_scroll = 0;
    int mx = -1, my = -1;
    bool held = false;
    // The Diplomacy dialog's choices, applied only on OK: the stance toward
    // each player, the tribute heaped on each icon, allied victory.
    uint8_t stance[Core::kMaxPlayers] = {};
    int tribute[Core::kMaxPlayers][4] = {};
    bool allied_victory = false;
    bool diplomacy_fresh = false;
    // The Chat dialog's choice of who hears, and what is being typed there or
    // on the chat line.
    bool hears[Core::kMaxPlayers] = {};
    TextField chat;
    // The Options dialog: the screen size chosen, the three sliders and the
    // three checks, applied only on OK.
    int option_size = 1;
    Slider music, sound, scroll;
    CheckBox taunts, one_click, two_button, no_selection_limit, production_queue, vsync, groups;
    CheckBox side_buttons;
    CheckBox simulated_mouse;
    int fps_index = 2;   // 60, 90, 120
    int hud_index = 1;   // 100%, 150%, 200%
    Slider top_bar, panel, text;   // the interface's sizes
    // The Save Game dialog: the games already saved, and the name typed.
    ListBox saves;
    TextField save_name;
    bool save_name_ready = false;
    std::string chosen_name;
};

Shared& S() {
    static Shared state;
    return state;
}

void Click() { HAL::Audio::Play(Audio::InterfaceSound::kButton2, 1.0f, 0.0f); }

// The in-game dialogs' art: the size of its parchment (the rest of the art
// is the shadow it casts, right and below) and the middle of its title
// plate. A dialog is placed in a box its parchment less 15 by 8, centred on
// the screen, the shadow falling past it.
struct DialogArt {
    uint32_t sin;
    SDL_Point parchment;
    SDL_Point plate;   // {0, 0}: none
};
constexpr DialogArt kDialogArt[] = {
    {Sin::kDiplomacy, {755, 474}, {386, 34}},
    {Sin::kGameMenu, {293, 299}, {0, 0}},
    {Sin::kObjectives, {462, 495}, {247, 28}},
    {Sin::kChat, {591, 521}, {271, 32}},
    {Sin::kGameDialog, {675, 444}, {346, 34}},
    {Sin::kChat2, {567, 602}, {273, 27}},
};
const DialogArt* ArtOf(uint32_t sin) {
    for (const auto& a : kDialogArt) {
        if (a.sin == sin) return &a;
    }
    return nullptr;
}
SDL_Point ParchmentOf(const Theme& theme, uint32_t sin) {
    const DialogArt* art = ArtOf(sin);
    return art != nullptr ? art->parchment : BackgroundSize(theme);
}
void Place(Theme& theme, uint32_t sin, int w, int h) {
    if (const DialogArt* art = ArtOf(sin)) {
        theme.origin = SDL_Point{(w - (art->parchment.x - 15)) / 2, (h - (art->parchment.y - 8)) / 2};
    }
}
// A dialog's title, in the screen-title face, centred on its plate.
void DrawTitle(SDL_Renderer* r, const Theme& theme, uint32_t sin, int title) {
    const DialogArt* art = ArtOf(sin);
    const SDL_Point plate = art != nullptr && art->plate.x > 0
        ? art->plate : SDL_Point{BackgroundSize(theme).x / 2, 34};
    DrawText(r, Text::kBlackletter21B, theme.origin.x + plate.x, theme.origin.y + plate.y - 11,
             Get(title), theme.text, theme.text_shadow, Align::Centre);
}

// The game menu's buttons, top to bottom, by their LANGUAGE.DLL names and
// what each does.
struct MenuButton {
    int label;
    Outcome outcome;
    Dialog opens;
    int confirm;   // a question to ask first, or -1
};
constexpr MenuButton kMenuButtons[] = {
    {9273, Outcome::QuitToMenu, Dialog::None, 9283},   // Quit Current Game
    {9271, Outcome::None, Dialog::Achievements, -1},   // Achievements
    {9272, Outcome::None, Dialog::SaveGame, -1},       // Save
    {9276, Outcome::Load, Dialog::None, 3100},         // Load
    {9279, Outcome::Restart, Dialog::None, 9279},      // Restart
    {9274, Outcome::None, Dialog::Options, -1},        // Options
    {9280, Outcome::Resign, Dialog::None, 9280},       // Resign
    {9275, Outcome::None, Dialog::None, -1},           // Cancel
    {0,    Outcome::None, Dialog::Cheats, -1},         // Cheats
};
constexpr int kMenuButtonW = 240;
constexpr int kMenuButtonH = 30;
constexpr int kMenuButtonPitch = 33;

SDL_Rect MenuButtonRect(const Theme& theme, int i, int w, int h) {
    (void)w; (void)h;
    const SDL_Point size = ParchmentOf(theme, Sin::kGameMenu);
    const int top = theme.origin.y + (size.y - static_cast<int>(std::size(kMenuButtons)) *
                                                  kMenuButtonPitch) / 2;
    return SDL_Rect{theme.origin.x + (size.x - kMenuButtonW) / 2, top + i * kMenuButtonPitch,
                    kMenuButtonW, kMenuButtonH};
}

Theme& MenuTheme(int w, int h) {
    static Theme theme;
    static int cached_w = 0, cached_h = 0;
    if (cached_w != w || cached_h != h) {
        (void)w; (void)h;
        theme = MakeTheme(Sin::kGameMenu, 800, 600, true);
        Place(theme, Sin::kGameMenu, 800, 600);
        cached_w = w;
        cached_h = h;
    }
    return theme;
}

Theme& GameDialogTheme(uint32_t sin, int w, int h) {
    struct Cached { uint32_t sin; int w, h; Theme theme; };
    static std::vector<Cached> cache;
    for (auto& c : cache) {
        if (c.sin == sin && c.w == w && c.h == h) return c.theme;
    }
    cache.push_back({sin, w, h, MakeTheme(sin, w, h, true)});
    Place(cache.back().theme, sin, w, h);
    return cache.back().theme;
}

// The yes-or-no box: over the game menu's parchment.
constexpr SDL_Rect kConfirmPanel{150, 180, 500, 240};

SDL_Rect ConfirmButton(const Theme& theme, bool yes) {
    (void)theme;
    return SDL_Rect{(yes ? kConfirmPanel.x + 125 : kConfirmPanel.x + 265),
                    kConfirmPanel.y + 186, 110, 32};
}

// The pause menu's official HD art: the main-menu plaque and background.
struct PauseArt { SDL_Texture* up = nullptr; SDL_Texture* hover = nullptr; SDL_Texture* parchment = nullptr; };
PauseArt& PauseArtOf(SDL_Renderer* r) {
    static PauseArt art;
    if (art.up == nullptr) {
        auto load = [&](const char* path) -> SDL_Texture* {
            int w = 0, h = 0, channels = 0;
            stbi_uc* pixels = stbi_load(path, &w, &h, &channels, 4);
            if (pixels == nullptr) return nullptr;
            SDL_Surface* surface = SDL_CreateRGBSurfaceFrom(pixels, w, h, 32, w * 4,
                                                            0x000000FF, 0x0000FF00, 0x00FF0000, 0xFF000000);
            SDL_Texture* texture = nullptr;
            if (surface != nullptr) { texture = SDL_CreateTextureFromSurface(r, surface); SDL_FreeSurface(surface); }
            stbi_image_free(pixels);
            return texture;
        };
        art.up = load("../assets/extracted_data/ui/pause_up.png");
        art.hover = load("../assets/extracted_data/ui/pause_hover.png");
        art.parchment = load("../assets/extracted_data/ui/pause_parchment.png");
    }
    return art;
}
void DrawPauseArt(SDL_Renderer* r, int w, int h, const SDL_Rect& panel) {
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
    const SDL_Rect dim{0, 0, w, h};
    SDL_SetRenderDrawColor(r, 0, 0, 0, 130);
    SDL_RenderFillRect(r, &dim);
    const PauseArt& art = PauseArtOf(r);
    if (art.parchment != nullptr) SDL_RenderCopy(r, art.parchment, nullptr, &panel);
}
void DrawMenu(SDL_Renderer* r, int w, int h) {
    const Theme& theme = MenuTheme(w, h);
    const SDL_Rect first = MenuButtonRect(theme, 0, w, h);
    const SDL_Rect last = MenuButtonRect(theme, static_cast<int>(std::size(kMenuButtons)) - 1, w, h);
    const SDL_Rect panel{first.x - 22, first.y - 18, first.w + 44,
                         last.y + last.h - first.y + 36};
    SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
    const SDL_Rect shadow{panel.x + 5, panel.y + 6, panel.w, panel.h};
    SDL_SetRenderDrawColor(r, 0, 0, 0, 150);
    SDL_RenderFillRect(r, &shadow);
    const PauseArt& art = PauseArtOf(r);
    if (art.parchment != nullptr) {
        SDL_RenderCopy(r, art.parchment, nullptr, &panel);
    } else {
        DrawShaded(r, theme, panel);
        DrawSunken2(r, theme, panel);
    }
    for (int i = 0; i < static_cast<int>(std::size(kMenuButtons)); ++i) {
        const SDL_Rect rect = MenuButtonRect(theme, i, w, h);
        Button b{rect, i == static_cast<int>(std::size(kMenuButtons)) - 1
                          ? "作弊菜单" : Get(kMenuButtons[i].label),
                 Text::kBlackletter14};
        DrawButton(r, theme, b, StateOf(b, S().mx, S().my, S().held));
    }
}
// The cheats menu: the codes of ecs/Cheats as buttons, on the same dark
// panel as the pause menu.
struct CheatEntry { const char* label; int code; };
constexpr CheatEntry kCheats[] = {
    {"食物 +10000", ECS::Cheats::kFood},     {"木材 +10000", ECS::Cheats::kWood},
    {"黄金 +10000", ECS::Cheats::kGold},     {"石头 +10000", ECS::Cheats::kStone},
    {"显示全图", ECS::Cheats::kMarco},      {"取消迷雾", ECS::Cheats::kPolo},
    {"快速建造", ECS::Cheats::kAegis},      {"快速生产", ECS::Cheats::kFastProduction},
    {"召唤跑车", ECS::Cheats::kCobra},  {"自然控制", ECS::Cheats::kNaturalWonders},
    {"立即胜利", ECS::Cheats::kWinner},     {"杀死敌人", ECS::Cheats::kBlackDeath},
};
constexpr int kCheatButtonW = 250, kCheatButtonH = 42, kCheatGap = 18;
constexpr int kCheatPanelW = 600, kCheatPanelH = 430;

SDL_Rect CheatButtonRect(int i, int w, int h) {
    const int cols = 2;
    const int left = (w - kCheatPanelW) / 2 + 35 + (i % cols) * (kCheatButtonW + kCheatGap);
    const int top = (h - kCheatPanelH) / 2 + 52 + (i / cols) * (kCheatButtonH + 10);
    return SDL_Rect{left, top, kCheatButtonW, kCheatButtonH};
}

void DrawCheats(SDL_Renderer* r, int w, int h) {
    const SDL_Rect panel{(w - kCheatPanelW) / 2, (h - kCheatPanelH) / 2, kCheatPanelW, kCheatPanelH};
    DrawPauseArt(r, w, h, panel);
    const PauseArt& art = PauseArtOf(r);
    const int px = panel.x, py = panel.y;
    DrawText(r, Text::kBlackletter14, px + kCheatPanelW / 2, py + 16, "作弊菜单",
             SDL_Color{236, 214, 166, 255}, SDL_Color{0, 0, 0, 230}, Align::Centre);
    for (int i = 0; i < static_cast<int>(std::size(kCheats)); ++i) {
        const SDL_Rect rect = CheatButtonRect(i, w, h);
        const bool hover = Hit(rect, S().mx, S().my);
        if (art.up != nullptr) {
            SDL_RenderCopy(r, hover && art.hover != nullptr ? art.hover : art.up, nullptr, &rect);
            SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
            SDL_SetRenderDrawColor(r, 67, 59, 34, 175);
            SDL_RenderFillRect(r, &rect);
        }
        DrawText(r, Text::kBlackletter14, rect.x + rect.w / 2,
                 rect.y + (rect.h - Text::Height(Text::kBlackletter14)) / 2, kCheats[i].label,
                 SDL_Color{226, 205, 160, 255}, SDL_Color{0, 0, 0, 220}, Align::Centre);
    }
    const SDL_Rect back{px + kCheatPanelW - 114, py + kCheatPanelH - 46, 92, 30};
    SDL_SetRenderDrawColor(r, 38, 32, 22, 220);
    SDL_RenderFillRect(r, &back);
    SDL_SetRenderDrawColor(r, 180, 145, 80, 200);
    SDL_RenderDrawRect(r, &back);
    DrawText(r, Text::kBlackletter14, back.x + back.w / 2,
             back.y + (back.h - Text::Height(Text::kBlackletter14)) / 2, "返回",
             SDL_Color{226, 205, 160, 255}, SDL_Color{0, 0, 0, 220}, Align::Centre);
}

void DrawConfirm(SDL_Renderer* r, int w, int h) {
    const Theme& theme = MenuTheme(w, h);
    (void)w; (void)h;
    // The dialog page's own shade is already drawn by Draw(); adding another
    // here doubled the darkness in the 4:3 area.
    const PauseArt& art = PauseArtOf(r);
    if (art.parchment != nullptr) {
        SDL_RenderCopy(r, art.parchment, nullptr, &kConfirmPanel);
    } else {
        DrawShaded(r, theme, kConfirmPanel);
        DrawSunken2(r, theme, kConfirmPanel);
    }
    std::string question = Get(S().question);
    if (S().question == 9283) question = Get(9283) + "?";
    DrawWrapped(r, Text::kGeorgia10B, kConfirmPanel.x + 28, kConfirmPanel.y + 44,
                kConfirmPanel.w - 56, question, SDL_Color{0, 0, 0, 255},
                SDL_Color{0, 0, 0, 255}, false);
    for (bool yes : {true, false}) {
        Button b{ConfirmButton(theme, yes), Get(yes ? 4003 : 4004), Text::kBlackletter14};
        DrawButton(r, theme, b, StateOf(b, S().mx, S().my, S().held));
    }
}

// A dialog with no contents of its own: its art, its title and a Cancel
// button.
void DrawPlaceholder(SDL_Renderer* r, uint32_t sin, int title, int w, int h) {
    const Theme& theme = GameDialogTheme(sin, w, h);
    DrawBackground(r, theme);
    const SDL_Point size = ParchmentOf(theme, sin);
    DrawTitle(r, theme, sin, title);
    Button close{SDL_Rect{theme.origin.x + (size.x - 120) / 2, theme.origin.y + size.y - 60, 120, 30},
                 Get(9275), Text::kBlackletter14};
    DrawButton(r, theme, close, StateOf(close, S().mx, S().my, S().held));
}

SDL_Rect PlaceholderClose(uint32_t sin, int w, int h) {
    const Theme& theme = GameDialogTheme(sin, w, h);
    const SDL_Point size = ParchmentOf(theme, sin);
    return SDL_Rect{theme.origin.x + (size.x - 120) / 2, theme.origin.y + size.y - 60, 120, 30};
}

// The Save Game dialog, on the in-game dialog art: the saved games in a list
// -- clicking one takes its name -- the name in a field under it, and Save
// and Cancel.
struct SaveLayout {
    SDL_Rect list, field, save, cancel;
};
constexpr int kGameDialogParchmentW = 675;
constexpr int kGameDialogParchmentH = 444;

SDL_Rect SavePanel(int w, int h) {
    constexpr int pw = 620, ph = 400;
    return SDL_Rect{(w - pw) / 2, (h - ph) / 2, pw, ph};
}

SaveLayout SaveRects(int w, int h) {
    const SDL_Rect p = SavePanel(w, h);
    const int x = p.x + 25;
    const int bw = p.w - 50;
    const int centre = p.x + p.w / 2;
    return SaveLayout{SDL_Rect{x, p.y + 60, bw, 250},
                      SDL_Rect{x, p.y + 322, bw, 26},
                      SDL_Rect{centre - 150, p.y + 360, 140, 30},
                      SDL_Rect{centre + 10, p.y + 360, 140, 30}};
}

// ---- Options ---------------------------------------------------------------
//
// The game's options from inside a game, on the same art: the screen size,
// the music, sound and scrolling, and the mouse and garrison choices -- the
// main menu's Options less the name, with the same LANGUAGE.DLL labels.
struct OptionsLayout {
    SDL_Rect sizes[3];
    SDL_Rect ok, cancel;
    int label_right;
};

SDL_Rect OptionsPanel(int w, int h) {
    constexpr int pw = 620, ph = 470;
    return SDL_Rect{(w - pw) / 2, (h - ph) / 2, pw, ph};
}

OptionsLayout OptionsRects(int w, int h) {
    const SDL_Rect p = OptionsPanel(w, h);
    const int ox = p.x, oy = p.y;
    OptionsLayout l{};
    for (int i = 0; i < 3; ++i) l.sizes[i] = SDL_Rect{ox + 165 + i * 150, oy + 44, 140, 26};
    l.ok = SDL_Rect{ox + p.w / 2 - 150, oy + p.h - 38, 140, 30};
    l.cancel = SDL_Rect{ox + p.w / 2 + 10, oy + p.h - 38, 140, 30};
    l.label_right = ox + 155;
    return l;
}

void OpenOptions(int w, int h) {
    Shared& s = S();
    const SDL_Rect p = OptionsPanel(w, h);
    const int ox = p.x, oy = p.y;
    const auto& profile = Core::Profile::Current();
    s.option_size = profile.widescreen ? (profile.widescreen_overlay ? 2 : 1) : 0;
    s.music = Slider{SDL_Rect{ox + 170, oy + 95, 240, 20}, profile.music_volume, 10};
    s.sound = Slider{SDL_Rect{ox + 170, oy + 150, 240, 20}, profile.sound_volume, 10};
    s.scroll = Slider{SDL_Rect{ox + 170, oy + 205, 240, 20}, profile.scroll_speed, 10};
    s.taunts = CheckBox{SDL_Rect{ox + 170, oy + 250, 28, 24}, profile.audio_taunts};
    s.one_click = CheckBox{SDL_Rect{ox + 170, oy + 276, 28, 24}, profile.one_click_garrison};
    s.two_button = CheckBox{SDL_Rect{ox + 170, oy + 302, 28, 24}, profile.two_button_mouse};
    s.no_selection_limit = CheckBox{SDL_Rect{ox + 170, oy + 328, 28, 24}, profile.no_selection_limit};
    s.production_queue = CheckBox{SDL_Rect{ox + 410, oy + 250, 28, 24}, profile.production_queue};
    s.groups = CheckBox{SDL_Rect{ox + 410, oy + 300, 28, 24}, profile.show_groups};
    s.side_buttons = CheckBox{SDL_Rect{ox + 40, oy + 372, 24, 22}, profile.show_side_buttons};
    s.simulated_mouse = CheckBox{SDL_Rect{ox + 220, oy + 372, 24, 22}, profile.simulated_mouse};
    s.vsync = CheckBox{SDL_Rect{ox + 40, oy + 350, 24, 22}, profile.vsync};
    s.fps_index = profile.fps_limit >= 120 ? 2 : profile.fps_limit >= 90 ? 1 : 0;
    s.hud_index = profile.panel_size >= 120 ? 2 : profile.panel_size >= 105 ? 1 : 0;
}

void DrawOptionsDialog(SDL_Renderer* r, int w, int h) {
    const Theme& theme = GameDialogTheme(Sin::kGameDialog, w, h);
    const SDL_Rect panel = OptionsPanel(w, h);
    if (const PauseArt& art = PauseArtOf(r); art.parchment != nullptr) {
        SDL_RenderCopy(r, art.parchment, nullptr, &panel);
    } else {
        SDL_SetRenderDrawColor(r, 205, 180, 140, 255);
        SDL_RenderFillRect(r, &panel);
        DrawBevel(r, theme, panel, false);
    }
    DrawText(r, Text::kBlackletter14, panel.x + panel.w / 2, panel.y + 12, Get(9274),
             SDL_Color{60, 35, 10, 255}, SDL_Color{240, 220, 170, 255}, Align::Centre);
    Shared& s = S();
    const OptionsLayout l = OptionsRects(w, h);
    const int ox = panel.x, oy = panel.y;
    const SDL_Color ink = {0, 0, 0, 255};
    DrawText(r, Text::kGeorgia10B, l.label_right, l.sizes[0].y + 6, "宽屏", ink, ink,
             Align::Right, false);
    static const char* kWidthNames[3] = {"关", "开", "镜头区域上方叠加"};
    for (int i = 0; i < 3; ++i) {
        Button b{l.sizes[i], kWidthNames[i], Text::kGeorgia10B};
        State state = StateOf(b, s.mx, s.my, s.held);
        if (i == s.option_size && state == State::Normal) state = State::Selected;
        DrawButton(r, theme, b, state);
    }
    struct Labelled { int label; const Slider* slider; int low; int high; };
    const Labelled sliders[] = {
        {9515, &s.music, 9517, 9516}, {9514, &s.sound, 9517, 9516}, {9518, &s.scroll, 9520, 9519},
    };
    for (const auto& lab : sliders) {
        std::string label = Get(lab.label);
        std::replace(label.begin(), label.end(), '\n', ' ');
        DrawText(r, Text::kGeorgia10B, l.label_right, lab.slider->track.y + 2, label, ink, ink,
                 Align::Right, false);
        DrawSlider(r, theme, *lab.slider);
        DrawText(r, Text::kArial8, lab.slider->track.x, lab.slider->track.y + 24, Get(lab.low), ink,
                 ink, Align::Left, false);
        DrawText(r, Text::kArial8, lab.slider->track.x + lab.slider->track.w,
                 lab.slider->track.y + 24, Get(lab.high), ink, ink, Align::Right, false);
    }
    struct Box { int label; const CheckBox* c; };
    const Box boxes[] = {{9526, &s.taunts}, {9527, &s.one_click}, {9528, &s.two_button}};
    for (const auto& b : boxes) {
        DrawCheckBox(r, theme, *b.c, s.mx, s.my, s.held);
        DrawText(r, Text::kGeorgia10B, b.c->box.x + b.c->box.w + 10, b.c->box.y + 5, Get(b.label),
                 ink, ink, Align::Left, false);
    }
    // No selection limit (Profile::Options::no_selection_limit); its label
    // is in no string table.
    DrawCheckBox(r, theme, s.no_selection_limit, s.mx, s.my, s.held);
    DrawText(r, Text::kGeorgia10B, s.no_selection_limit.box.x + s.no_selection_limit.box.w + 10,
             s.no_selection_limit.box.y + 5, "Disable selection limit", ink, ink, Align::Left, false);
    DrawCheckBox(r, theme, s.vsync, s.mx, s.my, s.held);
    DrawText(r, Text::kGeorgia10B, s.vsync.box.x + s.vsync.box.w + 8, s.vsync.box.y + 3,
             "垂直同步", ink, ink, Align::Left, false);
    static const char* kHudNames[3] = {"小", "中", "大"};
    DrawText(r, Text::kGeorgia10B, ox + 210, oy + 354, "HUD大小", ink, ink, Align::Left, false);
    for (int i = 0; i < 3; ++i) {
        Button b{SDL_Rect{ox + 300 + i * 58, oy + 350, 52, 24}, kHudNames[i], Text::kGeorgia10B};
        State state = StateOf(b, s.mx, s.my, s.held);
        if (i == s.hud_index && state == State::Normal) state = State::Selected;
        DrawButton(r, theme, b, state);
    }
    static const int kFps[3] = {60, 90, 120};
    DrawText(r, Text::kGeorgia10B, ox + 300, oy + 394, "帧数", ink, ink, Align::Left, false);
    for (int i = 0; i < 3; ++i) {
        Button b{SDL_Rect{ox + 345 + i * 62, oy + 390, 56, 24},
                 std::to_string(kFps[i]), Text::kArial8};
        State state = StateOf(b, s.mx, s.my, s.held);
        if (i == s.fps_index && state == State::Normal) state = State::Selected;
        DrawButton(r, theme, b, state);
    }
    // The overview of what is being made (Profile::Options::production_queue),
    // likewise.
    DrawCheckBox(r, theme, s.production_queue, s.mx, s.my, s.held);
    DrawText(r, Text::kGeorgia10B, s.production_queue.box.x + s.production_queue.box.w + 10,
             s.production_queue.box.y + 5, "Production Queue", ink, ink, Align::Left, false);
    DrawCheckBox(r, theme, s.groups, s.mx, s.my, s.held);
    DrawText(r, Text::kGeorgia10B, s.groups.box.x + s.groups.box.w + 10,
             s.groups.box.y + 5, "编队区", ink, ink, Align::Left, false);
    DrawCheckBox(r, theme, s.side_buttons, s.mx, s.my, s.held);
    DrawText(r, Text::kGeorgia10B, s.side_buttons.box.x + s.side_buttons.box.w + 10,
             s.side_buttons.box.y + 5, "左侧按钮", ink, ink, Align::Left, false);
    DrawCheckBox(r, theme, s.simulated_mouse, s.mx, s.my, s.held);
    DrawText(r, Text::kGeorgia10B, s.simulated_mouse.box.x + s.simulated_mouse.box.w + 10,
             s.simulated_mouse.box.y + 5, "模拟鼠标", ink, ink, Align::Left, false);
    Button ok{l.ok, Get(4001), Text::kBlackletter14};
    State state = StateOf(ok, s.mx, s.my, s.held);
    if (state == State::Normal) state = State::Hover;
    DrawButton(r, theme, ok, state);
    Button cancel{l.cancel, Get(4002), Text::kBlackletter14};
    DrawButton(r, theme, cancel, StateOf(cancel, s.mx, s.my, s.held));
}

// An event in the Options dialog; true when it closed it.
bool OptionsEventIn(const SDL_Event& e, int w, int h) {
    Shared& s = S();
    const Theme& theme = GameDialogTheme(Sin::kGameDialog, w, h);
    const OptionsLayout l = OptionsRects(w, h);
    const SDL_Rect panel = OptionsPanel(w, h);
    const int ox = panel.x, oy = panel.y;
    if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_LEFT) {
        for (Slider* slider : {&s.music, &s.sound, &s.scroll}) {
            if (DragSlider(*slider, e.button.x, e.button.y)) return false;
        }
        for (CheckBox* c : {&s.taunts, &s.one_click, &s.two_button, &s.no_selection_limit, &s.production_queue, &s.vsync, &s.groups, &s.side_buttons, &s.simulated_mouse}) {
            if (Hit(c->box, e.button.x, e.button.y)) {
                c->checked = !c->checked;
                Click();
                if (c == &s.simulated_mouse) HAL::Touch::SetSimulatedMouse(c->checked);
                if (c == &s.vsync) {
                    if (HAL::Window* window = HAL::MainWindow()) {
                        SDL_RenderSetVSync(window->GetSDLRenderer(), c->checked ? 1 : 0);
                    }
                }
                return false;
            }
        }
    } else if (e.type == SDL_MOUSEMOTION && s.held) {
        for (Slider* slider : {&s.music, &s.sound, &s.scroll}) {
            DragSlider(*slider, e.motion.x, e.motion.y);
        }
    } else if (e.type == SDL_MOUSEBUTTONUP && e.button.button == SDL_BUTTON_LEFT) {
        for (int i = 0; i < 3; ++i) {
            if (Hit(l.sizes[i], e.button.x, e.button.y)) {
                s.option_size = i;
                Click();
            }
            const SDL_Rect fps{ox + 345 + i * 62, oy + 390, 56, 24};
            if (Hit(fps, e.button.x, e.button.y)) {
                s.fps_index = i;
                Click();
            }
            const SDL_Rect hud{ox + 300 + i * 58, oy + 350, 52, 24};
            if (Hit(hud, e.button.x, e.button.y)) {
                s.hud_index = i;
                Click();
            }
        }
        if (Hit(l.ok, e.button.x, e.button.y)) {
            Click();
            auto& profile = Core::Profile::Current();
            const bool resized = profile.widescreen != (s.option_size > 0) ||
                                 profile.widescreen_overlay != (s.option_size == 2);
            profile.widescreen = s.option_size > 0;
            profile.widescreen_overlay = s.option_size == 2;
            profile.screen_width = 1024;
            profile.screen_height = 768;
            profile.music_volume = s.music.value;
            profile.sound_volume = s.sound.value;
            profile.scroll_speed = s.scroll.value;
            profile.audio_taunts = s.taunts.checked;
            profile.one_click_garrison = s.one_click.checked;
            profile.two_button_mouse = s.two_button.checked;
            profile.no_selection_limit = s.no_selection_limit.checked;
            profile.production_queue = s.production_queue.checked;
            profile.show_groups = s.groups.checked;
            profile.show_side_buttons = s.side_buttons.checked;
            profile.simulated_mouse = s.simulated_mouse.checked;
            profile.vsync = s.vsync.checked;
            static const int kFps[3] = {60, 90, 120};
            profile.fps_limit = kFps[s.fps_index];
            static const int kHud[3] = {100, 110, 120};
            profile.top_bar_size = kHud[s.hud_index];
            profile.panel_size = kHud[s.hud_index];
            profile.text_size = kHud[s.hud_index];
            // The three HUD presets are the final word.
            profile.top_bar_size = kHud[s.hud_index];
            profile.panel_size = kHud[s.hud_index];
            profile.text_size = kHud[s.hud_index];
            Core::Profile::Save(profile);
            HAL::Audio::SetVolume(static_cast<float>(profile.sound_volume) / 10.0f);
            Audio::Music::SetVolume(profile.music_volume);
            // Only an actual resolution change resizes the game frame. HUD
            // scale is a layout property and must not touch the game view.
            if (resized) {
                if (HAL::Window* window = HAL::MainWindow()) {
                    window->SetGameSize(profile.widescreen ? window->WideWidth(profile.screen_height)
                                                           : profile.screen_width,
                                        profile.screen_height);
                }
            }
            return true;
        }
        if (Hit(l.cancel, e.button.x, e.button.y)) {
            Click();
            return true;
        }
    }
    return false;
}

void OpenSave() {
    Shared& s = S();
    s.saves = ListBox{};
    s.saves.font = Text::kGeorgia10B;
    for (const auto& path : Screens::FilesIn(Screens::SavedGamesDir(), {".gam"})) {
        s.saves.items.push_back(std::filesystem::path(path).stem().string());
    }
    s.save_name.font = Text::kGeorgia10B;
    s.save_name.max_length = 40;
    s.save_name.focused = true;
    s.save_name.text.clear();
    s.save_name_ready = false;
}

void DrawSave(SDL_Renderer* r, int w, int h, ECS::Simulation& sim) {
    Shared& s = S();
    if (!s.save_name_ready) {
        s.save_name_ready = true;
        if (s.save_name.text.empty()) {
            auto& registry = sim.GetRegistry();
            const auto* me = ECS::Players::Find(registry, Core::LocalPlayer());
            if (me != nullptr) {
                std::string base = Core::ConfigManager::Get().GetCivName(me->civ);
                if (!base.empty()) {
                    int n = 1;
                    for (const auto& item : s.saves.items) {
                        const std::string prefix = base + "_";
                        if (item.rfind(prefix, 0) == 0) {
                            try { n = std::max(n, std::stoi(item.substr(prefix.size())) + 1); }
                            catch (...) {}
                        }
                    }
                    s.save_name.text = base + "_" + std::to_string(n);
                }
            }
        }
    }
    const Theme& theme = GameDialogTheme(Sin::kGameDialog, w, h);
    const SDL_Rect panel = SavePanel(w, h);
    if (const PauseArt& art = PauseArtOf(r); art.parchment != nullptr) {
        SDL_RenderCopy(r, art.parchment, nullptr, &panel);
    } else {
        SDL_SetRenderDrawColor(r, 205, 180, 140, 255);
        SDL_RenderFillRect(r, &panel);
        DrawBevel(r, theme, panel, false);
    }
    DrawText(r, Text::kBlackletter14, panel.x + panel.w / 2, panel.y + 16, Get(9411),
             SDL_Color{60, 35, 10, 255}, SDL_Color{240, 220, 170, 255}, Align::Centre);
    const SaveLayout l = SaveRects(w, h);
    s.saves.rect = l.list;
    s.save_name.rect = l.field;
    DrawListBox(r, theme, s.saves, s.mx, s.my);
    DrawTextField(r, theme, s.save_name);
    Button save{l.save, Get(9272), Text::kBlackletter14};
    save.enabled = !s.save_name.text.empty();
    DrawButton(r, theme, save, StateOf(save, s.mx, s.my, s.held));
    Button cancel{l.cancel, Get(9275), Text::kBlackletter14};
    DrawButton(r, theme, cancel, StateOf(cancel, s.mx, s.my, s.held));
}

// One frame of an interface sheet at its own size, its player colour drawn
// over it.
void DrawArt(SDL_Renderer* r, uint32_t slp, int frame, int x, int y, int player = 1) {
    auto& graphics = HAL::GraphicCache::Get();
    const HAL::GraphicAtlas* atlas = graphics.GetInterfaceAtlas(slp);
    if (atlas == nullptr || atlas->base == nullptr || frame < 0 ||
        frame >= static_cast<int>(atlas->frames.size())) {
        return;
    }
    const HAL::GraphicFrame& f = atlas->frames[static_cast<size_t>(frame)];
    const SDL_Rect dst = {x - f.hotspot_x, y - f.hotspot_y, f.rect.w, f.rect.h};
    SDL_RenderCopy(r, atlas->base, &f.rect, &dst);
    if (SDL_Texture* tint = graphics.GetInterfacePlayerLayer(slp, player)) {
        SDL_RenderCopy(r, tint, &f.rect, &dst);
    }
}

// ---- Diplomacy ----------------------------------------------------------
//
// Placed as every in-game dialog is (Place). A row per player, the viewer's
// first: the name on its banner (interfac.drs 50746, in the player's
// colour), the civilisation, how they regard the viewer; then the viewer's
// stance in three round buttons of the dialog's button art and a tribute
// button per stockpile (50732), the viewer's own row carrying the stockpiles
// over them.
constexpr uint32_t kBanner = 50746;
constexpr uint32_t kTributeIcons = 50732;     // wood, stone, food, gold
constexpr int kDipRowTop = 138;               // the viewer's row, art-relative
constexpr int kDipRowPitch = 30;
constexpr int kDipNameX = 35, kDipCivX = 186, kDipTheirX = 265;
constexpr int kDipStanceX[3] = {335, 413, 481};       // ally, neutral, enemy
constexpr int kDipStanceHeadX[3] = {359, 422, 506};
constexpr int kDipTributeX[4] = {535, 584, 632, 682}; // wood, food, gold, stone
constexpr int kDipTributeFrame[4] = {0, 2, 3, 1};
constexpr uint8_t kDipTributeResource[4] = {1, 0, 3, 2};  // dat resources
constexpr ECS::Diplomacy::Stance kDipStances[3] = {
    ECS::Diplomacy::Stance::Ally, ECS::Diplomacy::Stance::Neutral, ECS::Diplomacy::Stance::Enemy};

Theme DiplomacyTheme(int w, int h) {
    return GameDialogTheme(Sin::kDiplomacy, w, h);
}

// The players in the rows, the viewer first.
std::vector<Core::PlayerId> DiplomacyRows(const entt::registry& registry) {
    std::vector<Core::PlayerId> rows;
    const Core::PlayerId me = Core::LocalPlayer();
    if (ECS::Players::Find(registry, me) != nullptr) rows.push_back(me);
    for (int p = 1; p < Core::kMaxPlayers; ++p) {
        const auto* player = ECS::Players::Find(registry, static_cast<Core::PlayerId>(p));
        if (player != nullptr && player->active && p != me) rows.push_back(static_cast<Core::PlayerId>(p));
    }
    return rows;
}

int StanceIndex(ECS::Diplomacy::Stance stance) {
    return stance == ECS::Diplomacy::Stance::Ally ? 0 : stance == ECS::Diplomacy::Stance::Neutral ? 1 : 2;
}

void OpenDiplomacy(const entt::registry& registry) {
    Rendering::UIRenderer::SetHelpEnabled(false);
    Rendering::UIRenderer::SetHudHidden(true);
    Shared& s = S();
    const Core::PlayerId me = Core::LocalPlayer();
    for (int p = 0; p < Core::kMaxPlayers; ++p) {
        s.stance[p] = static_cast<uint8_t>(StanceIndex(
            ECS::Diplomacy::StanceOf(registry, me, static_cast<Core::PlayerId>(p))));
        for (int& t : s.tribute[p]) t = 0;
    }
    s.allied_victory = ECS::Diplomacy::AlliedVictory(registry, me);
}

SDL_Rect DipButton(const Theme&, int x, int row) {
    const SDL_Rect p = SavePanel(800, 600);
    return SDL_Rect{p.x + x, p.y + 70 + row * 34, 26, 26};
}
SDL_Rect DipTribute(const Theme&, int column, int row) {
    const SDL_Rect p = SavePanel(800, 600);
    return SDL_Rect{p.x + 470 + column * 34, p.y + 70 + row * 34, 28, 26};
}
SDL_Rect DipBottom(const Theme&, int which) {
    const SDL_Rect p = SavePanel(800, 600);
    static const int kX[3] = {30, 190, 360};
    static const int kW[3] = {130, 150, 130};
    return SDL_Rect{p.x + kX[which], p.y + 350, kW[which], 30};
}
SDL_Rect DipAlliedVictory(const Theme&) {
    const SDL_Rect p = SavePanel(800, 600);
    return SDL_Rect{p.x + 250, p.y + 310, 26, 26};
}

void DrawDiplomacy(SDL_Renderer* r, ECS::Simulation& sim, int w, int h) {
    const SDL_Rect p = SavePanel(w, h);
    const Theme& theme = DiplomacyTheme(w, h);
    SDL_SetRenderDrawColor(r, 205, 180, 140, 255);
    SDL_RenderFillRect(r, &p);
    DrawBevel(r, theme, p, false);
    const auto& registry = sim.GetRegistry();
    Shared& s = S();
    const Core::PlayerId me = Core::LocalPlayer();
    const ECS::Players::Player* mine = ECS::Players::Find(registry, me);
    const bool locked = ECS::Diplomacy::Locked(registry);
    const auto rows = DiplomacyRows(registry);
    const SDL_Color ink{0, 0, 0, 255};
    DrawText(r, Text::kBlackletter21B, p.x + p.w / 2, p.y + 8, Get(9851), ink, ink,
             Align::Centre, false);
    const int hy = p.y + 48;
    DrawText(r, Text::kGeorgia9B, p.x + 22, hy, Get(9862), ink, ink, Align::Left, false);
    DrawText(r, Text::kGeorgia9B, p.x + 170, hy, Get(9852), ink, ink, Align::Centre, false);
    DrawText(r, Text::kGeorgia9B, p.x + 300, hy, Get(9865), ink, ink, Align::Centre, false);
    DrawText(r, Text::kGeorgia9B, p.x + 370, hy, Get(9864), ink, ink, Align::Centre, false);
    for (int i = 0; i < 3; ++i) {
        DrawText(r, Text::kGeorgia9B, p.x + 360 + i * 35, hy + 18, Get(9853 + i), ink, ink,
                 Align::Centre, false);
    }
    for (int row = 0; row < static_cast<int>(rows.size()); ++row) {
        const Core::PlayerId who = rows[static_cast<size_t>(row)];
        const ECS::Players::Player* player = ECS::Players::Find(registry, who);
        const int y = p.y + 82 + row * 34;
        const HAL::PaletteColor pc = HAL::GraphicCache::Get().GetPlayerColor(who);
        const SDL_Color pcol{pc.r, pc.g, pc.b, 255};
        SDL_Rect swatch{p.x + 18, y + 3, 8, 8};
        SDL_SetRenderDrawColor(r, pc.r, pc.g, pc.b, 255);
        SDL_RenderFillRect(r, &swatch);
        DrawText(r, Text::kGeorgia9B, p.x + 30, y,
                 Rendering::UIRenderer::PlayerName(registry, who), pcol, ink, Align::Left, false);
        if (player != nullptr) {
            DrawText(r, Text::kGeorgia9B, p.x + 170, y, Get(Core::CivNameId(player->civ)), ink,
                     ink, Align::Centre, false);
        }
        if (who == me) {
            static const Core::ResourceType kKinds[4] = {
                Core::ResourceType::Wood, Core::ResourceType::Food,
                Core::ResourceType::Gold, Core::ResourceType::Stone};
            for (int c = 0; c < 4 && mine != nullptr; ++c) {
                DrawText(r, Text::kGeorgia9B, p.x + 484 + c * 34, y,
                         std::to_string(ECS::Players::Stock(*mine, kKinds[c])), ink, ink,
                         Align::Centre, false);
            }
            continue;
        }
        const ECS::Diplomacy::Stance theirs = ECS::Diplomacy::StanceOf(registry, who, me);
        DrawText(r, Text::kGeorgia9B, p.x + 300, y, Get(9853 + StanceIndex(theirs)), ink, ink,
                 Align::Centre, false);
        for (int i = 0; i < 3; ++i) {
            const SDL_Rect b = DipButton(theme, 360 + i * 35, row);
            const bool chosen = s.stance[who] == i;
            SDL_SetRenderDrawColor(r, chosen ? 150 : 120, chosen ? 105 : 90, 60, 255);
            SDL_RenderFillRect(r, &b);
            DrawBevel(r, theme, b, !locked && s.held && Hit(b, s.mx, s.my));
        }
        for (int c = 0; c < 4; ++c) {
            const SDL_Rect b = DipTribute(theme, c, row);
            SDL_SetRenderDrawColor(r, 190, 165, 125, 255);
            SDL_RenderFillRect(r, &b);
            DrawBevel(r, theme, b, false);
            DrawArt(r, kTributeIcons, kDipTributeFrame[c], b.x, b.y);
            if (s.tribute[who][c] > 0) {
                DrawTextIn(r, Text::kGeorgia9B, b, std::to_string(s.tribute[who][c]), ink, ink);
            }
        }
    }
    const SDL_Rect av = DipAlliedVictory(theme);
    SDL_SetRenderDrawColor(r, s.allied_victory ? 150 : 120, s.allied_victory ? 105 : 90, 60, 255);
    SDL_RenderFillRect(r, &av);
    DrawBevel(r, theme, av, false);
    DrawText(r, Text::kGeorgia9B, av.x + av.w + 8, av.y + 4, Get(9857), ink, ink,
             Align::Left, false);
    const SDL_Rect help{p.x + p.w - 34, p.y + 312, 24, 24};
    SDL_SetRenderDrawColor(r, 205, 180, 140, 255);
    SDL_RenderFillRect(r, &help);
    DrawBevel(r, theme, help, false);
    DrawTextIn(r, Text::kBlackletter14, help, "?", ink, ink, false);
    static const int kLabels[3] = {9858, 9859, 9275};
    for (int i = 0; i < 3; ++i) {
        const SDL_Rect b = DipBottom(theme, i);
        SDL_SetRenderDrawColor(r, 205, 180, 140, 255);
        SDL_RenderFillRect(r, &b);
        DrawBevel(r, theme, b, false);
        DrawTextIn(r, Text::kBlackletter14, b, Get(kLabels[i]), ink, ink, false);
    }
}

// A click in the Diplomacy dialog; true when it closed the dialog.
bool DiplomacyClick(ECS::Simulation& sim, int x, int y, int w, int h) {
    const Theme theme = DiplomacyTheme(w, h);
    auto& registry = sim.GetRegistry();
    Shared& s = S();
    const Core::PlayerId me = Core::LocalPlayer();
    const bool locked = ECS::Diplomacy::Locked(registry);
    const auto rows = DiplomacyRows(registry);
    for (int row = 0; row < static_cast<int>(rows.size()); ++row) {
        const Core::PlayerId p = rows[static_cast<size_t>(row)];
        if (p == me) continue;
        for (int i = 0; i < 3 && !locked; ++i) {
            if (Hit(DipButton(theme, kDipStanceX[i], row), x, y)) {
                Click();
                s.stance[p] = static_cast<uint8_t>(i);
                return false;
            }
        }
        for (int c = 0; c < 4; ++c) {
            if (!Hit(DipTribute(theme, c, row), x, y)) continue;
            const int amount = s.tribute[p][c] + 100;
            const auto refusal = ECS::Tribute::Check(registry, me, p, kDipTributeResource[c], amount);
            if (refusal == ECS::Tribute::Refusal::None) {
                Click();
                s.tribute[p][c] = amount;
            } else if (refusal == ECS::Tribute::Refusal::NoMarket) {
                Rendering::Messages::Post(Get(9863));
            } else if (refusal == ECS::Tribute::Refusal::CannotPay) {
                // "Not enough food." and its fellows, by dat resource.
                Rendering::Messages::Post(Get(3001 + kDipTributeResource[c]));
            }
            return false;
        }
    }
    if (!locked && Hit(DipAlliedVictory(theme), x, y)) {
        Click();
        s.allied_victory = !s.allied_victory;
        return false;
    }
    if (Hit(DipBottom(theme, 1), x, y)) {   // Clear Tributes
        Click();
        for (auto& row : s.tribute) {
            for (int& t : row) t = 0;
        }
        return false;
    }
    if (Hit(DipBottom(theme, 0), x, y)) {   // OK: everything chosen, as orders
        Click();
        auto& queue = Core::CommandQueue::Get();
        for (Core::PlayerId p : rows) {
            if (p == me) continue;
            const uint8_t chosen = static_cast<uint8_t>(kDipStances[s.stance[p]]);
            if (!locked && kDipStances[s.stance[p]] != ECS::Diplomacy::StanceOf(registry, me, p)) {
                queue.PushCommand(Core::DiplomacyCommand{p, chosen, me});
            }
            for (int c = 0; c < 4; ++c) {
                if (s.tribute[p][c] > 0) {
                    queue.PushCommand(Core::TributeCommand{p, kDipTributeResource[c], s.tribute[p][c], me});
                }
            }
        }
        if (!locked && s.allied_victory != ECS::Diplomacy::AlliedVictory(registry, me)) {
            queue.PushCommand(Core::AlliedVictoryCommand{s.allied_victory, me});
        }
        return true;
    }
    if (Hit(DipBottom(theme, 2), x, y)) {   // Cancel
        Click();
        return true;
    }
    return false;
}

// ---- Objectives ----------------------------------------------------------
//
// The Objectives dialog: a 485x523 panel on dlg_obj.sin's art, its title
// (10910, font 1) across the top, the text in a 385x359 box at (40, 66) in
// font 22 (black, wrapped, with a scroll bar), the Objectives and Hints tabs
// below it on objtabs.slp (interfac.drs 53005, frames 0 and 2) and OK.
//
// The objectives page lists the scenario's objective triggers in their
// order: those on, and those done (struck out, in font 28), each followed by
// an empty line. With none it shows an empty line and the scenario's
// instructions. The hints page is an empty line, string 10911 (which the DLL
// lacks) and the hints; without hints the tabs are not there. A random map's
// page is the victory condition's text for the kind of game.
std::string VictoryText(const entt::registry& registry) {
    const auto* setup = registry.ctx().find<Core::GameSetup>();
    if (setup == nullptr) return Get(9820);
    // The game types' own official descriptions.
    if (setup->supreme_king) {
        return "你的国王必须存活到最后。如果你的国王死亡，你将被淘汰出局。";
    }
    if (setup->king_of_the_hill) return Get(30174);
    if (setup->relic_victory) return Get(30178);
    if (setup->treaty) return Get(170035) + " " + Get(30190);
    if (setup->sudden_death) return "突然死亡: 每位玩家只有一个城镇中心，失去即被淘汰。";
    if (setup->wonder_race) return Get(30175);
    if (setup->defend_wonder) return Get(30176);
    if (setup->death_match) return Get(30172);
    if (setup->regicide) return Get(30171);
    switch (setup->victory) {
    case Core::VictoryKind::Conquest:  return Get(9823);
    case Core::VictoryKind::TimeLimit: return Get(9821);
    case Core::VictoryKind::Score:     return Get(9822);
    default:                           return Get(30190);
    }
}

constexpr SDL_Rect kObjTitle = {30, 8, 420, 36};
constexpr SDL_Rect kObjText = {30, 44, 430, 286};
constexpr SDL_Rect kObjTabs[2] = {{22, 334, 110, 30}, {138, 334, 110, 30}};
constexpr int kObjTabFrame[2] = {0, 2};
constexpr int kObjTabLabel[2] = {10910, 10912};
constexpr SDL_Rect kObjOk = {250, 344, 120, 28};
constexpr uint32_t kObjTabArt = 53005;   // objtabs.slp
constexpr int kObjScrollW = 20;

Theme ObjectivesTheme(int w, int h) {
    Theme theme = GameDialogTheme(Sin::kObjectives, w, h);
    const SDL_Rect panel = SavePanel(w, h);
    theme.origin = SDL_Point{panel.x, panel.y};
    return theme;
}

SDL_Rect At(const Theme& theme, const SDL_Rect& r) {
    return SDL_Rect{theme.origin.x + r.x, theme.origin.y + r.y, r.w, r.h};
}

SDL_Rect ObjectivesClose(const Theme& theme) { return At(theme, kObjOk); }

struct ObjectiveLine {
    std::string text;
    bool done = false;
};

std::string HintsOf(const entt::registry& registry) {
    const Scenario::File* file = ECS::Triggers::ScenarioOf(registry);
    return file != nullptr ? Scenario::Show(file->texts[Scenario::kHints]) : std::string{};
}

std::vector<ObjectiveLine> ObjectivePage(const entt::registry& registry, int tab) {
    std::vector<ObjectiveLine> page;
    const Scenario::File* file = ECS::Triggers::ScenarioOf(registry);
    if (file == nullptr) {
        page.push_back({" "});
        page.push_back({VictoryText(registry)});
        return page;
    }
    if (tab == 1) {
        page.push_back({" "});
        page.push_back({Get(10911)});
        page.push_back({HintsOf(registry)});
        return page;
    }
    for (const ECS::Triggers::Objective& o : ECS::Triggers::Objectives(registry)) {
        if (!o.on && !o.fired) continue;
        page.push_back({o.text, o.fired && !o.on});
        page.push_back({" "});
    }
    if (page.empty()) {
        page.push_back({" "});
        page.push_back({Scenario::Show(file->texts[Scenario::kInstructions])});
    }
    return page;
}

// The page's lines as the text box wraps them, each with whether it is
// struck out.
std::vector<ObjectiveLine> ObjectiveRows(const entt::registry& registry, int tab) {
    const int body = Text::GameFont(22);
    const int width = PanelWrapWidth(kObjText.w, 0);
    std::vector<ObjectiveLine> rows;
    for (const ObjectiveLine& paragraph : ObjectivePage(registry, tab)) {
        std::vector<std::string_view> lines = PanelLines(body, paragraph.text, width, true);
        if (lines.empty()) lines.push_back(std::string_view{});
        for (std::string_view line : lines) rows.push_back({std::string(line), paragraph.done});
    }
    return rows;
}

int ObjectiveRowsShown() { return kObjText.h / PanelPitch(Text::GameFont(22)); }

void DrawObjectives(SDL_Renderer* r, ECS::Simulation& sim, int w, int h) {
    const Theme theme = ObjectivesTheme(w, h);
    Shared& s = S();
    const auto& registry = sim.GetRegistry();
    const bool tabs = !HintsOf(registry).empty();
    if (!tabs) s.objectives_tab = 0;
    const SDL_Rect panel = SavePanel(w, h);
    SDL_SetRenderDrawColor(r, 205, 180, 140, 255);
    SDL_RenderFillRect(r, &panel);
    DrawBevel(r, theme, panel, false);
    DrawPanelText(r, Text::GameFont(1), At(theme, kObjTitle), Get(kObjTabLabel[s.objectives_tab]),
                  Align::Centre, Down::Centre, false, SinInk(theme));

    const std::vector<ObjectiveLine> rows = ObjectiveRows(registry, s.objectives_tab);
    const int body = Text::GameFont(22);
    const int struck = Text::GameFont(28);
    const SDL_Rect box = At(theme, kObjText);
    const int shown = ObjectiveRowsShown();
    const SDL_Color black{0, 0, 0, 255};
    for (int i = 0; i < shown && s.objectives_scroll + i < static_cast<int>(rows.size()); ++i) {
        const ObjectiveLine& row = rows[static_cast<size_t>(s.objectives_scroll + i)];
        const int x = box.x + 5;
        const int y = box.y + i * PanelPitch(body);
        DrawPanelLine(r, row.done ? struck : body, x, y, row.text, kBlackInk);
        if (row.done && !row.text.empty()) {
            Text::StrikeOut(r, struck, x, y + Text::GdiAscent(struck) - Text::Ascent(struck),
                            Text::Width(struck, row.text), black);
        }
    }
    if (static_cast<int>(rows.size()) > shown) {
        DrawButtonArt(r, theme, 8, box.x + box.w, box.y);
        DrawButtonArt(r, theme, 10, box.x + box.w, box.y + box.h - kObjScrollW);
    }

    if (tabs) {
        const HAL::GraphicAtlas* art = HAL::GraphicCache::Get().GetInterfaceAtlas(kObjTabArt);
        for (int t = 0; t < 2; ++t) {
            const SDL_Rect tab = At(theme, kObjTabs[t]);
            if (art != nullptr && art->base != nullptr &&
                kObjTabFrame[t] < static_cast<int>(art->frames.size())) {
                const HAL::GraphicFrame& f = art->frames[static_cast<size_t>(kObjTabFrame[t])];
                const SDL_Rect dst = {tab.x - f.hotspot_x, tab.y - f.hotspot_y, f.rect.w, f.rect.h};
                SDL_RenderCopy(r, art->base, &f.rect, &dst);
            }
            const bool chosen = t == s.objectives_tab;
            DrawTextIn(r, Text::GameFont(11), tab, Get(kObjTabLabel[t]),
                       chosen ? theme.state : Hit(tab, s.mx, s.my) ? theme.focus : theme.text,
                       theme.text_shadow);
        }
    }
    Button close{ObjectivesClose(theme), Get(4001), Text::GameFont(0)};
    State state = StateOf(close, s.mx, s.my, s.held);
    if (state == State::Normal) state = State::Hover;   // the dialog's focus
    DrawButton(r, theme, close, state);
}

// A click in the Objectives dialog; true when it closes.
bool ObjectivesClick(ECS::Simulation& sim, int x, int y, int w, int h) {
    const Theme theme = ObjectivesTheme(w, h);
    Shared& s = S();
    if (Hit(ObjectivesClose(theme), x, y)) {
        Click();
        return true;
    }
    if (!HintsOf(sim.GetRegistry()).empty()) {
        for (int t = 0; t < 2; ++t) {
            if (Hit(At(theme, kObjTabs[t]), x, y) && t != s.objectives_tab) {
                Click();
                s.objectives_tab = t;
                s.objectives_scroll = 0;
            }
        }
    }
    const SDL_Rect box = At(theme, kObjText);
    const int most = std::max(0, static_cast<int>(ObjectiveRows(sim.GetRegistry(), s.objectives_tab).size()) -
                                 ObjectiveRowsShown());
    if (Hit(SDL_Rect{box.x + box.w, box.y, kObjScrollW, kObjScrollW}, x, y)) {
        s.objectives_scroll = std::max(0, s.objectives_scroll - 1);
    } else if (Hit(SDL_Rect{box.x + box.w, box.y + box.h - kObjScrollW, kObjScrollW, kObjScrollW}, x, y)) {
        s.objectives_scroll = std::min(most, s.objectives_scroll + 1);
    }
    return false;
}

// ---- Chat ----------------------------------------------------------------
//
// Who hears: a check per player, and buttons that check the allies, the
// enemies or everyone; what to say in a field below; OK sends it as chat
// orders. The art is the Chat dialog's own (Sin 50017).
struct ChatLayout {
    SDL_Rect allies, enemies, everyone, field, ok, cancel;
};
constexpr int kChatRowTop = 110;
constexpr int kChatRowPitch = 30;

ChatLayout ChatRects(const Theme& theme) {
    (void)theme;
    const SDL_Rect p = SavePanel(800, 600);
    const int third = (p.w - 70) / 3;
    return ChatLayout{SDL_Rect{p.x + 25, p.y + 255, third, 30},
                      SDL_Rect{p.x + 35 + third, p.y + 255, third, 30},
                      SDL_Rect{p.x + 45 + 2 * third, p.y + 255, third, 30},
                      SDL_Rect{p.x + 25, p.y + 300, p.w - 50, 26},
                      SDL_Rect{p.x + p.w / 2 - 115, p.y + 350, 105, 30},
                      SDL_Rect{p.x + p.w / 2 + 10, p.y + 350, 105, 30}};
}

std::vector<Core::PlayerId> Others(const entt::registry& registry) {
    std::vector<Core::PlayerId> out;
    for (int p = 1; p < Core::kMaxPlayers; ++p) {
        const auto* player = ECS::Players::Find(registry, static_cast<Core::PlayerId>(p));
        if (player != nullptr && player->active && p != Core::LocalPlayer()) {
            out.push_back(static_cast<Core::PlayerId>(p));
        }
    }
    return out;
}

SDL_Rect ChatCheck(const Theme& theme, int row) {
    (void)theme;
    const SDL_Rect p = SavePanel(800, 600);
    return SDL_Rect{p.x + 25, p.y + 70 + row * kChatRowPitch - 8, 39, 39};
}

void OpenChat() {
    Shared& s = S();
    for (bool& h : s.hears) h = true;
    s.chat.text.clear();
    s.chat.font = Text::kGeorgia10B;
    s.chat.max_length = ECS::Chat::kMostCharacters;
    s.chat.focused = true;
    HAL::TextInput::Want(HAL::TextInput::Kind::Line);
    SDL_StartTextInput();
}

// Every cheat the chat line recognises, in two columns inside the right half
// of the Chat dialog, above the recipient buttons.
void DrawCheatList(SDL_Renderer* r, const SDL_Rect& panel) {
    static const char* const kCodes[] = {
        "cheese steak jimmy's", "lumberjack", "robin hood", "rock on",
        "marco", "polo", "aegis", "fast production",
        "natural wonders", "i r winner", "black death", "wimpywimpywimpy",
        "how do you turn this on", "to smithereens",
        "i love the monkey head", "torpedo1", "torpedo2", "torpedo3",
        "torpedo4", "torpedo5", "torpedo6", "torpedo7", "torpedo8",
    };
    const int list_left = panel.x + 372;
    const int list_w = panel.w - 372 - 14;
    const int col_w = list_w / 2;
    const int top = panel.y + 66;
    const int row_h = 13;
    const SDL_Color ink{35, 20, 8, 255};
    const SDL_Color dim{90, 65, 35, 255};
    Text::Draw(r, Text::kGeorgia8B, list_left, top - 17, "作弊代码", dim);
    for (size_t i = 0; i < std::size(kCodes); ++i) {
        const int col = static_cast<int>(i) >= 12 ? 1 : 0;
        const int row = static_cast<int>(i) % 12;
        Text::Draw(r, Text::kGeorgia8B, list_left + col * col_w, top + row * row_h,
                   kCodes[i], ink);
    }
}

void DrawChat(SDL_Renderer* r, ECS::Simulation& sim, int w, int h) {
    const Theme& theme = GameDialogTheme(Sin::kChat, w, h);
    const SDL_Rect panel = SavePanel(w, h);
    SDL_SetRenderDrawColor(r, 205, 180, 140, 255);
    SDL_RenderFillRect(r, &panel);
    DrawBevel(r, theme, panel, false);
    DrawTitle(r, theme, Sin::kChat, 9832);
    Shared& s = S();
    const SDL_Color ink{0, 0, 0, 255};
    DrawText(r, Text::kGeorgia10B, panel.x + 25, panel.y + 48, Get(9831), ink, ink,
             Align::Left, false);
    const auto& registry = sim.GetRegistry();
    const auto others = Others(registry);
    for (int row = 0; row < static_cast<int>(others.size()); ++row) {
        const Core::PlayerId p = others[static_cast<size_t>(row)];
        const SDL_Rect box = ChatCheck(theme, row);
        DrawButtonArt(r, theme, s.hears[p] ? 2 : 0, box.x, box.y);
        const HAL::PaletteColor c = HAL::GraphicCache::Get().GetPlayerColor(p);
        DrawText(r, Text::kGeorgia10B, box.x + 50, box.y + 8,
                 Rendering::UIRenderer::PlayerName(registry, p), SDL_Color{c.r, c.g, c.b, 255}, ink);
    }
    const ChatLayout l = ChatRects(theme);
    for (const auto& [rect, label] : {std::pair{l.allies, 9833}, std::pair{l.enemies, 9834},
                                      std::pair{l.everyone, 9835}}) {
        Button b{rect, Get(label), Text::kBlackletter14};
        DrawButton(r, theme, b, StateOf(b, s.mx, s.my, s.held));
    }
    s.chat.rect = l.field;
    s.chat.font = Text::kGeorgia10B;
    DrawTextField(r, theme, s.chat);
    DrawCheatList(r, panel);
    Button ok{l.ok, Get(4001), Text::kBlackletter14};
    State state = StateOf(ok, s.mx, s.my, s.held);
    if (state == State::Normal) state = State::Hover;
    DrawButton(r, theme, ok, state);
    Button cancel{l.cancel, Get(4002), Text::kBlackletter14};
    DrawButton(r, theme, cancel, StateOf(cancel, s.mx, s.my, s.held));
}

// Sends what was typed to whoever hears: everyone, the allies, or each
// chosen player in turn.
void SendChat(const entt::registry& registry, const std::string& text, const bool* hears) {
    if (text.empty()) return;
    auto& queue = Core::CommandQueue::Get();
    const Core::PlayerId me = Core::LocalPlayer();
    // In a game that allows cheats, a cheat is done rather than said.
    if (const auto* setup = registry.ctx().find<Core::GameSetup>(); setup != nullptr && setup->cheats) {
        if (const int code = ECS::Cheats::Recognise(text); code != ECS::Cheats::kNone) {
            queue.PushCommand(Core::CheatCommand{code, me});
            return;
        }
    }
    const auto others = Others(registry);
    bool all = true, allies_only = true, any = false;
    for (Core::PlayerId p : others) {
        const bool ally = ECS::Diplomacy::Allied(registry, me, p);
        all = all && hears[p];
        allies_only = allies_only && hears[p] == ally;
        any = any || hears[p];
    }
    if (!any) return;
    if (all) {
        queue.PushCommand(Core::ChatCommand{0, 0, text, me});
    } else if (allies_only) {
        queue.PushCommand(Core::ChatCommand{1, 0, text, me});
    } else {
        for (Core::PlayerId p : others) {
            if (hears[p]) queue.PushCommand(Core::ChatCommand{2, p, text, me});
        }
    }
}

// A click in the Chat dialog; true when it closed it.
bool ChatClick(ECS::Simulation& sim, int x, int y, int w, int h) {
    const Theme& theme = GameDialogTheme(Sin::kChat, w, h);
    const auto& registry = sim.GetRegistry();
    Shared& s = S();
    const auto others = Others(registry);
    for (int row = 0; row < static_cast<int>(others.size()); ++row) {
        if (Hit(ChatCheck(theme, row), x, y)) {
            Click();
            s.hears[others[static_cast<size_t>(row)]] ^= true;
            return false;
        }
    }
    const ChatLayout l = ChatRects(theme);
    const Core::PlayerId me = Core::LocalPlayer();
    if (Hit(l.allies, x, y) || Hit(l.enemies, x, y) || Hit(l.everyone, x, y)) {
        Click();
        const bool allies = Hit(l.allies, x, y), enemies = Hit(l.enemies, x, y);
        for (Core::PlayerId p : others) {
            const bool ally = ECS::Diplomacy::Allied(registry, me, p);
            s.hears[p] = allies ? ally : enemies ? !ally : true;
        }
        return false;
    }
    if (Hit(l.field, x, y)) {
        s.chat.focused = true;
        HAL::TextInput::Want(HAL::TextInput::Kind::Line);
        SDL_StartTextInput();
        HAL::TextInput::Pressed(x, y);
        return false;
    }
    if (Hit(l.ok, x, y)) {
        Click();
        SendChat(registry, s.chat.text, s.hears);
        return true;
    }
    if (Hit(l.cancel, x, y)) {
        Click();
        return true;
    }
    return false;
}

// The chat line: what Enter opens over the game, sent to everyone -- 111
// rows into the view, at the Options' Text size like the rest of the text
// over the world.
void DrawChatLine(SDL_Renderer* r, int w, int h) {
    const Theme& theme = GameDialogTheme(Sin::kChat, w, h);
    Shared& s = S();
    const int percent = Rendering::UIRenderer::TextPercent();
    auto sized = [percent](int pixels) { return (pixels * percent + 50) / 100; };
    const SDL_Rect view = Rendering::UIRenderer::ViewRect(w, h);
    s.chat.rect = SDL_Rect{sized(4), view.y + sized(111), std::min(w - 8, sized(520)), sized(24)};
    s.chat.font = Text::Scaled(Text::kGeorgia10B, percent);
    DrawTextField(r, theme, s.chat);
}

uint32_t SinOf(Dialog d) {
    switch (d) {
    case Dialog::Options: return Sin::kGameDialog;
    case Dialog::Objectives: return Sin::kObjectives;
    case Dialog::Diplomacy: return Sin::kDiplomacy;
    case Dialog::Chat: return Sin::kChat;
    case Dialog::TechTree: return Sin::kGameDialog;
    default: return Sin::kGameMenu;
    }
}

int TitleOf(Dialog d) {
    switch (d) {
    case Dialog::Options: return 9274;
    case Dialog::Objectives: return 10910;
    case Dialog::Diplomacy: return 9851;
    case Dialog::Chat: return 9832;
    case Dialog::TechTree: return 9799;
    default: return 9446;
    }
}

int g_w = 1024;
int g_h = 768;
float g_dialog_scale = 1.0f;
int g_dialog_offx = 0;
int g_dialog_offy = 0;
bool g_dialog_scaled = false;

} // namespace

void Open(Dialog dialog) {
    S().dialog = dialog;
    if (dialog == Dialog::SaveGame) OpenSave();
    // The diplomacy choices start from the world as it is, read on the
    // dialog's first frame.
    if (dialog == Dialog::Diplomacy) S().diplomacy_fresh = true;
    if (dialog == Dialog::Chat || dialog == Dialog::ChatLine) OpenChat();
    if (dialog == Dialog::Options) OpenOptions(g_w, g_h);
    if (dialog == Dialog::TechTree) TechTree::OpenInGame();
    // The screen opens on its first page.
    if (dialog == Dialog::Achievements) {
        Achievements::State fresh;
        fresh.opening = S().achievements.opening;
        S().achievements = fresh;
    }
    S().objectives_tab = 0;
    S().objectives_scroll = 0;
}

void ShowAchievementsPage(int page) {
    S().achievements.page = std::clamp(page, static_cast<int>(Achievements::kScore),
                                       static_cast<int>(Achievements::kTimeline));
}

void Reset() { S() = Shared{}; }

Dialog Current() { return S().dialog; }

bool WantsText() {
    const Dialog d = S().dialog;
    return d == Dialog::ChatLine || d == Dialog::Chat || d == Dialog::SaveGame;
}

bool Paused() {
    if (S().paused) return true;
    // A single-player game stands still behind its dialogs; the achievements
    // at the end, too. Typing a line of chat does not stop it.
    return S().dialog != Dialog::None && S().dialog != Dialog::ChatLine;
}

void TogglePause() { S().paused = !S().paused; }

void GameOver(bool won, bool single_player) {
    Shared& s = S();
    if (s.over_message >= 0) return;
    s.single_player = single_player;
    s.over_message = won ? Core::Strings::Id::Victorious : Core::Strings::Id::Defeated;
    s.over_at = SDL_GetTicks();
    HAL::Audio::Play(won ? Audio::InterfaceSound::kWon : Audio::InterfaceSound::kLost, 1.0f, 0.0f);
}

void Update() {
    Shared& s = S();
    if (s.dialog == Dialog::None && s.over_message >= 0 && !s.ended &&
        SDL_GetTicks() - s.over_at > 1500) {
        s.ended = true;
        s.outcome = Outcome::Ended;
    }
}

bool HandleEvent(const SDL_Event& raw, ECS::Simulation& sim) {
    SDL_Event e = raw;
    if (g_dialog_scaled && (e.type == SDL_MOUSEBUTTONDOWN || e.type == SDL_MOUSEBUTTONUP ||
                            e.type == SDL_MOUSEMOTION)) {
        e.button.x = static_cast<int>((raw.button.x - g_dialog_offx) / g_dialog_scale);
        e.button.y = static_cast<int>((raw.button.y - g_dialog_offy) / g_dialog_scale);
        e.motion.x = e.button.x;
        e.motion.y = e.button.y;
    }

    Shared& s = S();
    if (e.type == SDL_MOUSEMOTION) { s.mx = e.motion.x; s.my = e.motion.y; }
    // A button goes down and up where the mouse is.
    if (e.type == SDL_MOUSEBUTTONDOWN || e.type == SDL_MOUSEBUTTONUP) { s.mx = e.button.x; s.my = e.button.y; }
    if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_LEFT) s.held = true;
    if (e.type == SDL_MOUSEBUTTONUP && e.button.button == SDL_BUTTON_LEFT) s.held = false;
    if (s.dialog == Dialog::TechTree) {
        if (TechTree::HandleEvent(e, g_w, g_h) == TechTree::Result::Closed) s.dialog = Dialog::None;
        return true;
    }

    if (e.type == SDL_KEYDOWN) {
        const SDL_Keycode key = e.key.keysym.sym;
        namespace HK = Core::Hotkeys;
        if (s.dialog == Dialog::None) {
            // F10 is the menu's own key, not one of the table's. The
            // Android back gesture opens the same pause menu.
            if (key == SDLK_F10 || key == SDLK_AC_BACK || key == SDLK_ESCAPE) {
                Open(Dialog::Menu);
                return true;
            }
            if (HK::Is(e.key, HK::kGameCommands, HK::kPause)) { TogglePause(); return true; }
            if (HK::Is(e.key, HK::kGameCommands, HK::kDiplomacy)) { Open(Dialog::Diplomacy); return true; }
            if (HK::Is(e.key, HK::kGameCommands, HK::kObjectives)) { Open(Dialog::Objectives); return true; }
            if (HK::Is(e.key, HK::kGameCommands, HK::kChatDialog)) { Open(Dialog::Chat); return true; }
            if (HK::Is(e.key, HK::kGameCommands, HK::kTechTree)) { Open(Dialog::TechTree); return true; }
            if (HK::Is(e.key, HK::kGameCommands, HK::kSave)) { Open(Dialog::SaveGame); return true; }
            if (HK::Is(e.key, HK::kGameCommands, HK::kChat)) { Open(Dialog::ChatLine); return true; }
        }
        if ((s.dialog == Dialog::ChatLine || s.dialog == Dialog::Chat) && key == SDLK_RETURN) {
            // Enter sends: the line to everyone, the dialog to whoever is checked.
            bool everyone[Core::kMaxPlayers];
            for (bool& b : everyone) b = true;
            SendChat(sim.GetRegistry(), s.chat.text, s.dialog == Dialog::ChatLine ? everyone : s.hears);
            s.dialog = Dialog::None;
            return true;
        }
        if (s.dialog == Dialog::SaveGame && key == SDLK_RETURN && !s.save_name.text.empty()) {
            Click();
            s.chosen_name = s.save_name.text;
            s.outcome = Outcome::Save;
            s.dialog = Dialog::None;
            return true;
        }
        if ((key == SDLK_ESCAPE || key == SDLK_AC_BACK) &&
            s.dialog != Dialog::None && s.dialog != Dialog::Achievements) {
            s.dialog = s.dialog == Dialog::Confirm ? Dialog::Menu : Dialog::None;
            return true;
        }
        // Escape is the Achievements' "Return to Game" while the game goes
        // on; at its end the screen waits for a button.
        if (key == SDLK_ESCAPE && s.dialog == Dialog::Achievements && s.over_message < 0) {
            s.dialog = Dialog::None;
            return true;
        }
    }
    if (s.dialog == Dialog::None) {
        // The end-of-game message gives way, on a click, to whatever comes
        // before the achievements, which the application then opens.
        if (s.over_message >= 0 && !s.ended && e.type == SDL_MOUSEBUTTONUP &&
            SDL_GetTicks() - s.over_at > 1500) {
            s.ended = true;
            s.outcome = Outcome::Ended;
            return true;
        }
        return false;
    }
    const bool up = e.type == SDL_MOUSEBUTTONUP && e.button.button == SDL_BUTTON_LEFT;
    const int x = up ? e.button.x : 0;
    const int y = up ? e.button.y : 0;
    if (s.dialog == Dialog::ChatLine || s.dialog == Dialog::Chat) {
        if (TypeIntoField(s.chat, e)) return true;
        if (s.dialog == Dialog::ChatLine) return e.type != SDL_MOUSEMOTION;
    }
    if (s.dialog == Dialog::Options) {
        if (OptionsEventIn(e, g_w, g_h)) s.dialog = Dialog::Menu;
        return true;
    }
    if (s.dialog == Dialog::SaveGame) {
        // Typing goes to the name; a saved game picked from the list gives
        // its own, to save over it.
        if (TypeIntoField(s.save_name, e)) return true;
        if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_LEFT &&
            ClickListBox(s.saves, e.button.x, e.button.y)) {
            if (s.saves.selected >= 0) s.save_name.text = s.saves.items[s.saves.selected];
            return true;
        }
        const Theme& theme = GameDialogTheme(Sin::kGameDialog, g_w, g_h);
        const SaveLayout l = SaveRects(g_w, g_h);
        if (up && Hit(l.save, x, y) && !s.save_name.text.empty()) {
            Click();
            s.chosen_name = s.save_name.text;
            s.outcome = Outcome::Save;
            s.dialog = Dialog::None;
        } else if (up && Hit(l.cancel, x, y)) {
            Click();
            s.dialog = Dialog::None;
        }
        return true;
    }
    switch (s.dialog) {
    case Dialog::Diplomacy:
        if (up && !s.diplomacy_fresh && DiplomacyClick(sim, x, y, g_w, g_h)) s.dialog = Dialog::None;
        break;
    case Dialog::Chat:
        if (up && ChatClick(sim, x, y, g_w, g_h)) s.dialog = Dialog::None;
        break;
    case Dialog::Objectives:
        if (up && ObjectivesClick(sim, x, y, g_w, g_h)) s.dialog = Dialog::None;
        if (e.type == SDL_MOUSEWHEEL) {
            const int most = std::max(0, static_cast<int>(ObjectiveRows(sim.GetRegistry(), s.objectives_tab).size()) -
                                         ObjectiveRowsShown());
            s.objectives_scroll = std::clamp(s.objectives_scroll - e.wheel.y, 0, most);
        }
        break;
    case Dialog::Cheats: {
        if (!up) break;
        if (auto* setup = sim.GetRegistry().ctx().find<Core::GameSetup>()) setup->cheats = true;
        bool handled = false;
        for (int i = 0; i < static_cast<int>(std::size(kCheats)); ++i) {
            if (!Hit(CheatButtonRect(i, g_w, g_h), x, y)) continue;
            Click();
            ECS::Cheats::Apply(sim.GetRegistry(), sim.GetGrid(), Core::LocalPlayer(),
                               kCheats[i].code);
            handled = true;
            break;
        }
        if (!handled && Hit(SDL_Rect{(g_w - kCheatPanelW) / 2 + kCheatPanelW - 114,
                                    (g_h - kCheatPanelH) / 2 + kCheatPanelH - 46, 92, 30}, x, y)) {
            Click();
            s.dialog = Dialog::Menu;
        }
        break;
    }
    case Dialog::Menu: {
        if (!up) break;
        const Theme& theme = MenuTheme(g_w, g_h);
        for (int i = 0; i < static_cast<int>(std::size(kMenuButtons)); ++i) {
            if (!Hit(MenuButtonRect(theme, i, g_w, g_h), x, y)) continue;
            Click();
            const MenuButton& b = kMenuButtons[i];
            if (b.confirm >= 0) {
                s.question = b.confirm;
                s.on_yes = b.outcome;
                s.dialog = Dialog::Confirm;
            } else if (b.opens != Dialog::None) {
                Open(b.opens);
            } else {
                s.outcome = b.outcome;
                s.dialog = Dialog::None;
            }
            break;
        }
        break;
    }
    case Dialog::Confirm: {
        if (!up) break;
        const Theme& theme = MenuTheme(g_w, g_h);
        if (Hit(ConfirmButton(theme, true), x, y)) {
            Click();
            s.outcome = s.on_yes;
            s.dialog = Dialog::None;
        } else if (Hit(ConfirmButton(theme, false), x, y)) {
            Click();
            s.dialog = Dialog::Menu;
        }
        break;
    }
    case Dialog::Achievements: {
        const bool down = e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_LEFT;
        if (!up && !down) break;
        const int page = s.achievements.page;
        const Achievements::Exit exit =
            Achievements::Mouse(s.achievements, g_w, g_h, e.button.x, e.button.y, down);
        if (s.achievements.page != page) Click();
        switch (exit) {
        case Achievements::Exit::None: break;
        case Achievements::Exit::ReturnToGame:
            Click();
            s.dialog = Dialog::None;
            break;
        case Achievements::Exit::MainMenu:
        case Achievements::Exit::CampaignMenu:
            // Both lead to the main menu.
            Click();
            s.outcome = Outcome::QuitToMenu;
            s.dialog = Dialog::None;
            break;
        case Achievements::Exit::PlayAgain:
            Click();
            s.outcome = Outcome::Restart;
            s.dialog = Dialog::None;
            break;
        }
        break;
    }
    default: {
        if (up && Hit(PlaceholderClose(SinOf(s.dialog), g_w, g_h), x, y)) {
            Click();
            s.dialog = Dialog::None;
        }
        break;
    }
    }
    // While a dialog is open nothing behind it hears the mouse or the keys.
    return true;
}

void Draw(SDL_Renderer* r, ECS::Simulation& sim, int w, int h) {
    Shared& s = S();
    g_dialog_scaled = s.dialog != Dialog::None && s.dialog != Dialog::Achievements;
    if (g_dialog_scaled) {
        constexpr int lw = 800, lh = 600;
        const float sc = std::min(static_cast<float>(w) / lw, static_cast<float>(h) / lh);
        g_dialog_scale = sc;
        g_dialog_offx = (w - static_cast<int>(lw * sc)) / 2;
        g_dialog_offy = (h - static_cast<int>(lh * sc)) / 2;
        const SDL_Rect viewport{g_dialog_offx, g_dialog_offy, static_cast<int>(lw * sc),
                                static_cast<int>(lh * sc)};
        SDL_RenderSetViewport(r, &viewport);
        SDL_RenderSetScale(r, sc, sc);
        w = lw;
        h = lh;
        if (s.dialog != Dialog::Menu && s.dialog != Dialog::Cheats) {
            SDL_SetRenderDrawBlendMode(r, SDL_BLENDMODE_BLEND);
            const SDL_Rect shade{0, 0, lw, lh};
            SDL_SetRenderDrawColor(r, 0, 0, 0, 120);
            SDL_RenderFillRect(r, &shade);
        }
    } else {
        g_dialog_scale = 1.0f;
        g_dialog_offx = g_dialog_offy = 0;
    }
    g_w = w;
    g_h = h;
    Rendering::UIRenderer::SetHelpEnabled(s.dialog == Dialog::None);
    Rendering::UIRenderer::SetHudHidden(s.dialog == Dialog::Diplomacy);
    HAL::Touch::SetUiOnly(s.dialog != Dialog::None);
    // The message at the end of the game, large, in the middle of the view.
    if (s.over_message >= 0 && s.dialog == Dialog::None) {
        DrawText(r, Text::kBlackletter28B, w / 2, h / 2 - 60, Get(s.over_message),
                 SDL_Color{255, 255, 255, 255}, SDL_Color{0, 0, 0, 255}, Align::Centre);
    }
    // "Game Paused": a 600x60 text panel centred in the map view, in Lucida
    // Blackletter 21 bold, white.
    if (s.paused && s.dialog == Dialog::None) {
        const SDL_Rect view = Rendering::UIRenderer::ViewRect(w, h);
        const SDL_Rect box{view.x + (view.w - 600) / 2, view.y + (view.h - 60) / 2, 600, 60};
        DrawTextIn(r, Text::kBlackletter21B, box, Get(9001), SDL_Color{255, 255, 255, 255},
                   SDL_Color{0, 0, 0, 255});
    }
    switch (s.dialog) {
    case Dialog::None: break;
    case Dialog::Menu: DrawMenu(r, w, h); break;
    case Dialog::Cheats: DrawCheats(r, w, h); break;
    case Dialog::Confirm: DrawConfirm(r, w, h); break;
    case Dialog::Achievements: {
        // Why the screen is open decides its buttons: the game going on, or
        // over; a campaign's scenario; a game against the computer.
        Achievements::Opening& opening = s.achievements.opening;
        opening.game_over = s.over_message >= 0;
        const auto* setup = sim.GetRegistry().ctx().find<Core::GameSetup>();
        opening.campaign = setup != nullptr && !setup->scenario.empty() && setup->scenario_entry >= 0;
        opening.single_player = s.single_player;
        Achievements::Draw(r, sim, w, h, s.achievements, s.mx, s.my, s.held);
        break;
    }
    case Dialog::SaveGame: DrawSave(r, w, h, sim); break;
    case Dialog::Objectives: DrawObjectives(r, sim, w, h); break;
    case Dialog::Options: DrawOptionsDialog(r, w, h); break;
    case Dialog::Chat: DrawChat(r, sim, w, h); break;
    case Dialog::ChatLine: DrawChatLine(r, w, h); break;
    case Dialog::TechTree: TechTree::Draw(r, &sim.GetRegistry(), w, h); break;
    case Dialog::Diplomacy:
        if (s.diplomacy_fresh) {
            OpenDiplomacy(sim.GetRegistry());
            s.diplomacy_fresh = false;
        }
        DrawDiplomacy(r, sim, w, h);
        break;
    default: DrawPlaceholder(r, SinOf(s.dialog), TitleOf(s.dialog), w, h); break;
    }
    if (g_dialog_scaled) {
        SDL_RenderSetScale(r, 1.0f, 1.0f);
        SDL_RenderSetViewport(r, nullptr);
    }
    // Leave the renderer on the whole window; the next frame's world must not
    // inherit the dialog's 4:3 viewport.
    if (g_dialog_scaled) {
        SDL_RenderSetViewport(r, nullptr);
        SDL_RenderSetScale(r, 1.0f, 1.0f);
    }
}

std::string SaveName() { return S().chosen_name; }

Outcome TakeOutcome() {
    const Outcome o = S().outcome;
    S().outcome = Outcome::None;
    return o;
}

} // namespace GameDialogs
